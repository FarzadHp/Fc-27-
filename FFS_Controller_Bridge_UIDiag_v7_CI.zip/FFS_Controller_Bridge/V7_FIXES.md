# v7: confirmed defects and evidence integrity

Based on the supplied UIDiag_v6_CI archive. Classic layout and controller/macro engine are unchanged.

## Fixed
- CI selects an explicit archive (workflow_dispatch input), never a lexicographically newest file.
- Archive SHA-256 and per-source-file SHA-256 manifest are uploaded with results.
- tools/ci_checks.py runs all checks and records command/exit status; any failed required check fails the job. Logs survive ordinary command failures and timeouts. Artifact upload remains always().
- Cold and warm native experiments have separate CI checks. Child failure is only accepted in the cold experiment when exhaustion and the expected menu failure are observed. Missing warm detector output fails evidence validation. Each writes result.json; application_fix_proven is always false.
- Native-window probe exceptions now destroy the candidate form and restore selection, retaining the previous form.
- Missing native windows no longer cause allocation of another modal native dialog under resource exhaustion. Existing log UI and file report the error. The message no longer asserts an unproven root cause.
- Added regressions for CI failure propagation, source fingerprinting, experiment validation, probe cleanup and no-dialog form retention. Existing tests remain intact.

## Windows usage
Extract to a new directory. Copy .github/workflows/windows-check.yml to the repository's root .github/workflows/ directory (a workflow inside a ZIP is not executed by GitHub). Commit FFS_Controller_Bridge_UIDiag_v7_CI.zip and choose that exact file in Run workflow. CI requires a Windows GUI session as before.

Local Windows checks: python tools/ci_checks.py (installs the same pinned test dependencies as the previous CI). Reports are in out/. This includes deliberate resource-exhaustion experiments in isolated child processes; do not run those experiments during important work. The expected cold crash is not an application PASS. A different OS/Tk behavior may fail experiment validation and needs inspection, not relaxed tests.

## Validation here
158 tests: 126 passed, 32 skipped (environment/platform dependencies, including GUI). compileall passed. This is not a new Windows result. The supplied earlier Windows results belong to an incompletely identified earlier source, not this release. No EXE built here.

## Remaining uncertainty
No demonstrated leak in the original user session has been identified or repaired. Menu warm-up does not restore exhausted resources. Form preservation does not guarantee operation after system-wide/native resource failure. Do not change Windows quotas as a substitute for finding the cause. Real-controller, virtual-output and packaged EXE validation remain necessary. Earlier release documents retain their historical status; this file describes v7.
