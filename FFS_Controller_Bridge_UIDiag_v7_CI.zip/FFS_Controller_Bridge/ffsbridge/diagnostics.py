"""Evidence-gathering helpers: bounded, cheap and never on the controller's fast path.

Nothing here changes bridge behaviour. It records what the process looked like
(Tk objects, Windows USER/GDI handles, native crashes, UI stalls) so a
rare Windows-only failure can be diagnosed from logs instead of guessed.
"""
from __future__ import annotations

import faulthandler
import logging
import sys
import threading
import time
from pathlib import Path

log = logging.getLogger(__name__)

# GetGuiResources flags (winuser.h).
GR_GDIOBJECTS, GR_USEROBJECTS, GR_GDIOBJECTS_PEAK, GR_USEROBJECTS_PEAK = 0, 1, 2, 4
# Windows allows 10,000 USER and 10,000 GDI objects per process by default.
WARN_USER_OBJECTS = WARN_GDI_OBJECTS = 2500
WARN_WIDGETS = 400
WARN_PENDING_AFTER = 100

_fault_file = None  # faulthandler needs this file object to stay open for the process lifetime


# --------------------------------------------------------------------------- logging helpers
class LogThrottle:
    """Allow a repeating error through at most once per interval, counting the rest.

    A 20 Hz UI poll that fails persistently must not fill the rotating log (or
    hide the first traceback, which is the useful one) with thousands of copies.
    """

    def __init__(self, interval=30.0, clock=time.monotonic):
        self.interval, self.clock = interval, clock
        self.last, self.suppressed = {}, {}

    def error(self, logger, key, message, exc_info=True):
        now = self.clock()
        last = self.last.get(key)
        if last is not None and now - last < self.interval:
            self.suppressed[key] = self.suppressed.get(key, 0) + 1
            return False
        skipped = self.suppressed.pop(key, 0)
        suffix = f" [{skipped} identical error(s) suppressed since the last report]" if skipped else ""
        logger.error("%s%s", message, suffix, exc_info=exc_info)
        self.last[key] = now
        return True


def rotate_file(path: Path, keep=3):
    """path -> path.1 -> path.2 ... (at most `keep` old copies)."""
    path = Path(path)
    if not path.exists():
        return
    for index in range(keep, 0, -1):
        source = path if index == 1 else path.with_name(f"{path.name}.{index - 1}")
        target = path.with_name(f"{path.name}.{index}")
        if source.exists():
            target.unlink(missing_ok=True)
            source.replace(target)


# --------------------------------------------------------------------------- native crashes
def enable_faulthandler(directory: Path):
    """Write Python tracebacks of ALL threads to a file when the process dies natively.

    Covers SIGSEGV/SIGFPE/SIGABRT/SIGILL and Windows access violations; Tcl_Panic ends
    in abort(), so a Tk panic is expected to leave a Python-side trace here.
    Limits: not written for TerminateProcess, OOM/kill from outside, power loss or a
    hang; the trace shows Python frames only, not the native C stack. The file stays
    open for the process lifetime (a requirement of faulthandler) and is removed on a
    clean exit when empty. Old files rotate to .1/.2/.3 so crashes are not overwritten.
    """
    global _fault_file
    if _fault_file is not None:
        return Path(_fault_file.name)
    path = Path(directory) / "faulthandler.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    rotate_file(path)
    _fault_file = open(path, "w", encoding="utf-8")
    faulthandler.enable(file=_fault_file, all_threads=True)
    log.info("faulthandler enabled: %s", path)
    return path


def disable_faulthandler():
    global _fault_file
    if _fault_file is None:
        return
    faulthandler.cancel_dump_traceback_later()
    faulthandler.disable()
    path = Path(_fault_file.name)
    _fault_file.close()
    _fault_file = None
    if path.exists() and path.stat().st_size == 0:
        path.unlink()


class StallWatch:
    """Debug aid: dump every thread's stack if the Tk thread stops beating for `timeout`.

    The UI poll calls beat() about every 50 ms. A blocked event loop (SDL call,
    join, file or driver I/O on the Tk thread) therefore leaves a traceback showing
    exactly where it is blocked. Re-arming is throttled because each arm starts a thread.
    """

    def __init__(self, timeout=15.0, clock=time.monotonic):
        self.timeout, self.clock = timeout, clock
        self.armed_at = None

    def beat(self):
        now = self.clock()
        if self.armed_at is not None and now - self.armed_at < 1.0:
            return
        target = _fault_file if _fault_file is not None else sys.stderr
        if target is None:
            return
        faulthandler.dump_traceback_later(self.timeout, repeat=False, file=target)
        self.armed_at = now

    def stop(self):
        faulthandler.cancel_dump_traceback_later()
        self.armed_at = None


# --------------------------------------------------------------------------- measurements
_win = None


def _win_api():
    """Typed ctypes bindings, created once. Returns None off Windows."""
    global _win
    if sys.platform != "win32":
        return None
    if _win is None:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetCurrentProcess.restype = wintypes.HANDLE
        user32.GetGuiResources.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        user32.GetGuiResources.restype = wintypes.DWORD
        kernel32.GetProcessHandleCount.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel32.GetProcessHandleCount.restype = wintypes.BOOL
        callback = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumChildWindows.argtypes = (wintypes.HWND, callback, wintypes.LPARAM)
        user32.EnumChildWindows.restype = wintypes.BOOL
        _win = (ctypes, wintypes, user32, kernel32, callback)
    return _win


def process_resources():
    """Windows USER/GDI/handle counts for this process ({} elsewhere).

    USER and GDI object counts are the evidence for 'handles leak until painting or
    window creation fails' (default per-process limit: 10,000 each).
    """
    api = _win_api()
    if api is None:
        return {}
    ctypes, wintypes, user32, kernel32, _ = api
    process = kernel32.GetCurrentProcess()
    handles = wintypes.DWORD()
    if not kernel32.GetProcessHandleCount(process, ctypes.byref(handles)):
        handles.value = 0
    return {
        "user": user32.GetGuiResources(process, GR_USEROBJECTS),
        "gdi": user32.GetGuiResources(process, GR_GDIOBJECTS),
        "user_peak": user32.GetGuiResources(process, GR_USEROBJECTS_PEAK),
        "gdi_peak": user32.GetGuiResources(process, GR_GDIOBJECTS_PEAK),
        "handles": handles.value,
    }


def native_window_count(root):
    """Number of native HWNDs below the toplevel frame (Windows; None elsewhere).

    Every Tk widget owns one HWND, so this should track the Tk widget count.
    """
    api = _win_api()
    if api is None:
        return None
    ctypes, _, user32, _, callback = api
    total = [0]

    def visit(_hwnd, _param):
        total[0] += 1
        return True

    proc = callback(visit)  # keep a reference while EnumChildWindows runs
    user32.EnumChildWindows(int(root.wm_frame(), 16), proc, 0)
    return total[0]


def count_widgets(widget):
    return 1 + sum(count_widgets(child) for child in widget.winfo_children())


def tk_snapshot(root):
    """Tk-side object counts; must be called on the Tk thread."""
    tcl = root.tk

    def count(*command):
        return len(tcl.splitlist(tcl.call(*command)))

    return {
        "widgets": count_widgets(root),
        "after": count("after", "info"),   # pending timer + idle callbacks
        "commands": count("info", "commands"),
        "globals": count("info", "globals"),
        "threads": threading.active_count(),
    }


def full_snapshot(root):
    data = tk_snapshot(root)
    data.update(process_resources())
    windows = native_window_count(root)
    if windows is not None:
        data["hwnd"] = windows
    return data


def format_snapshot(data):
    return " ".join(f"{key}={value}" for key, value in data.items())


def log_snapshot(root, label, level=logging.INFO):
    try:
        log.log(level, "resources[%s] %s", label, format_snapshot(full_snapshot(root)))
    except Exception:  # a measuring failure must be visible, but must not break the UI
        log.exception("resource snapshot failed [%s]", label)


HANDLE_LIMIT = 10_000


def widgets_without_native_window(widget):
    """Paths of Tk widgets under `widget` that have no native window (HWND 0). Windows only.

    Tk 8.6.12 ignores a failed CreateWindowExW (win/tkWinWindow.c, TkpMakeWindow): the widget
    exists in Tcl and Python but is never painted. Measured on Windows: winfo_id() is 0x0
    for such a widget, and calling it forces the window to be created now.
    """
    if sys.platform != "win32":
        return []
    missing = []

    def walk(node):
        if node.winfo_id() == 0:
            missing.append(str(node))
        for child in node.winfo_children():
            walk(child)

    walk(widget)
    return missing


def handle_pressure(resources=None, fraction=0.8):
    """Message if USER/GDI objects are close to Windows' per-process limit, else None.

    Tk 8.6.12 (win/tkWinWindow.c, TkpMakeWindow) does not check CreateWindowExW's result:
    once USER objects run out, newly built widgets silently get no native window and are
    never painted, with no Tcl or Python error. This is the only visible warning.
    """
    data = process_resources() if resources is None else resources
    worst = [(key.upper(), data[key]) for key in ("user", "gdi") if data.get(key, 0) >= HANDLE_LIMIT * fraction]
    if not worst:
        return None
    return ("Windows is nearly out of window/graphics handles (" + ", ".join(f"{k}={v}/{HANDLE_LIMIT}" for k, v in worst)
            + "). New controls may not be drawn. Save, close and reopen the app, then send logs\\bridge.log.")


def threshold_warnings(data, baseline_widgets):
    out = []
    for key, limit in (("user", WARN_USER_OBJECTS), ("gdi", WARN_GDI_OBJECTS)):
        if data.get(key, 0) >= limit:
            out.append(f"{key.upper()} objects {data[key]} >= {limit} (Windows limit is 10,000/process)")
    if data["widgets"] > baseline_widgets + WARN_WIDGETS:
        out.append(f"Tk widgets grew from {baseline_widgets} to {data['widgets']}")
    if data["after"] > WARN_PENDING_AFTER:
        out.append(f"{data['after']} pending after() callbacks")
    return out


class ResourceSampler:
    """Debug mode: one log line every `interval_ms` and a warning when counts look runaway."""

    def __init__(self, root, interval_ms=30_000):
        self.root, self.interval_ms = root, interval_ms
        self.job = None
        self.baseline = None
        self.warned = set()

    def start(self):
        self.baseline = tk_snapshot(self.root)["widgets"]
        self._tick()

    def stop(self):
        if self.job is not None:
            self.root.after_cancel(self.job)
            self.job = None

    def _tick(self):
        try:
            data = full_snapshot(self.root)
            log.info("resources[sample] %s", format_snapshot(data))
            for warning in threshold_warnings(data, self.baseline):
                if warning.split(" ", 1)[0] not in self.warned:  # once per metric, not once per sample
                    self.warned.add(warning.split(" ", 1)[0])
                    log.warning("resource warning: %s", warning)
        except Exception:
            log.exception("resource sampling failed")
        self.job = self.root.after(self.interval_ms, self._tick)


def warm_up_tk_menu(root):
    """Initialise Tk's lazily-created hidden menu windows at startup.

    Tk 8.6.12 (win/tkWinMenu.c, TkpMenuThreadInit) creates two hidden windows the
    first time the thread sees a menu or WM_SYSCOMMAND/WM_INITMENU/WM_COMMAND/WM_MENUSELECT
    message, and calls Tcl_Panic("Failed to create the menu window") if CreateWindow
    fails. This app creates no menus, so that first use would otherwise happen at a
    random late moment (first minimize/maximize/move/close). Doing it now moves any
    such failure to startup and makes later window-creation failures ordinary
    TclError exceptions that the UI handlers log, instead of a process abort.
    It does NOT cure handle exhaustion; it only makes that failure observable.
    """
    import tkinter as tk
    tk.Menu(root, tearoff=False).destroy()
