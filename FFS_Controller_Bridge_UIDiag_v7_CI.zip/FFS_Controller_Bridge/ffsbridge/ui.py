"""Tkinter editor/monitor; the Tk thread never polls hardware or writes reports."""
from __future__ import annotations

import copy
import json
import logging
from pathlib import Path
import queue
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from . import diagnostics
from .config import ConfigError, parse_json
from .service import BridgeService
from .state import CHANNELS
from . import theme

log = logging.getLogger(__name__)


def pretty(name):
    return name.replace("_", " ").title().replace(" Ms", " (ms)").replace(" Percent", " (%)")


def leaves(schema, value, path=()):
    if schema.get("type") == "object":
        for key, child in schema["properties"].items():
            yield from leaves(child, value[key], path + (key,))
    elif path != ("version",):
        yield path, schema, value


def put(root, path, value):
    for key in path[:-1]:
        root = root[key]
    root[path[-1]] = value


class BridgeApp:
    def __init__(self, root, store, service=None, auto_scan=True):
        self.root, self.store = root, store
        self.settings, self.catalog = store.load()
        self.service = service or BridgeService(store.directory)
        self.devices = []
        self.busy = False
        self.scanning = False
        self.last_service_error = None
        self.closing = False
        self.current_recipe = None
        self.poll_job = None
        self.form_reset_job = None
        self.shown_group = None
        self.io_cache = {}
        self.poll_failure_count = 0
        self.poll_errors = diagnostics.LogThrottle(30.0)
        self.pressure_notices = diagnostics.LogThrottle(60.0)
        self.sampler = self.stall_watch = None
        self.form_vars, self.field_schemas = {}, {}
        self.schema = store.schemas["settings"]
        for path, schema, value in leaves(self.schema, self.settings):
            self.field_schemas[path] = schema
            self.form_vars[path] = (tk.BooleanVar(root, value) if schema.get("type") == "boolean"
                                    else tk.StringVar(root, str(value)))
        theme.apply_theme(root)
        root.title("FFS Controller Bridge — SDL2 → Xbox 360")
        root.geometry("1100x760")
        root.minsize(850, 630)
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.bind("<F12>", lambda _: self.stop())
        self._build()
        self._load_form()
        self._recipes_refresh()
        self._show_group()
        self._poll()
        if log.isEnabledFor(logging.DEBUG):  # --debug only; no cost in normal runs
            self.sampler = diagnostics.ResourceSampler(root)
            self.sampler.start()
            self.stall_watch = diagnostics.StallWatch()
        self._log("Automation is OFF in factory defaults. Preview creates no virtual controller. F12 stops this app when focused.")
        if auto_scan:
            self.scan()

    def _build(self):
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(4, weight=1)
        header = ttk.Frame(outer)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ttk.Label(header, text="FFS  /  CONTROLLER BRIDGE", style="Heading.TLabel").pack(side="left")
        ttk.Label(header, text="SDL2 → Xbox 360", style="Muted.TLabel").pack(side="right")
        top = ttk.Frame(outer)
        top.grid(row=1, column=0, sticky="ew")
        ttk.Label(top, text="Physical input", style="Muted.TLabel").pack(side="left")
        self.device_box = ttk.Combobox(top, state="readonly", width=60)
        self.device_box.pack(side="left", fill="x", expand=True, padx=10)
        self.scan_button = ttk.Button(top, text="Refresh", command=self.scan)
        self.scan_button.pack(side="left")
        control_panel = ttk.Frame(outer, padding=(0, 8))
        control_panel.grid(row=2, column=0, sticky="ew")
        controls = ttk.Frame(control_panel)
        controls.pack(fill="x")
        self.preview = tk.BooleanVar(self.root, True)
        self.preview_box = ttk.Checkbutton(controls, text="Preview (no virtual output)", variable=self.preview)
        self.preview_box.pack(side="left")
        self.start_button = ttk.Button(controls, text="Save & Start", command=self.start, style="Accent.TButton")
        self.start_button.pack(side="left", padx=10)
        self.apply_button = ttk.Button(controls, text="Apply", command=self.apply_changes)
        self.apply_button.pack(side="left")
        ttk.Button(controls, text="STOP / F12", command=self.stop, style="Danger.TButton").pack(side="right")
        runtime_controls = ttk.Frame(control_panel, padding=(0, 8, 0, 0))
        runtime_controls.pack(fill="x")
        self.pause = tk.BooleanVar(self.root, False)
        self.menu = tk.BooleanVar(self.root, False)
        self.pause_box = ttk.Checkbutton(runtime_controls, text="Pause macros", variable=self.pause,
                                        command=lambda: self.service.request("pause", value=self.pause.get()))
        self.pause_box.pack(side="left", padx=8)
        self.menu_box = ttk.Checkbutton(runtime_controls, text="Menu: neutral", variable=self.menu,
                                       command=lambda: self.service.request("menu", value=self.menu.get()))
        self.menu_box.pack(side="left")
        self.corner_button = ttk.Button(runtime_controls, text="Arm/cancel corner", command=lambda: self.service.request("corner"))
        self.corner_button.pack(side="right")
        self.status = tk.StringVar(self.root, "Stopped — select a physical controller explicitly")
        ttk.Label(outer, textvariable=self.status, style="Status.TLabel", wraplength=760).grid(row=3, column=0, sticky="ew", pady=(0, 8))
        self.tabs = ttk.Notebook(outer)
        self.tabs.grid(row=4, column=0, sticky="nsew")
        monitor = ttk.Frame(self.tabs, padding=12)
        settings = ttk.Frame(self.tabs, padding=12)
        recipes = ttk.Frame(self.tabs, padding=12)
        help_tab = ttk.Frame(self.tabs, padding=12)
        logs_tab = ttk.Frame(self.tabs, padding=12)
        self.monitor_tab, self.settings_tab, self.logs_tab = monitor, settings, logs_tab
        for frame, title in ((settings, "Settings"), (monitor, "Live I/O"), (recipes, "JSON recipes"), (logs_tab, "Logs"), (help_tab, "Help")):
            self.tabs.add(frame, text=title)
        ttk.Label(monitor, text="Computed output before Xbox conversion; touchpad/misc1 have no Xbox 360 output equivalent.", style="Muted.TLabel").pack(anchor="w", pady=(0, 8))
        self.io = ttk.Treeview(monitor, columns=("input", "output"), show="tree headings", height=12)
        self.io.heading("#0", text="Channel")
        self.io.heading("input", text="SDL input")
        self.io.heading("output", text="Computed output")
        self.io.column("#0", width=150)
        for key in CHANNELS:
            self.io.insert("", "end", iid=key, text=key.upper(), values=("0.000", "0.000"))
        io_scroll = ttk.Scrollbar(monitor, command=self.io.yview)
        self.io.configure(yscrollcommand=io_scroll.set)
        io_scroll.pack(side="right", fill="y")
        self.io.pack(fill="both", expand=True)
        ttk.Label(settings, text="Changes take effect on Apply or Start. Mapping file/watchdog changes require Stop + Start.", style="Muted.TLabel").pack(anchor="w")
        body = ttk.Frame(settings)
        body.pack(fill="both", expand=True, pady=6)
        self.group_box = tk.Listbox(body, width=17, exportselection=False)
        theme.style_listbox(self.group_box)
        self.groups = ["General", "Movement", "Shots", "Snap", "Passes", "Corner", "Tactics", "Skills"]
        for group in self.groups:
            self.group_box.insert("end", group)
        self.group_box.selection_set(0)
        self.group_box.pack(side="left", fill="y", padx=(0, 10))
        self.group_box.bind("<<ListboxSelect>>", lambda _: self._show_group())
        self.form_canvas = tk.Canvas(body, highlightthickness=0)
        theme.style_canvas(self.form_canvas)
        scrollbar = ttk.Scrollbar(body, orient="vertical", command=self.form_canvas.yview)
        self.form_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.form_canvas.pack(side="left", fill="both", expand=True)
        self.form = ttk.Frame(self.form_canvas)
        self.form_window = self.form_canvas.create_window((0, 0), window=self.form, anchor="nw")
        self.form.bind("<Configure>", self._form_resized)
        self.form_canvas.bind("<Configure>", self._canvas_resized)
        self.root.bind("<MouseWheel>", self._wheel, add=True)
        self.root.bind("<Button-4>", lambda e: self._wheel(e, -3), add=True)
        self.root.bind("<Button-5>", lambda e: self._wheel(e, 3), add=True)
        recipe_top = ttk.Frame(recipes)
        recipe_top.pack(fill="x")
        self.recipe_box = ttk.Combobox(recipe_top, state="readonly")
        self.recipe_box.pack(side="left", fill="x", expand=True)
        self.recipe_box.bind("<<ComboboxSelected>>", self._recipe_selected)
        self.recipe_stage_button = ttk.Button(recipe_top, text="Validate / stage edit", command=self._stage_clicked)
        self.recipe_stage_button.pack(side="left", padx=10)
        ttk.Label(recipes, text="Edit this skill/action as JSON. Save writes all staged edits. scale_percent scales skill durations.", style="Muted.TLabel").pack(anchor="w", pady=8)
        self.recipe_text = ScrolledText(recipes, undo=True, font=("Consolas", 10), wrap="none")
        theme.style_text(self.recipe_text, mono=True)
        self.recipe_text.pack(fill="both", expand=True)
        help_text = ScrolledText(help_tab, wrap="word", font=("Segoe UI", 10))
        theme.style_text(help_text)
        help_text.pack(fill="both", expand=True)
        help_text.insert("1.0", HELP_TEXT + f"\n\nConfig directory:\n{self.store.directory}")
        help_text.configure(state="disabled")
        toolbar = ttk.Frame(outer, padding=(0, 8))
        toolbar.grid(row=5, column=0, sticky="ew")
        self.file_buttons = []
        for title, command in (("Save JSON", self.save), ("Reload files", self.reload),
                               ("Import bundle", self.import_bundle), ("Export bundle", self.export_bundle),
                               ("Factory settings", self.defaults)):
            button = ttk.Button(toolbar, text=title, command=command)
            button.pack(side="left", padx=(0, 6))
            self.file_buttons.append(button)
        ttk.Label(logs_tab, text="Session events and errors", style="Heading.TLabel").pack(anchor="w", pady=(0, 8))
        self.log_box = ScrolledText(logs_tab, height=4, wrap="word", state="disabled")
        theme.style_text(self.log_box, mono=True)
        self.log_box.pack(fill="both", expand=True)
        self._set_busy(False)

    def _wheel(self, event, units=None):
        if str(event.widget).startswith(str(self.form_canvas)):
            bounds = self.form_canvas.bbox("all")
            if not bounds or bounds[3] - bounds[1] <= self.form_canvas.winfo_height():
                self.form_canvas.yview_moveto(0)
                return
            self.form_canvas.yview_scroll(units if units is not None else (-1 if event.delta > 0 else 1) * 3, "units")

    def _combobox_wheel(self, event, units=None):
        self._wheel(event, units)
        return "break"  # stop the class binding that would change the selected value

    def _load_form(self):
        names = {s["id"]: s["name"] for s in self.catalog["skills"]}
        for path, _, value in leaves(self.schema, self.settings):
            if path[:2] == ("skills", "mapping"):
                value = f"{value}: {names.get(value, 'OFF')}"
            self.form_vars[path].set(value)

    def _settings_from_form(self):
        result = copy.deepcopy(self.settings)
        for path, variable in self.form_vars.items():
            schema = self.field_schemas[path]
            value = variable.get()
            try:
                if schema.get("type") == "integer":
                    value = int(str(value).split(":", 1)[0])
                elif schema.get("type") == "number":
                    value = float(value)
            except (ValueError, TypeError) as exc:
                raise ConfigError(f"{'.'.join(path)}: enter a valid {schema['type']}") from exc
            put(result, path, value)
        return result

    def _form_resized(self, event):
        if event.widget is self.form:
            self.form_canvas.configure(scrollregion=self.form_canvas.bbox("all"))

    def _canvas_resized(self, event):
        self.form_canvas.itemconfigure(self.form_window, width=max(1, event.width))

    def _reset_form_view(self):
        self.form_reset_job = None
        # Grid geometry is deferred by Tk. Reset only AFTER it has settled;
        # otherwise the old, taller group's scroll region can survive the swap.
        self.form_canvas.configure(scrollregion=self.form_canvas.bbox("all"))
        self.form_canvas.xview_moveto(0)
        self.form_canvas.yview_moveto(0)

    def _show_group(self):
        selection = self.group_box.curselection()
        group = self.groups[selection[0]] if selection else "General"
        # Build off-screen; never clear the visible form before a replacement
        # is complete. Fresh grid geometry also avoids leftover row/column sizes.
        replacement = ttk.Frame(self.form_canvas)
        try:
            self._build_group(replacement, group)
            missing = diagnostics.widgets_without_native_window(replacement)
        except Exception:
            replacement.destroy()
            self._select_group(self.shown_group)  # the list must keep naming the form still on screen
            raise
        if missing:  # Windows could not create the form's native windows: never show a blank form
            replacement.destroy()
            self._select_group(self.shown_group)
            self._native_window_failure(group, missing)
            return
        previous = self.form
        try:
            replacement.bind("<Configure>", self._form_resized)
            self.form_canvas.itemconfigure(self.form_window, window=replacement)
        except Exception:
            replacement.destroy()
            self._select_group(self.shown_group)
            raise
        self.form = replacement
        self.shown_group = group
        previous.destroy()
        if self.form_reset_job is not None:  # one pending reset is enough; never queue a pile
            self.root.after_cancel(self.form_reset_job)
        self.form_reset_job = self.root.after_idle(self._reset_form_view)
        self._check_handle_pressure()

    def _native_window_failure(self, group, missing):
        text = (f"Windows could not create {len(missing)} window(s) for the {group} settings form, so it was not shown "
                "and the previous form was kept. Window creation failed; resource exhaustion is one possible cause. "
                "Save your settings, close the "
                "app, and send logs\\bridge.log.")
        log.error("%s First widget: %s", text, missing[0])
        diagnostics.log_snapshot(self.root, "native-window-failure", logging.ERROR)
        self._log("ERROR: " + text)
        # Do not create another native dialog while window creation is failing.
        # The existing log tab and file carry the error without allocating a dialog.

    def _check_handle_pressure(self):
        message = diagnostics.handle_pressure()
        if message and self.pressure_notices.error(log, "handles", message, exc_info=False):
            self._log("WARNING: " + message)

    def _select_group(self, group):
        if group in self.groups:
            self.group_box.selection_clear(0, "end")
            self.group_box.selection_set(self.groups.index(group))

    def _build_group(self, form, group):
        roots = {"input", "layout", "shortcuts"} if group == "General" else {group.lower()}
        row, heading = 0, None
        for path, schema in self.field_schemas.items():
            if path[0] not in roots:
                continue
            parent = " / ".join(pretty(k) for k in path[:-1])
            if parent != heading:
                ttk.Label(form, text=parent or group, style="Heading.TLabel").grid(row=row, column=0, columnspan=3, sticky="w", pady=(16, 6))
                heading, row = parent, row + 1
            ttk.Label(form, text=pretty(path[-1])).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=3)
            var = self.form_vars[path]
            if schema.get("type") == "boolean":
                field = ttk.Checkbutton(form, variable=var)
            elif "enum" in schema or path[:2] == ("skills", "mapping"):
                choices = schema.get("enum") or ["0: OFF"] + [f"{s['id']}: {s['name']}" for s in self.catalog["skills"]]
                field = ttk.Combobox(form, textvariable=var, values=choices, state="readonly", width=28)
                # ttk::combobox binds the wheel to "select next/previous value". Inside this
                # scrolling form that silently rewrites skill mappings: scroll the form instead.
                field.bind("<MouseWheel>", self._combobox_wheel)
                field.bind("<Button-4>", lambda e: self._combobox_wheel(e, -3))
                field.bind("<Button-5>", lambda e: self._combobox_wheel(e, 3))
            else:
                field = ttk.Entry(form, textvariable=var, width=28)
            field.grid(row=row, column=1, sticky="ew", pady=3)
            hint = schema.get("description", "")
            if "minimum" in schema:
                hint = f"{schema['minimum']} .. {schema['maximum']}  " + hint
            ttk.Label(form, text=hint, wraplength=330, style="Muted.TLabel").grid(row=row, column=2, sticky="w", padx=10)
            row += 1
        form.columnconfigure(2, weight=1)

    def _recipes_refresh(self):
        self.recipe_keys = [("skills", i) for i in range(len(self.catalog["skills"]))] + [("actions", k) for k in self.catalog["actions"]]
        labels = [f"Skill {s['id']:g} — {s['name']}" for s in self.catalog["skills"]] + [f"Action — {k}" for k in self.catalog["actions"]]
        self.recipe_box.configure(values=labels)
        self.recipe_box.current(0)
        self.current_recipe = self.recipe_keys[0]
        self._render_recipe()

    def _render_recipe(self):
        kind, index = self.current_recipe
        self.recipe_text.configure(state="normal")
        self.recipe_text.delete("1.0", "end")
        self.recipe_text.insert("1.0", json.dumps(self.catalog[kind][index], ensure_ascii=False, indent=2))
        self.recipe_text.edit_reset()

    def _collect(self):
        settings, catalog = self._settings_from_form(), copy.deepcopy(self.catalog)
        if self.current_recipe is not None:
            kind, index = self.current_recipe
            catalog[kind][index] = parse_json(self.recipe_text.get("1.0", "end"))
        self.store.validate(settings, catalog)
        return settings, catalog

    def _recipe_selected(self, _=None):
        selected = self.recipe_box.current()
        try:
            _, catalog = self._collect()
            self.catalog = catalog
            self.current_recipe = self.recipe_keys[selected]
            self._render_recipe()
        except Exception as exc:
            self.recipe_box.current(self.recipe_keys.index(self.current_recipe))
            self._error(exc)

    def _stage_clicked(self):
        try:
            _, self.catalog = self._collect()
            self._log("Recipe validated and staged; click Save JSON to persist.")
        except Exception as exc:
            self._error(exc)

    def apply_changes(self):
        if not self.busy:
            return
        try:
            settings, catalog = self._collect()
            self.service.apply(settings, catalog)
            self.apply_button.configure(state="disabled")
            self._log("Apply requested; current macro will be cancelled. Save JSON separately to persist.")
        except Exception as exc:
            self._error(exc)

    def save(self):
        try:
            settings, catalog = self._collect()
            self.store.save_all(settings, catalog)
            self.settings, self.catalog = settings, catalog
            self._log(f"Saved settings.json and catalog.json in {self.store.directory}")
            return True
        except Exception as exc:
            self._error(exc)
            return False

    def _replace(self, settings, catalog):
        self.settings, self.catalog = settings, catalog
        self._load_form()
        self._recipes_refresh()
        self._show_group()

    def reload(self):
        if self.busy or not messagebox.askyesno("Reload", "Discard unsaved edits and reload JSON files?", parent=self.root):
            return
        try:
            self._replace(*self.store.load())
        except Exception as exc:
            self._error(exc)

    def defaults(self):
        if self.busy or not messagebox.askyesno("Factory settings", "Reset settings (automation OFF)? Your catalog is kept. Click Save to persist.", parent=self.root):
            return
        self._replace(self.store.defaults(), self.catalog)

    def import_bundle(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(parent=self.root, filetypes=[("JSON bundle", "*.json")])
        if path:
            try:
                self._replace(*self.store.read_bundle(Path(path)))
                self._log("Bundle loaded into editor. Click Save to persist.")
            except Exception as exc:
                self._error(exc)

    def export_bundle(self):
        if self.busy:
            return
        path = filedialog.asksaveasfilename(parent=self.root, defaultextension=".json", initialfile="ffs-bundle.json", filetypes=[("JSON bundle", "*.json")])
        if path:
            try:
                self.store.export(Path(path), *self._collect())
                self._log(f"Exported {path}")
            except Exception as exc:
                self._error(exc)

    def scan(self):
        if self.busy or self.scanning:
            return
        self.scanning = True
        self.last_service_error = None
        self.scan_button.configure(state="disabled")
        self.start_button.configure(state="disabled")
        self.status.set("Scanning SDL controllers…")
        self.service.request("scan", mapping_file=self.form_vars[("input", "mapping_file")].get())

    def start(self):
        index = self.device_box.current()
        if self.busy or self.scanning:
            return
        if index < 0 or index >= len(self.devices):
            self._error("Select a physical controller first. Never select another bridge's virtual output.")
            return
        if not self.devices[index].mapped:
            self._error("This controller needs an SDL mapping. Set input.mapping_file, then Refresh.")
            return
        if not self.preview.get() and not messagebox.askokcancel("Create virtual Xbox 360", "The selected input must be a PHYSICAL controller. Avoid running other remappers.\n\nGames may see both physical and virtual input unless you configure device hiding.\n\nStart real virtual output?", parent=self.root):
            return
        if self.save():
            self.last_service_error = None
            self._set_busy(True)
            self.pause.set(False)
            self.menu.set(False)
            self.status.set("Starting…")
            try:
                self.service.start(self.devices[index], self.settings, self.catalog, self.preview.get())
            except Exception as exc:
                self._set_busy(False)
                self._error(exc)

    def stop(self):
        self._set_busy(True)
        self.service.stop()
        self.apply_button.configure(state="disabled")
        self.status.set("Stopping / requesting neutral output…")

    def _disable_tree(self, widget, disabled):
        for child in widget.winfo_children():
            if isinstance(child, (ttk.Entry, ttk.Combobox, ttk.Checkbutton, ttk.Button)):
                child.configure(state="disabled" if disabled else "readonly" if isinstance(child, ttk.Combobox) else "normal")
            self._disable_tree(child, disabled)

    def _set_busy(self, busy):
        self.busy = busy
        for widget in [self.start_button, self.scan_button, self.preview_box, *self.file_buttons[1:]]:
            widget.configure(state="disabled" if busy else "normal")
        self.device_box.configure(state="disabled" if busy else "readonly")
        self.recipe_box.configure(state="readonly")
        self.apply_button.configure(state="normal" if busy else "disabled")
        for widget in (self.pause_box, self.menu_box, self.corner_button):
            widget.configure(state="normal" if busy else "disabled")
        self.recipe_text.configure(state="normal")
        self._disable_tree(self.form, False)

    def _poll(self):
        if self.closing:
            return
        if self.stall_watch is not None:
            self.stall_watch.beat()
        try:
            self._poll_events()
        except Exception:
            # One Tk callback error must not permanently stop service events. The first
            # traceback is logged in full; a persistent fault is then throttled, not repeated at 20 Hz.
            self.poll_failure_count += 1
            self.poll_errors.error(log, "poll", "UI event processing failed")
        finally:
            if not self.closing:
                self.poll_job = self.root.after(50, self._poll)

    def _poll_events(self):
        while True:
            try:
                event = self.service.events.get_nowait()
            except queue.Empty:
                break
            kind = event["type"]
            if kind == "devices":
                index = self.device_box.current()
                selected = self.devices[index] if 0 <= index < len(self.devices) else None
                self.devices = event["devices"]
                self.device_box.configure(values=[d.label for d in self.devices])
                self.device_box.set("")
                # Preserve only the exact explicitly selected device. Never fall
                # back to an index/name (which could now be a virtual output).
                for i, device in enumerate(self.devices):
                    if selected is not None and device == selected:
                        self.device_box.current(i)
                        break
                self.scanning = False
                self._set_busy(self.busy)
                self.status.set(f"{len(self.devices)} controller(s). Select the physical input explicitly.")
            elif kind == "running":
                self._set_busy(True)
                self._log(("PREVIEW" if event["preview"] else "VIRTUAL XBOX") + ": " + event["device"])
            elif kind == "stopped":
                self.scanning = False
                self._set_busy(False)
                self.pause.set(False)
                self.menu.set(False)
                self.status.set("Stopped — " + self.last_service_error if self.last_service_error
                                else "Stopped — ready to Start again")
            elif kind in ("applied", "apply_rejected"):
                self.apply_button.configure(state="normal" if self.busy else "disabled")
                self._log("Settings applied; active macro cancelled." if kind == "applied" else event["message"])
            elif kind == "error":
                self.last_service_error = event["message"]
                self._log("ERROR: " + event["message"])
                self.status.set("Error — " + event["message"])
                self.tabs.select(self.logs_tab)  # Make diagnostics visible instead of hiding them.
            elif kind == "setting":
                path = tuple(event["path"])
                put(self.settings, path, event["value"])
                self.form_vars[path].set(event["value"])
                try:
                    self.store.save_settings(self.settings, self.catalog)
                    self._log("Shortcut saved: " + ".".join(path) + " = " + str(event["value"]))
                except Exception as exc:
                    self._log(f"ERROR saving shortcut (runtime changed only): {exc}")
            elif kind == "menu" and event["value"]:
                self.tabs.select(self.settings_tab)
        snapshot = self.service.snapshot()
        # Write a widget variable only when its value changed: at 20 Hz an unconditional
        # set() invalidates and repaints the same label/checkbuttons every time.
        if snapshot["running"]:
            self._set_var(self.pause, snapshot["paused"])
            self._set_var(self.menu, snapshot["menu"])
            self._set_var(self.status, ("PREVIEW | " if self.preview.get() else "VIRTUAL XBOX | ") + snapshot["activity"]
                          + (" | CORNER ARMED" if snapshot["corner"] else ""))
        if self.tabs.select() == str(self.monitor_tab):  # the table is invisible on other tabs
            for key in CHANNELS:
                values = (f"{snapshot['input'][key]:+.3f}", f"{snapshot['output'][key]:+.3f}")
                if self.io_cache.get(key) != values:
                    self.io.item(key, values=values)
                    self.io_cache[key] = values

    @staticmethod
    def _set_var(variable, value):
        if variable.get() != value:
            variable.set(value)

    def _log(self, message):
        log.info(message)
        self.log_box.configure(state="normal")
        self.log_box.insert("end", time.strftime("%H:%M:%S ") + message + "\n")
        if int(self.log_box.index("end-1c").split(".")[0]) > 200:
            self.log_box.delete("1.0", "50.0")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _error(self, error):
        self._log("ERROR: " + str(error))
        messagebox.showerror("FFS Controller Bridge", str(error), parent=self.root)

    def close(self):
        if self.closing:
            return
        if not self.closing:
            try:
                settings, catalog = self._collect()
                disk_settings, disk_catalog = self.store.load()
                dirty = settings != disk_settings or catalog != disk_catalog
            except Exception:
                dirty = True
            if dirty:
                choice = messagebox.askyesnocancel("Unsaved edits", "Save edits before closing?", parent=self.root)
                if choice is None or (choice and not self.save()):
                    return
        self.closing = True
        if self.poll_job is not None:
            self.root.after_cancel(self.poll_job)
        if self.form_reset_job is not None:
            self.root.after_cancel(self.form_reset_job)
            self.form_reset_job = None
        if self.sampler is not None:
            self.sampler.stop()
        if self.stall_watch is not None:
            self.stall_watch.stop()
        diagnostics.log_snapshot(self.root, "closing")
        self.service.shutdown()
        self.status.set("Closing — releasing virtual controls…")
        self.close_deadline = time.monotonic() + 4
        self.root.after(50, self._finish_close)

    def _finish_close(self):
        if not self.service.alive:
            self.root.destroy()
        elif time.monotonic() >= self.close_deadline:
            messagebox.showwarning("Driver/input thread unresponsive", "Could not confirm neutral output or device removal. The app will exit. Check Windows controllers before using the game.", parent=self.root)
            self.root.destroy()
        else:
            self.root.after(50, self._finish_close)


HELP_TEXT = """FIRST RUN
1. Connect a physical controller, Refresh, then explicitly select it.
2. Leave Preview ON and inspect Live I/O. Preview creates NO virtual device.
3. Start with factory settings: all macros, shortcuts and skill mappings are OFF.
4. Stop, enable only the desired features, then Save & Start again.
5. For real output, use Windows + vgamepad + a working ViGEmBus driver. Turn Preview OFF.

BUTTON NAMES (Xbox / PlayStation position)
a = A / Cross; b = B / Circle; x = X / Square; y = Y / Triangle
lb/rb = L1/R1; lt/rt = L2/R2; ls/rs = L3/R3; back/start = Share/Options.
Layout classic uses B for Shoot, X for Cross; alternate swaps them.
Touchpad and misc1 can trigger recipes, but Xbox 360 cannot emit these buttons.

OPTIONAL SHORTCUTS (enable shortcuts.enabled)
LT + Start: toggle neutral menu mode; LT + Back: pause/resume macros.
LT + Up: arm/cancel corner; LT + Left: toggle shot master switch.
LT + Down: toggle flair Snap Aim. Shot master also requires per-profile enable.
Other D-pad actions require their own setting: Left team press; Up offside;
Right run+lob (default trigger). One-touch low driven defaults to L3, OFF initially.
LT + RT > 90%: temporary macro bypass/cancel, regardless of shortcut setting.
Pause passes physical controls through. Menu outputs neutral. Stop closes output.

SKILLS / JSON
Map each right-stick direction (relative to screen, not player) to a catalog ID.
Return the right stick to center before the next flick. Recipes rotate to the last
left-stick facing direction (default UP). R3 maps to a skill only with RS centered.
Skills will not start while an action/aim/corner is active. Physical shot/pass cancels a skill.
Recipes use duration_ms and set; channels not set inherit the physical state.
ls_local / rs_local vectors are [right, forward], rotated to facing. mirror_trigger
mirrors local X for left-side flicks. scale_percent changes skill timing.
The complete JSON catalog, not the original GPC, is used at runtime.

SAFETY / COMPATIBILITY
Source instance is pinned before creating output. Disconnect/error/watchdog expiry
stops the session; reconnect requires explicit Refresh/selection/Start.
Other apps' virtual controllers can appear in SDL: NEVER select them as input.
HidHide can prevent double input; allow this app to see physical input, hide it
from the game, and do not hide the virtual Xbox device. No automatic driver changes.
No rumble forwarding, gyro, touch gestures, adaptive triggers or arbitrary DirectInput
mapping editor. Unknown joysticks require a compatible SDL GameController mapping.
A frozen driver/OS/process cannot be made safe by a Python watchdog alone.
This app has no game/screen awareness. 'Perfect' features are timed macros, not
accuracy guarantees. Game skill requirements, settings and timing still matter.
Use where automation is permitted; game rules may restrict macros.
"""
