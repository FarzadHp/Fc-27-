import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from tools import ci_checks
from tools.ci_checks import source_manifest
from tools.repro_menu_panic import classify


class EvidenceTests(unittest.TestCase):
    def test_cold_requires_exhaustion_and_matching_crash(self):
        self.assertTrue(classify('cold', 2147483651, 'USER objects: 10000', 'Failed to create the menu window')['experiment_valid'])
        self.assertFalse(classify('cold', 1, '', 'ImportError')['experiment_valid'])
        self.assertFalse(classify('cold', 0, 'USER objects: 10000', 'Failed to create the menu window')['experiment_valid'])

    def test_warm_requires_detector_output(self):
        text = 'USER objects: 10000\nRESULT: no panic'
        self.assertFalse(classify('warm', 0, text, '')['experiment_valid'])
        report = classify('warm', 0, text + '\ndetector widgets_without_native_window: []', '')
        self.assertTrue(report['experiment_valid'])
        self.assertFalse(report['application_fix_proven'])

    def test_ci_retains_all_results_and_fails_on_one_failed_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            runs = [SimpleNamespace(returncode=0) for _ in range(9)]
            runs[2] = SimpleNamespace(returncode=1)
            with patch.object(ci_checks, '__file__', str(root / 'tools' / 'ci_checks.py')), \
                    patch.object(ci_checks.os, 'chdir'), \
                    patch.object(ci_checks.subprocess, 'run', side_effect=runs) as run, \
                    patch('builtins.print'):
                self.assertEqual(ci_checks.main(), 1)
            self.assertEqual(run.call_count, 9)
            self.assertTrue((root / 'out' / 'ci-summary.json').exists())

    def test_manifest_changes_with_source_not_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            file = root / 'app.py'
            file.write_text('old')
            before = source_manifest(root)
            (root / 'out').mkdir()
            (root / 'out' / 'log.txt').write_text('report')
            self.assertEqual(before, source_manifest(root))
            file.write_text('new')
            self.assertNotEqual(before, source_manifest(root))
