"""Run all Windows checks, retaining evidence and failing on any required failure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def source_manifest(root):
    return {str(p.relative_to(root)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file()
            and not any(x in {'out', '__pycache__', '.git', '.venv', 'build', 'dist'}
                        for x in p.relative_to(root).parts)}


def main():
    root = Path(__file__).resolve().parents[1]
    os.chdir(root)
    out = root / 'out'
    out.mkdir(exist_ok=True)
    (out / 'source-manifest.json').write_text(json.dumps(source_manifest(root), indent=2), encoding='utf-8')
    py = sys.executable
    checks = [
        ('01_install', ['-m', 'pip', 'install', 'jsonschema==4.26.0', 'PySDL2==0.9.17', 'pysdl2-dll==2.32.10']),
        ('02_env', ['-c', "import sys, tkinter as tk; r=tk.Tk(); print(sys.version); print('Tk',r.tk.call('info','patchlevel')); r.destroy()"]),
        ('03_unit_tests', ['-m', 'unittest', 'discover', '-s', 'tests', '-v']),
        ('04_stress_ui', ['tools/stress_ui.py', '--mode', 'fake', '--interactions', '800', '--warmup', '80', '--step-ms', '10', '--out', 'out/stress_ui']),
        ('05_gui_stress', ['tools/gui_stress.py', '--cycles', '300', '--applies', '50', '--csv', 'out/gui_stress.csv']),
        ('06_repro_cold', ['tools/repro_menu_panic.py', 'cold', '--out', 'out/repro_cold']),
        ('07_repro_warm', ['tools/repro_menu_panic.py', 'warm', '--out', 'out/repro_warm']),
        ('08_sdl_probe', ['tools/sdl_handle_probe.py', '--iterations', '300']),
        ('09_stress_long', ['tools/stress_ui.py', '--mode', 'fake', '--interactions', '3000', '--warmup', '100', '--step-ms', '5', '--seed', '2', '--out', 'out/stress_long']),
    ]
    results = {}
    for name, args in checks:
        with (out / (name + '.txt')).open('w', encoding='utf-8') as stream:
            try:
                run = subprocess.run([py, *args], stdout=stream, stderr=subprocess.STDOUT, timeout=600)
                results[name] = {'exit_code': run.returncode, 'command': [py, *args]}
            except (OSError, subprocess.TimeoutExpired) as exc:
                stream.write(str(exc))
                results[name] = {'exit_code': 2, 'error': str(exc)}
        print(name, results[name], flush=True)
        (out / 'ci-summary.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    return int(any(item['exit_code'] != 0 for item in results.values()))


if __name__ == '__main__':
    raise SystemExit(main())
