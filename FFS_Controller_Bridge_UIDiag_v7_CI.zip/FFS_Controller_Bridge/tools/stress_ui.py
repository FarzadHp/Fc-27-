"""UI stress test: hundreds of real interactions inside the real Tk event loop.

Every step is an after() callback in root.mainloop() (no update() polling), driving the
same widgets and events a person would: group switches, wheel scrolling, Apply,
Start/Stop, Refresh, resize, minimize/restore, tab changes. Resources are sampled
before, during and after: Tk widgets/after/commands/threads and, on Windows,
USER/GDI objects, handles and native HWNDs.

Modes (they are deliberately separate):
  fake            default. Fake controller + Preview output. No hardware, no driver.
  preview-device  real SDL controller (--device-label) + Preview output. NO virtual controller.
  real-output     real SDL controller + REAL virtual Xbox 360 (needs --confirm-real-output).

A PASS means "no growth beyond the thresholds in this run". It is not proof that a
handle leak or a native crash cannot happen; read the CSV and the logs too.
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import math
import random
import shutil
import traceback
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.stress_evidence import EvidenceQueue, evidence_problems

GROUPS = ["General", "Movement", "Shots", "Snap", "Passes", "Corner", "Tactics", "Skills"]
CHARGE = ("passes", "pass", "charge_ms")
ACTIONS = (("group", 38), ("wheel", 14), ("combo_wheel", 4), ("tab", 10), ("resize", 8),
           ("minimize", 4), ("apply", 10), ("refresh", 4), ("startstop", 8))
COLUMNS = ["step", "seconds", "action", "widgets", "after", "commands", "globals", "threads",
           "user", "gdi", "user_peak", "gdi_peak", "handles", "hwnd"]


def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--mode", choices=("fake", "preview-device", "real-output"), default="fake")
    p.add_argument("--interactions", type=int, default=600)
    p.add_argument("--step-ms", type=int, default=20, help="delay between interactions")
    p.add_argument("--sample-every", type=int, default=25)
    p.add_argument("--warmup", type=int, default=60, help="interactions before the reference sample")
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--device-label", help="substring of the PHYSICAL controller label (non-fake modes)")
    p.add_argument("--confirm-real-output", action="store_true", help="required for --mode real-output")
    p.add_argument("--watchdog-ms", type=int, default=1000)
    p.add_argument("--max-handle-growth", type=int, default=50, help="allowed USER/GDI/HWND growth after warm-up")
    p.add_argument("--out", type=Path, help="output directory (default: ./stress-results/<timestamp>)")
    return p


class FakeInput:
    """Hardware-free stand-in for SDLInput (same methods the service uses)."""

    def __init__(self):
        from ffsbridge.input_sdl import Device
        self.device = Device(17, "Stress fake controller", "0123456789abcdef", True)
        self.opened = None

    def load_mappings(self, path):
        pass

    def devices(self):
        return [self.device]

    def open(self, device):
        self.opened = device
        return device

    def read(self, deadzone):
        from ffsbridge.state import PadState
        return PadState.from_values(lx=math.sin(time.monotonic()), a=float(int(time.monotonic()) % 2))

    def close_device(self):
        self.opened = None

    def close(self):
        pass


class Stress:
    def __init__(self, args):
        self.args = args
        self.rng = random.Random(args.seed)
        self.samples, self.notes, self.dialogs, self.errors = [], [], [], []
        self.step_no, self.started = 0, time.monotonic()
        self.out = args.out or Path("stress-results") / time.strftime("%Y%m%d-%H%M%S")
        self.out.mkdir(parents=True, exist_ok=True)
        self.reference_taken = False
        self.counts = collections.Counter()
        self.events = EvidenceQueue()
        self.apply_pending = None
        self.cleanup_errors = []

    # ------------------------------------------------------------------ setup
    def build(self):
        import tkinter as tk
        from tkinter import messagebox
        from ffsbridge import diagnostics, launcher
        from ffsbridge.config import ConfigStore
        from ffsbridge.service import BridgeService
        from ffsbridge.ui import BridgeApp

        self.tk, self.diagnostics = tk, diagnostics
        # A modal dialog would freeze an unattended run: record it instead of showing it.
        for name in ("showerror", "showwarning", "showinfo"):
            setattr(messagebox, name, lambda title=None, message=None, _n=name, **kw: self.dialogs.append((_n, message)))
        messagebox.askyesno = lambda *a, **kw: False
        messagebox.askyesnocancel = lambda *a, **kw: False   # on close: do not save the stress edits
        messagebox.askokcancel = lambda *a, **kw: bool(self.args.confirm_real_output)

        self.config_dir = Path(tempfile.mkdtemp(prefix="ffs-stress-"))
        store = ConfigStore(self.config_dir)
        factory = FakeInput if self.args.mode == "fake" else None
        self.root = tk.Tk()
        self.service = BridgeService(self.config_dir, input_factory=factory) if factory else BridgeService(self.config_dir)
        self.service.events = self.events
        self.root.report_callback_exception = launcher.tk_callback_reporter(self.root, self.service, self.errors)
        diagnostics.warm_up_tk_menu(self.root)
        self.app = BridgeApp(self.root, store, self.service, auto_scan=False)
        self.app.form_vars[("input", "watchdog_ms")].set(str(self.args.watchdog_ms))
        self.app.preview.set(self.args.mode != "real-output")
        self.system = self.root.tk.call("tk", "windowingsystem")

    # ------------------------------------------------------------------ measuring
    def sample(self, action=""):
        data = self.diagnostics.full_snapshot(self.root)
        row = {"step": self.step_no, "seconds": round(time.monotonic() - self.started, 1), "action": action, **data}
        self.samples.append(row)
        return row

    # ------------------------------------------------------------------ interactions
    def running(self):
        return self.service.snapshot()["running"]

    def pick_device(self):
        label = self.args.device_label
        for index, device in enumerate(self.app.devices):
            if (label is None or label.lower() in device.label.lower()) and device.mapped:
                self.app.device_box.current(index)
                return True
        return False

    def act_group(self):
        group = self.rng.choice(GROUPS)
        box = self.app.group_box
        box.selection_clear(0, "end")
        box.selection_set(GROUPS.index(group))
        box.event_generate("<<ListboxSelect>>")
        return group

    def wheel(self, widget, direction):
        if self.system == "x11":
            widget.event_generate("<Button-5>" if direction > 0 else "<Button-4>")
        else:
            widget.event_generate("<MouseWheel>", delta=-120 * direction)

    def act_wheel(self):
        for _ in range(self.rng.randint(1, 6)):
            self.wheel(self.app.form_canvas, self.rng.choice((-1, 1)))
        return "form"

    def act_combo_wheel(self):
        combos = [w for w in self.app.form.winfo_children() if w.winfo_class() == "TCombobox"]
        if not combos:
            return "no-combobox"
        box = self.rng.choice(combos)
        before = box.get()
        self.wheel(box, 1)
        if box.get() != before:
            self.notes.append(f"step {self.step_no}: wheel over a combobox changed its value")
        return "combobox"

    def act_tab(self):
        self.app.tabs.select(self.rng.randrange(5))
        return "tab"

    def act_resize(self):
        self.root.geometry(f"{self.rng.randint(850, 1400)}x{self.rng.randint(630, 900)}")
        return "resize"

    def act_minimize(self):
        self.root.iconify()
        self.root.after(150, self.root.deiconify)
        return "minimize/restore"

    def act_apply(self):
        if not (self.app.busy and self.running() and str(self.app.apply_button["state"]) == "normal"):
            return "apply-skipped"
        self.app.form_vars[CHARGE].set(str(self.rng.randint(100, 400)))
        before = sum(e.get('type') == 'applied' for e in self.events.evidence())
        self.app.apply_button.invoke()
        self.apply_pending = (before, time.monotonic())
        return "apply"

    def act_refresh(self):
        if self.app.busy or self.app.scanning:
            return "refresh-skipped"
        self.app.scan()
        return "refresh"

    def act_startstop(self):
        if self.app.scanning:
            return "startstop-skipped"
        if self.app.busy:
            if self.running():
                self.app.stop()
                return "stop"
            return "startstop-waiting"
        if self.app.device_box.current() < 0 and not self.pick_device():
            if not self.app.devices:
                self.app.scan()
                return "refresh(for start)"
            self.notes.append("no matching physical controller; check --device-label")
            return "start-impossible"
        self.app.start()
        return "start"

    def next_action(self):
        names, weights = zip(*ACTIONS)
        return self.rng.choices(names, weights)[0]

    def step(self):
        if self.app.poll_failure_count:
            return self.finish("UI event polling failed", 2)
        if self.app.last_service_error or any(e.get('type') in ('error', 'apply_rejected') for e in self.events.evidence()):
            return self.finish("Service error or rejected Apply", 2)
        if self.errors:
            return self.finish("Tk callback exception (see logs/bridge.log)", 2)
        if self.apply_pending is not None:
            before, started = self.apply_pending
            acknowledged = sum(e.get('type') == 'applied' for e in self.events.evidence())
            if acknowledged <= before:
                if time.monotonic() - started > 10:
                    return self.finish("Apply acknowledgement timed out", 2)
                return self.root.after(20, self.step)
            self.apply_pending = None
        if self.step_no >= self.args.interactions:
            return self.settle(self.finish_run)
        if self.step_no == self.args.warmup and not self.reference_taken:
            self.reference_taken = True
            return self.settle(self.take_reference)
        try:
            name = self.act_startstop() if self.step_no == 0 else getattr(self, "act_" + self.next_action())()
        except self.tk.TclError as exc:  # an action failing is a finding, not something to hide
            self.notes.append(f"step {self.step_no}: TclError {exc}")
            return self.finish(f"TclError during interaction {self.step_no}: {exc}", 2)
        self.step_no += 1
        self.counts[name if name in ('start', 'stop', 'apply', 'refresh') or name.endswith('skipped') else name.split('/')[0]] += 1
        if self.step_no % self.args.sample_every == 0:
            self.sample(name)
        self.root.after(self.args.step_ms, self.step)

    def settle(self, then):
        """Stop, return to ONE fixed state (Passes, tab 0, 1100x760), let timers drain, then call `then`.

        Reference and final samples are both taken in this state, so counts are comparable.
        """
        self.settle_then, self.settle_started = then, None
        self.settle_step()

    def settle_step(self):
        if self.settle_started is None:
            self.settle_started = time.monotonic()
            if self.app.busy:
                self.app.stop()
            self.root.deiconify()
            self.root.geometry("1100x760")
            self.app.tabs.select(0)
            box = self.app.group_box
            box.selection_clear(0, "end")
            box.selection_set(GROUPS.index("Passes"))
            box.event_generate("<<ListboxSelect>>")
            return self.root.after(2500, self.settle_step)
        if self.app.busy or self.app.scanning:
            if time.monotonic() - self.settle_started > 15:
                return self.finish("Stop/Refresh did not complete within 15 s", 2)
            return self.root.after(200, self.settle_step)
        if self.errors or self.app.poll_failure_count:
            return self.finish("Callback/poll failure while settling", 2)
        if not (self.app.form.winfo_ismapped() and self.app.form.winfo_height() > 1 and self.app.form.winfo_children()):
            return self.finish("Settings form is not visible after settling", 2)
        self.settle_then()

    def take_reference(self):
        self.sample("reference")
        self.root.after(0, self.step)

    def finish_run(self):
        self.sample("final")
        self.close_started = time.monotonic()
        self.app.close()  # the real close path, including worker shutdown
        self.root.after(200, self.after_close)

    def after_close(self):
        if self.service.alive:
            if time.monotonic() - self.close_started > 10:
                return self.finish("Shutdown timed out", 2)
            return self.root.after(200, self.after_close)
        self.finish(None, None)

    # ------------------------------------------------------------------ result
    def finish(self, failure, code):
        self.failure, self.code = failure, code
        try:
            self.root.quit()
        except self.tk.TclError:
            pass

    def run(self):
        from ffsbridge import diagnostics, launcher
        with launcher.session_logging(self.out / "logs", debug=True) as log_path:
            diagnostics.enable_faulthandler(self.out / "logs")
            self.failure = self.code = None
            try:
                self.build()
                self.root.after(300, self.begin)
                self.root.mainloop()
            except Exception:
                self.failure = traceback.format_exc()
            finally:
                service = getattr(self, 'service', None)
                if service is not None:
                    try:
                        service.shutdown()
                        deadline = time.monotonic() + 10
                        while service.alive and time.monotonic() < deadline:
                            time.sleep(0.02)
                        if service.alive or service.snapshot()['running']:
                            self.cleanup_errors.append('Worker/output shutdown not confirmed')
                    except Exception:
                        self.cleanup_errors.append(traceback.format_exc())
                app = getattr(self, 'app', None)
                if app is not None:
                    app.closing = True
                    if app.sampler is not None:
                        app.sampler.stop()
                    if app.stall_watch is not None:
                        app.stall_watch.stop()
                if hasattr(self, 'root'):
                    try:
                        self.root.destroy()
                    except self.tk.TclError:
                        pass  # normal close may have already destroyed it
                diagnostics.disable_faulthandler()
                if hasattr(self, 'config_dir'):
                    try:
                        shutil.rmtree(self.config_dir)
                    except OSError as exc:
                        self.cleanup_errors.append(f'Temporary directory cleanup: {exc}')
        return self.report(log_path)

    def begin(self):
        if not hasattr(self, 'begin_started'):
            self.begin_started = time.monotonic()
            self.initial_start_requested = False
        if time.monotonic() - self.begin_started > 15:
            return self.finish('Initial scan/Preview start timed out', 2)
        if self.errors or self.app.poll_failure_count or self.app.last_service_error:
            return self.finish('Initial scan/start failed', 2)
        if not self.app.devices and not self.app.scanning:
            self.app.scan()
        if self.app.scanning:
            return self.root.after(100, self.begin)
        if not self.initial_start_requested:
            if not self.pick_device():
                return self.finish('No matching controller', 2)
            self.app.start()
            self.counts['start'] += 1
            self.initial_start_requested = True
        if not self.running() or str(self.app.apply_button['state']) != 'normal':
            return self.root.after(50, self.begin)
        self.sample("before")
        # Guarantee at least one actual Apply, even for short randomized runs.
        action = self.act_apply()
        self.counts[action] += 1
        self.root.after(0, self.step)

    def report(self, log_path):
        with open(self.out / "samples.csv", "w", newline="") as handle:
            writer = csv.DictWriter(handle, COLUMNS, extrasaction="ignore", restval="")
            writer.writeheader()
            writer.writerows(self.samples)
        verdict, problems = "ERROR" if self.failure else "PASS", [self.failure] if self.failure else []
        reference = next((s for s in self.samples if s["action"] == "reference"), None)
        final = self.samples[-1] if self.samples else None
        if not self.failure and reference and final and final["action"] == "final":
            limit = self.args.max_handle_growth
            for key in ("user", "gdi", "hwnd"):
                if key in final and final[key] - reference[key] > limit:
                    problems.append(f"{key} grew {reference[key]} -> {final[key]} (> {limit}) after warm-up")
            if final["widgets"] != reference["widgets"]:
                problems.append(f"Tk widgets {reference['widgets']} -> {final['widgets']} in the same fixed state")
            if final["after"] > reference["after"] + 2:
                problems.append(f"pending after() {reference['after']} -> {final['after']}")
            if final["commands"] > reference["commands"] + 10:
                problems.append(f"Tcl commands {reference['commands']} -> {final['commands']}")
            if final["threads"] > reference["threads"]:
                problems.append(f"threads {reference['threads']} -> {final['threads']}")
            verdict = "FAIL" if problems else "PASS"
        elif not self.failure:
            verdict, problems = "ERROR", ["no reference/final sample (is --warmup smaller than --interactions?)"]
        evidence = evidence_problems(self.events.evidence(), self.counts['apply'])
        evidence += self.cleanup_errors
        evidence += [f'Tk callback error: {error}' for error in self.errors]
        evidence += [f'Suppressed dialog: {dialog}' for dialog in self.dialogs if dialog[0] in ('showerror', 'showwarning')]
        app = getattr(self, 'app', None)
        if app is not None and app.poll_failure_count:
            evidence.append(f'UI poll failures: {app.poll_failure_count}')
        if evidence:
            problems.extend(evidence)
            verdict = 'ERROR' if self.failure else 'FAIL'
        native = [m for _, m in self.dialogs if m and "could not create" in str(m)]
        if native:  # a rejected form means Windows ran out of window handles during the run
            problems.append(f"{len(native)} form(s) rejected: Windows could not create native windows")
            verdict = "FAIL" if verdict == "PASS" else verdict
        problems += self.notes[:20]
        summary = {"verdict": verdict, "mode": self.args.mode, "interactions": self.step_no,
                   "seed": self.args.seed, "actions": dict(self.counts), "problems": problems, "dialogs_suppressed": len(self.dialogs),
                   "worker_error": getattr(app, 'last_service_error', None), "apply_acknowledged": sum(e.get('type') == 'applied' for e in self.events.evidence()), "log": str(log_path), "csv": str(self.out / "samples.csv")}
        (self.out / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False))
        print(f"\n{'step':>6} {'sec':>6} {'widg':>5} {'after':>5} {'cmds':>5} {'thr':>4} {'USER':>6} {'GDI':>6} {'hndl':>6} {'HWND':>5}  action")
        middle = [s for s in self.samples[1:-1] if s["action"] != "reference"]
        shown = ([self.samples[0]] + ([reference] if reference else []) + middle[::max(1, len(middle) // 6)]
                 + self.samples[-1:]) if self.samples else []
        shown.sort(key=lambda row: row["seconds"])
        for s in shown:
            print(f"{s['step']:>6} {s['seconds']:>6} {s['widgets']:>5} {s['after']:>5} {s['commands']:>5} {s['threads']:>4} "
                  f"{s.get('user', '-'):>6} {s.get('gdi', '-'):>6} {s.get('handles', '-'):>6} {s.get('hwnd', '-'):>5}  {s['action']}")
        print("\nActions performed:", dict(self.counts))
        print(f"RESULT: {verdict}  ({self.step_no} interactions, mode={self.args.mode})")
        for problem in problems:
            print("  -", problem)
        if self.dialogs:
            print(f"  - {len(self.dialogs)} dialog(s) were suppressed during the run; first: {self.dialogs[0]}")
        if summary["worker_error"]:
            print("  - last service error:", summary["worker_error"])
        print(f"Files: {self.out}")
        return {"PASS": 0, "FAIL": 1}.get(verdict, 2)


def main(argv=None):
    args = parser().parse_args(argv)
    if args.interactions <= 0 or not 0 <= args.warmup < args.interactions or args.sample_every <= 0 or args.step_ms < 0 or args.max_handle_growth < 0:
        print('Invalid counts: require interactions > warmup >= 0, sample-every > 0, nonnegative delays/thresholds.')
        return 2
    if args.mode == "real-output" and not args.confirm_real_output:
        print("real-output creates a REAL virtual Xbox 360 controller. Re-run with --confirm-real-output.")
        return 2
    if args.mode != "fake" and not args.device_label:
        print("Non-fake modes need --device-label <text of the PHYSICAL controller>; never pick a virtual output.")
        return 2
    return Stress(args).run()


if __name__ == "__main__":
    raise SystemExit(main())
