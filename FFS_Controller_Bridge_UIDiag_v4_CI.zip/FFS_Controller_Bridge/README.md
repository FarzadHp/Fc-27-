# FFS Controller Bridge

پل کنترلر: **SDL2 → ماکروهای JSON → Xbox 360 مجازی در Windows**.
کاتالوگ شامل ۹۲ مهارت است. در زمان اجرا نیازی به فایل GPC نیست؛ قابلیت‌های خودکار در تنظیمات کارخانه خاموش‌اند. Preview پیش‌فرض رابط است و هیچ کنترلر مجازی ایجاد نمی‌کند.

## شروع سریع Windows

1. فایل ZIP را در یک پوشهٔ قابل‌نوشتن استخراج کنید.
2. Python **3.11 x64** را با Tcl/Tk، pip و Python Launcher نصب کنید.
3. `setup_windows.cmd` را اجرا کنید؛ دریافت وابستگی‌ها اینترنت می‌خواهد.
4. `run_windows.cmd` را اجرا کنید و ابتدا با Preview آزمایش کنید.

نصب وابستگی‌ها **درایور نصب نمی‌کند**. خروجی واقعی به درایور سازگار و نصب دستی نیاز دارد. راهنمای کامل، هشدارهای کنترلر دوگانه و چک‌لیست آزمون: [راهنمای فارسی Windows](docs/WINDOWS_FA.md).

## فرمان‌های تشخیص

```bat
run_windows.cmd --version
run_windows.cmd --check-config
run_windows.cmd --list-devices
run_windows.cmd --no-scan
run_windows.cmd --config-dir "D:\FFS Profile" --check-config
```

`--check-config` بدون GUI و سخت‌افزار تنظیمات را ایجاد/اعتبارسنجی می‌کند؛ `--list-devices` فقط ورودی‌های SDL را فهرست می‌کند. تنظیمات موجود بازنویسی نمی‌شوند. گزارش‌ها در زیرپوشهٔ `logs` مسیر پروفایل‌اند.

## عیب‌یابی رابط

`--debug` نمونه‌برداری منابع (ویجت، `after`، USER/GDI در Windows) و ثبت stack هنگام قفل رابط را به `logs` اضافه می‌کند. فایل `logs\faulthandler.log` برای کرش بومی است. آزمون فشار: `run_stress_test.cmd` (پیش‌فرض بدون سخت‌افزار و بدون خروجی واقعی). جزئیات، یافته‌های تأییدشده و فرضیه‌ها: [docs/UI_DIAGNOSTICS_FA.md](docs/UI_DIAGNOSTICS_FA.md).

## توسعه و ساخت

```sh
python -m unittest discover -s tests -v
python -m ffsbridge --check-config --config-dir ./test-profile
```

برای ساخت در **Windows x64**: `build_windows.cmd`. خروجی مورد انتظار `dist/FFSControllerBridge` است؛ کل پوشه، از جمله `_internal`، لازم است. EXE گرافیکی و کنسولی کنار هم ساخته می‌شوند. PyInstaller این پروژه را از Linux به Windows کامپایل نمی‌کند.

- `ffsbridge/`: موتور، SDL، خروجی، سرویس و رابط Tk
- `data/`: تنظیمات کارخانه، کاتالوگ و JSON Schemaها
- `tests/`: تست‌های بدون کنترلر واقعی
- `tools/`: تبدیل آفلاین و بررسی بسته‌بندی
- `windows/`: hook زمان اجرای بسته

نسخه‌های مستقیم وابستگی‌ها مشخص شده‌اند؛ وابستگی‌های انتقالی کاملاً قفل نشده‌اند و ساخت بایت‌به‌بایت یکسان تضمین نمی‌شود. فهرست نصب واقعی در خروجی ساخت ذخیره می‌شود.

## وضعیت و محدودیت

این بسته **سورس است، نه EXE تأییدشده**. تست‌های خودکار روی Linux اجرا شده‌اند؛ GUI/Tk، درایور، سخت‌افزار و بستهٔ Windows در این محیط آزمایش نشده‌اند. نتیجهٔ آزمون‌ها در `TEST_RESULTS.md` آمده است.

بدون rumble، gyro، gesture، adaptive trigger، تحلیل تصویر یا آگاهی از وضعیت بازی. `touchpad` و `misc1` فقط می‌توانند محرک ماکرو باشند و خروجی معادل Xbox 360 ندارند. زمان‌بندی و عملکرد مهارت‌ها در بازی تضمین نمی‌شود. قوانین بازی/پلتفرم و محدودیت استفاده از ماکرو را رعایت کنید.

اطلاعات وابستگی‌ها و وضعیت حقوق بازنشر: [THIRD_PARTY.md](THIRD_PARTY.md).
