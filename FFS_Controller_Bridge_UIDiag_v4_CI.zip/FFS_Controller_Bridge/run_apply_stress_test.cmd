@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
if not exist ".venv\Scripts\python.exe" (
    echo Run setup_windows.cmd first.
    popd
    exit /b 1
)
set "PYTHONUTF8=1"
".venv\Scripts\python.exe" tools\gui_stress.py %*
set "RC=%ERRORLEVEL%"
popd
exit /b %RC%
