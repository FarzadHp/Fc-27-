@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
set "RC=1"
rem vgamepad 0.2.0 otherwise may start an old ViGEmBus MSI during pip install.
set "VGAMEPAD_SKIP_VIGEMBUS_INSTALL=true"
set "PYTHONUTF8=1"
if exist ".venv\Scripts\python.exe" goto check_host
where py >nul 2>&1
if errorlevel 1 (
    echo Python launcher not found. Install Python 3.11 x64 with Tcl/Tk and the py launcher.
    goto finish
)
py -3.11 tools\windows_bundle.py --host-only
if errorlevel 1 goto finish
py -3.11 -m venv .venv
if errorlevel 1 goto finish
:check_host
".venv\Scripts\python.exe" tools\windows_bundle.py --host-only
if errorlevel 1 goto finish
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto finish
".venv\Scripts\python.exe" tools\windows_bundle.py
if errorlevel 1 goto finish
echo.
echo Setup complete. No ViGEmBus or HidHide driver was installed.
echo Preview needs no driver. For real output, see docs\WINDOWS_FA.md.
set "RC=0"
:finish
if not "%RC%"=="0" echo SETUP FAILED. Read the error above; do not run as Administrator to bypass it.
popd
if /I not "%~1"=="--no-pause" pause
exit /b %RC%
