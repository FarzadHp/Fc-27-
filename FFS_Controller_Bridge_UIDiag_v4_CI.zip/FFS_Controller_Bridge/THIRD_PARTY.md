# Third-party components and redistribution

This source archive does not include Python, downloaded wheels, native DLLs,
driver installers or installed site-packages. The setup script downloads runtime
dependencies; the Windows build includes selected installed runtime files.

Direct runtime dependencies: jsonschema, PySDL2, pysdl2-dll (SDL2 native runtime),
and vgamepad (Windows, including its ViGEmClient runtime). Python/Tcl/Tk and
transitive dependencies such as attrs, referencing, rpds-py and
jsonschema-specifications also have their own terms. Build tools include
PyInstaller and pyinstaller-hooks-contrib. Version requirements are in the two
requirements files; the Windows build saves the actual installed package list.

The build helper copies available installed LICENSE/COPYING/NOTICE files into
`_internal/licenses`, including available Python and Tcl/Tk notices. This is a
best-effort collection, NOT a complete license or redistribution audit. Before
publishing binaries, inspect the exact versions, native-library notices, required
attributions and any source-offer obligations. Do not assume a Python wrapper's
license also covers every bundled native library.

ViGEmBus and HidHide are separate, optional/manual driver installations, not
redistributed here. No permission to redistribute driver installers is implied.

No project-wide open-source license is asserted by this delivery. Rights to the
original GPC and derived skill data remain subject to their owners' permissions.
Before public or commercial redistribution, establish the rights to the original
material and the project code and supply an appropriate license. This document
is informational, not legal advice.
