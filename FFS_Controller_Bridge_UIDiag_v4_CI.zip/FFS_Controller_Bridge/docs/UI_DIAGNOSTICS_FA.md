# عیب‌یابی خرابی رابط و کرش `Failed to create the menu window`

این سند فقط چیزی را «تأییدشده» می‌نامد که در سورس یا در اجرای واقعی همین محیط دیده شده است. علت نهایی خرابی تصویری روی Windows **هنوز اثبات نشده**؛ ابزارهای زیر برای گرفتن همان مدرک اضافه شده‌اند.

## تأییدشده

1. **منبع پیام `Failed to create the menu window`** در Tk 8.6.12: `win/tkWinMenu.c`، تابع `TkpMenuThreadInit`. اگر `CreateWindowW` برای یک پنجرهٔ مخفی ساده شکست بخورد، `Tcl_Panic` می‌زند و پردازش بسته می‌شود؛ یعنی استثنای پایتون نیست و `try/except` آن را نمی‌گیرد.
2. این init **تنبل (lazy)** است: فقط وقتی اجرا می‌شود که Tk اولین پیام منو/سیستم را ببیند (`WM_SYSCOMMAND`، `WM_INITMENU`، `WM_COMMAND`، `WM_MENUSELECT`) یا فرمان `menu` اجرا شود. این برنامه Menu نمی‌سازد؛ پس اولین `WM_SYSCOMMAND` (کوچک/بزرگ‌کردن، جابه‌جایی، تغییر اندازه، بستن) می‌تواند ساعت‌ها بعد از شروع برنامه این کد را اجرا کند.
3. نتیجهٔ منطقی: در لحظهٔ کرش، ساخت یک پنجرهٔ ساده در این پردازش یا این Desktop شکست می‌خورد. شایع‌ترین علت‌ها: رسیدن به سقف USER objects (پیش‌فرض ۱۰٬۰۰۰ برای هر پردازش)، فشار Desktop heap یا شرایط مشابه سیستم. **این ثابت نمی‌کند نشتی از برنامهٔ ما بوده**؛ فقط می‌گوید باید USER/GDI را در لحظهٔ خرابی ببینیم.
4. چرخ ماوس روی `ttk.Combobox` در Tk 8.6.12 مقدار انتخاب‌شده را عوض می‌کند (`ttk::combobox::Scroll`، `combobox.tcl`). در فرم Skills (۹ Combobox) اسکرول با ماوس می‌توانست بی‌صدا نگاشت مهارت را تغییر دهد؛ در کد قبلی با شبیه‌ساز رویداد X11 بازتولید شد (`0: OFF` → `1: Body Feint Left`). اصلاح شد (`_combobox_wheel`). این باگ واقعی است ولی **توضیح‌دهندهٔ فرم خالی نیست**.
5. حلقهٔ `_poll` هر ۵۰ms اجرا می‌شد و در خطای پایدار، traceback کامل را ۲۰ بار در ثانیه می‌نوشت (۱۰۰ بار در تست). اکنون خطای اول کامل و بقیه با شمارندهٔ suppress ثبت می‌شوند.
6. فهرست گروه‌ها پس از شکست ساخت فرم جدید روی گروه ناموفق می‌ماند، در حالی که فرم قبلی نمایش داده می‌شد؛ اکنون انتخاب فهرست برمی‌گردد و exception همچنان بالا می‌آید.
7. چندین `after_idle(_reset_form_view)` بدون تعویض رویداد روی هم جمع می‌شدند (۲۴ مورد در تست)؛ اکنون فقط یکی pending می‌ماند.
8. جدول Live I/O، status و checkbuttonها ۲۰ بار در ثانیه حتی بدون تغییر مقدار نوشته می‌شدند؛ اکنون فقط هنگام تغییر مقدار (و جدول فقط وقتی تبش دیده می‌شود).
9. مالکیت thread: در سورس، هیچ فراخوانی Tk خارج از thread اصلی دیده نشد (`service.py`, `output.py`, `input_sdl.py` از Tk استفاده نمی‌کنند؛ ارتباط فقط با `queue`). `Variable.__del__` روی thread دیگر ممکن است خطای بی‌صدا بسازد؛ برای دیدن آن `sys.unraisablehook` اضافه شد.
10. در Linux (Tk 8.6.14 + Xvfb) تعویض ۱۵۰۰ بارهٔ گروه، Apply/Start/Stop/Refresh مکرر و stress ۷۰۰ تعاملی هیچ رشدی در ویجت، فرمان Tcl، globals، `after` یا thread نشان ندادند (`tests/test_ui_regression.py`، `tools/stress_ui.py`).

## فرضیه‌ها (اثبات‌نشده)

- **نشتی/پر شدن USER یا GDI در Windows** (مثلاً از رسم مکرر ttk با تم vista یا درایور گرافیک): در Linux قابل اندازه‌گیری نیست. باید `tools/stress_ui.py` و لاگ debug روی Windows اجرا شود.
- **عدم repaint بدون مرگ event loop:** در عکس، نوشتهٔ `VIRTUAL XBOX | Passthrough` یعنی دست‌کم یک بار poll اجرا و status ساخته شده؛ زنده‌بودن حلقه در لحظهٔ عکس ثابت نمی‌شود. عکس از صفحه است (moiré)، پس آرتیفکت نمایش را هم نمی‌توان کنار گذاشت.
- **قطع شدن ارتباط DWM/درایور گرافیک** یا برنامه‌های overlay همزمان (بازی، ضبط، ابزار ریمپ).
- **خرابی نمایش فعلی و کرش `menu window` یک علت دارند:** هر دو با «شکست ساخت/رسم پنجره» سازگارند، ولی مدرکی نیست. جدا بررسی شوند.

## آنچه اضافه شد (مشاهده‌پذیری، نه درمان)

| ابزار | کاربرد |
|---|---|
| `logs\bridge.log` (چرخشی ۱MB×۳) | خطاها، توقف worker، Tk patchlevel، خط `resources[startup]` و `resources[closing]` در هر اجرا |
| `report_callback_exception` | traceback کامل هر استثنای callback Tk + شمار منابع + توقف ایمن خروجی |
| `sys.unraisablehook` | خطاهای مخفی `__del__` (مثلاً Variable روی thread اشتباه) |
| `logs\faulthandler.log` | tracebackِ همهٔ threadها هنگام SIGSEGV/SIGABRT/Access violation. `Tcl_Panic` به `abort()` ختم می‌شود و انتظار می‌رود اینجا اثر بگذارد. **محدودیت:** فقط stack پایتون، نه C؛ برای kill خارجی، OOM یا TerminateProcess چیزی نمی‌نویسد. در خروج سالم اگر خالی باشد حذف می‌شود؛ فایل‌های قبلی `.1 .2 .3` می‌شوند |
| `--debug` | هر ۳۰ثانیه `resources[sample]`: ویجت، `after`، فرمان Tcl، thread، USER، GDI، handle، HWND؛ هشدار یک‌باره هنگام رشد؛ StallWatch: اگر thread رابط ۱۵ثانیه poll نکند، stack همهٔ threadها در `faulthandler.log` |
| `warm_up_tk_menu` | init منوی Tk را به شروع برنامه می‌آورد. اگر ساخت پنجره آن زمان ناممکن باشد، همان لحظه معلوم می‌شود؛ و اگر بعداً پنجره‌ای ساخته نشود، به‌جای `Tcl_Panic` یک `TclError` قابل‌ثبت می‌گیریم. **درمان نشتی نیست.** |

## آزمون روی Windows

پیش‌نیاز: `setup_windows.cmd` (بدون نصب درایور).

### ۱) ساخت و تست‌ها
```
build_exe.cmd
```
`build_windows.cmd` اکنون پوشهٔ قدیمی `dist\FFSControllerBridge` را **قبل از ساخت پاک می‌کند** و در هر شکست هم پوشهٔ ناقص را حذف می‌کند؛ پس بعد از «BUILD FAILED» EXE‌ای وجود ندارد. تست‌ها (از جمله GUI) پیش از PyInstaller اجرا می‌شوند.

### ۲) stress بدون سخت‌افزار (Preview، کنترلر جعلی) — پیش‌فرض
```
run_stress_test.cmd --interactions 600
```
خروجی: `stress-results\<زمان>\samples.csv`، `summary.json`، `logs\bridge.log`. کد خروج: `0` PASS، `1` FAIL، `2` خطا/گیر کردن. PASS فقط یعنی «رشدی فراتر از آستانه نبود».

برای بازتولید بهتر: `--interactions 3000 --step-ms 10 --seed 2` را چند بار با seedهای مختلف اجرا کنید.

### ۳) کنترلر فیزیکی، فقط Preview (خروجی مجازی ساخته نمی‌شود)
```
run_stress_test.cmd --mode preview-device --device-label "بخشی از نام کنترلر فیزیکی"
```
### ۴) خروجی واقعی Xbox مجازی (اختیاری، جدا)
فقط با ViGEmBus سالم و بدون برنامهٔ remap دیگر:
```
run_stress_test.cmd --mode real-output --device-label "نام کنترلر فیزیکی" --confirm-real-output
```
هرگز کنترلر مجازی را به‌عنوان ورودی انتخاب نکنید.

### ۵) تأیید دستی اصلاح
۱. `FFSControllerBridge.exe --debug` را اجرا کنید. ۲. Settings → Skills را تا پایین اسکرول کنید، با چرخ ماوس **روی Combobox** بچرخانید؛ مقدارها نباید تغییر کنند. ۳. چند ده بار Skills/Passes/General، Apply، Stop/Start، تغییر اندازه و minimize. ۴. بعد از خروج سالم، `logs\bridge.log` را برای خطوط `resources[...]` و `WARNING` ببینید.

## اگر باز هم خالی شد، این‌ها را بفرستید
- `logs\bridge.log` و `logs\faulthandler.log*` (کل پوشهٔ `logs`).
- خطوط `resources[sample]` پیش از و هنگام خرابی: ستون‌های `user`, `gdi`, `hwnd`, `widgets`, `after`.
- اگر پنجره خالی شد و برنامه هنوز جواب می‌دهد: همان لحظه Task Manager → Details → ستون‌های «USER objects» و «GDI objects» برای `FFSControllerBridge.exe` (Select columns).
- اگر پنجره خالی شد و جواب نمی‌دهد: وجود `faulthandler.log` با بخش `Timeout` (stack محل قفل).
- آیا فقط با خروجی واقعی رخ می‌دهد یا در Preview هم؟ آیا با `--no-scan` هم؟
- نسخهٔ درایور گرافیک و برنامه‌های overlay/ضبط/ریمپ همزمان.
