# UI layout rework

- Primary actions and status use reserved grid rows; only the central notebook expands.
- Runtime toggles are separated from Start/Apply/Stop.
- Settings is the initial tab; session logs have their own tab.
- Existing settings form scrolling, live Apply and controller logic remain unchanged.
- Build on Windows with build_exe.cmd. Never use a stale dist after a failed build.

Validation in this Linux environment: compileall passed; 98 tests passed and 4 Tk GUI tests skipped because Tk is unavailable. Windows rendering, high-DPI behavior and real controller operation are not verified. This layout revision does not establish or guarantee a fix for the previously photographed rendering problem.
