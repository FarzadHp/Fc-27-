# Start / Stop / Refresh follow-up

This patch does not claim a confirmed fix for the user's Windows/SDL/driver restart failure: the video does not expose a readable error and the hardware is unavailable here.

Changes:
- Refresh retains the exact previously explicitly selected Device, but does not choose a new/reconnected/virtual device automatically.
- Repeated Refresh requests are blocked while enumeration is pending; Start waits for enumeration.
- Stop blocks Start until the worker reports stopped.
- Start/cleanup errors remain in the status after stopped and open the Logs tab.
- The UI event polling callback is rescheduled even if a callback raises; exceptions go to bridge.log.
- The engine menu action selects Settings rather than Live I/O after the tab reorder.

Validation: compileall passed; unittest discovery ran 106 tests: 98 passed, 8 Tk GUI tests skipped (Tk unavailable). No Windows, actual driver, controller or GUI validation performed.

Windows verification:
1. Extract into a fresh directory and run build_exe.cmd. Do not run an old dist after a failed build.
2. Run the entire successful output bundle including _internal, without the game.
3. Enable Preview, Refresh, explicitly select the physical controller, Start, Stop, wait for Stopped, Start. Repeat several times.
4. While stopped, Refresh should retain that same controller if its identity is unchanged. Reconnect requires explicit selection again.
5. If unsuccessful, send Logs text and logs/bridge.log; say whether Preview was enabled and whether status remains Stopping or reports Error.
6. Only then test actual output separately. An unresponsive output driver still intentionally blocks restart for safety.
