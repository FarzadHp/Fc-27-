# Classic / native light appearance

Restores the native Windows ttk theme (vista/xpnative/winnative) and default light Tk widgets instead of the custom blue/green palette. The current layout is retained, including separate action rows and the Logs tab. Live Apply, explicit device selection and restart/refresh fixes are retained. This is an appearance rollback, not a rollback to the old engine or an exact restoration of the old layout.

Existing user settings in LocalAppData are not changed. No watchdog default change.

Validation: compileall passed; 106 tests ran, 98 passed and 8 GUI tests skipped because Tk is unavailable. Windows appearance and the reported 'Failed to create the menu window' crash have NOT been verified or proven fixed.

Extract into a fresh folder. Use run_windows.cmd for source execution or build_exe.cmd for a Windows bundle. Only use dist after a successful build, retaining _internal.
