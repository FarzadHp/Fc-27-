# FC 27 – Curated 15-skill catalog

The previous 92-entry skill list is replaced by these 15 distinct entries. All original non-skill `actions` and application files are preserved.

| ID | Skill |
|---:|---|
| 1 | Body Feint Left |
| 2 | Body Feint Right |
| 3 | Stepover Left |
| 4 | Stepover Right |
| 5 | Reverse Stepover Left |
| 6 | Reverse Stepover Right |
| 7 | Ball Roll Left |
| 8 | Ball Roll Right |
| 9 | Heel Flick |
| 10 | Roulette Left |
| 11 | Roulette Right |
| 12 | Fake Left and Go Right |
| 13 | Fake Right and Go Left |
| 14 | Elastico |
| 15 | Reverse Elastico |

## Input convention
All recipes use the right stick (RS), relative to the player's facing: local x=right and local y=forward. Flicks are short pulses followed by neutral; turns are approximated by intermediate stick positions.

## Timing caveat
EA's public move lists specify button/stick sequences, not millisecond timings for external macro software. Durations here are conservative starting estimates, not official or game-validated values. Results depend on polling rate, frame rate, connection latency, player animation and skill rating. Validate in FC 27 before competitive use.

## Sources for move names and stick sequences
- Dot Esports: https://dotesports.com/ea-sports-fc/guides/ea-sports-fc-27-skills
- FIFPlay: https://www.fifplay.com/fc-27-skill-moves
- Paamu: https://paamu.com/en/games/ea-sports-fc-27/guides/four-five-star-skill-moves-controller-inputs/
