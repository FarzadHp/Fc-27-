@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
set "PYTHONUTF8=1"
if exist ".venv\Scripts\python.exe" goto run
call setup_windows.cmd --no-pause
if errorlevel 1 goto setup_failed
:run
".venv\Scripts\python.exe" run_bridge.py %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo Bridge exited with an error. Check the console and the logs directory.
    pause
)
popd
exit /b %RC%
:setup_failed
echo Setup failed. See docs\WINDOWS_FA.md.
pause
popd
exit /b 1
