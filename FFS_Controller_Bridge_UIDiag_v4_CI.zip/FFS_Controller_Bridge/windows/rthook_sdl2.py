"""Prefer this bundle's verified SDL2.dll over any machine-wide SDL path."""
import os
from pathlib import Path
import sys

if getattr(sys, "frozen", False):
    os.environ["PYSDL2_DLL_PATH"] = str(Path(sys._MEIPASS) / "sdl2dll" / "dll")
