"""Static guards for the Windows build scripts (they cannot be executed on Linux)."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class BuildScriptTests(unittest.TestCase):
    def script(self):
        return (ROOT / "build_windows.cmd").read_text(encoding="ascii")

    def test_old_dist_is_removed_before_building_and_after_failure(self):
        text = self.script()
        remove = r"rmdir /s /q dist\FFSControllerBridge"
        self.assertIn(remove, text)
        self.assertLess(text.index(remove), text.index("setup_windows.cmd --no-pause"))
        failure = text[text.index(":finish"):]
        self.assertIn(remove, failure)
        self.assertIn('if not "%RC%"=="0"', failure)

    def test_every_step_after_pyinstaller_can_fail_the_build(self):
        text = self.script()
        tail = text[text.index("PyInstaller"):text.index('set "RC=0"')]
        self.assertGreaterEqual(tail.count("if errorlevel 1 goto finish"), 5)
        self.assertIn("verify_windows_build.py", tail)

    def test_cmd_files_use_crlf(self):
        # LF-only batch files can mis-parse labels/goto in cmd.exe.
        for path in ROOT.glob("*.cmd"):
            data = path.read_bytes()
            self.assertEqual(data.count(b"\n"), data.count(b"\r\n"), path.name)


if __name__ == "__main__":
    unittest.main()
