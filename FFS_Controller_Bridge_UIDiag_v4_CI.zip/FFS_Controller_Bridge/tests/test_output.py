import math
import threading
import unittest

from unittest.mock import patch

from ffsbridge.output import FreshReport, OutputPump
from ffsbridge.state import PadState
from tests.helpers import RecordingOutput, eventually


class MailboxTests(unittest.TestCase):
    def test_timeout_must_be_positive_and_finite(self):
        for value in (0, -1, math.nan, math.inf):
            with self.subTest(value=value), self.assertRaises(ValueError):
                FreshReport(value)

    def test_clock_is_read_under_lock_not_before_newer_submission(self):
        m = FreshReport(.15)
        m.submit(PadState.from_values(a=1), 1)
        locked = threading.Event()

        class InterleavingLock:
            def __enter__(self):
                # Simulate a producer publishing just before consumer takes lock.
                m.stamp = 1.1
                locked.set()

            def __exit__(self, *args):
                locked.clear()

        def clock():
            self.assertTrue(locked.is_set(), "Reading outside lock races with producer")
            return 1.11

        m.lock = InterleavingLock()
        with patch("ffsbridge.output.time.monotonic", side_effect=clock):
            self.assertEqual(m.sample(), (PadState.from_values(a=1), False))

    def test_fresh_samples_are_copies(self):
        m = FreshReport(.15)
        p = PadState.from_values(a=1)
        m.submit(p, 1)
        p.patch({"a": 0})
        result, expired = m.sample(1.1)
        self.assertFalse(expired)
        self.assertEqual(result["a"], 1)
        result.patch({"a": 0})
        self.assertEqual(m.sample(1.1)[0]["a"], 1)

    def test_staleness_latches_and_neutralizes(self):
        m = FreshReport(.15)
        m.submit(PadState.from_values(a=1, rt=1), 1)
        self.assertEqual(m.sample(1.2), (PadState(), True))
        with self.assertRaises(TimeoutError):
            m.submit(PadState.from_values(b=1), 1.21)
        self.assertEqual(m.sample(1.22), (PadState(), True))

    def test_late_submission_cannot_hide_stall(self):
        m = FreshReport(.15)
        m.submit(PadState(), 1)
        with self.assertRaises(TimeoutError):
            m.submit(PadState.from_values(a=1), 1.2)

    def test_bad_time_fails_closed(self):
        for now in (.5, math.nan, math.inf, -math.inf):
            m = FreshReport(.15)
            m.submit(PadState.from_values(a=1), 1)
            self.assertEqual(m.sample(now), (PadState(), True))
        for now in (math.nan, math.inf):
            with self.assertRaises(TimeoutError):
                FreshReport(.15).submit(PadState(), now)


class PumpTests(unittest.TestCase):
    def make(self, watchdog=1000, sink_class=RecordingOutput):
        self.sinks = []
        def factory():
            sink = sink_class()
            self.sinks.append(sink)
            return sink
        pump = OutputPump(factory, watchdog)
        self.addCleanup(pump.stop)
        pump.start()
        return pump, self.sinks[0]

    def test_owner_thread_full_reports_and_neutral_stop(self):
        pump, sink = self.make()
        pump.submit(PadState.from_values(a=1, lt=1))
        eventually(lambda: sink.seen("a", 1))
        pump.submit(PadState.from_values(b=1))
        eventually(lambda: sink.seen("b", 1))
        self.assertEqual(sink.last()["a"], 0)
        self.assertTrue(pump.stop())
        self.assertTrue(sink.closed.is_set())
        self.assertEqual(sink.last(), PadState())
        self.assertEqual(set(sink.threads), {sink.created_on})
        self.assertNotEqual(sink.created_on, threading.get_ident())
        with self.assertRaises(RuntimeError):
            pump.submit(PadState())
        self.assertTrue(pump.stop())

    def test_stalled_producer_stops_neutral(self):
        pump, sink = self.make(watchdog=100)
        pump.submit(PadState.from_values(a=1))
        eventually(lambda: sink.seen("a", 1))
        self.assertTrue(sink.closed.wait(3))
        self.assertIn("watchdog", pump.error)
        self.assertEqual(sink.last(), PadState())
        self.assertTrue(pump.stop())

    def test_watchdog_armed_even_without_first_report(self):
        pump, sink = self.make(watchdog=100)
        self.assertTrue(sink.closed.wait(3))
        self.assertIn("watchdog", pump.error)
        self.assertEqual(sink.last(), PadState())

    def test_factory_failure_reported(self):
        def factory():
            raise RuntimeError("factory injected")
        pump = OutputPump(factory, 100)
        self.addCleanup(pump.stop)
        with self.assertRaisesRegex(RuntimeError, "factory injected"):
            pump.start()
        self.assertTrue(pump.stop())

    def test_send_error_still_neutralizes_and_closes(self):
        class FailingSink(RecordingOutput):
            def send(self, p):
                if p.down("a"):
                    raise OSError("send injected")
                super().send(p)
        pump, sink = self.make(sink_class=FailingSink)
        pump.submit(PadState.from_values(a=1))
        self.assertTrue(sink.closed.wait(3))
        self.assertEqual(pump.error, "send injected")
        self.assertEqual(sink.last(), PadState())

    def test_close_error_is_reported(self):
        class BadClose(RecordingOutput):
            def close(self):
                super().close()
                raise OSError("close injected")
        pump, sink = self.make(sink_class=BadClose)
        self.assertTrue(pump.stop())
        self.assertIn("close injected", pump.error)
        self.assertEqual(sink.last(), PadState())


if __name__ == "__main__":
    unittest.main()
