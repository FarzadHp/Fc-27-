"""Hardware-free regression tests. Run: python -m unittest discover -s tests -v"""
