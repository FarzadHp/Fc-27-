"""Diagnostics must really capture evidence: native crash traces, UI stalls, handle counts."""
import logging
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

try:
    import tkinter as tk
except ImportError:
    tk = None

from ffsbridge import diagnostics, launcher

ROOT = Path(__file__).resolve().parents[1]


def run_python(code, *args, timeout=60):
    return subprocess.run([sys.executable, "-c", textwrap.dedent(code), *map(str, args)],
                          cwd=ROOT, capture_output=True, text=True, timeout=timeout)


class LogThrottleTests(unittest.TestCase):
    def test_repeated_error_is_reported_once_per_interval_with_suppressed_count(self):
        now = [0.0]
        throttle = diagnostics.LogThrottle(30, clock=lambda: now[0])
        logger = logging.getLogger("ffsbridge.test_throttle")
        with self.assertLogs(logger, "ERROR") as logs:
            for _ in range(50):
                throttle.error(logger, "k", "failure", exc_info=False)
            now[0] = 31
            throttle.error(logger, "k", "failure", exc_info=False)
        self.assertEqual(len(logs.records), 2)
        self.assertIn("49 identical", logs.output[1])

    def test_different_keys_are_independent(self):
        throttle = diagnostics.LogThrottle(30, clock=lambda: 0.0)
        logger = logging.getLogger("ffsbridge.test_throttle")
        with self.assertLogs(logger, "ERROR") as logs:
            throttle.error(logger, "a", "one", exc_info=False)
            throttle.error(logger, "b", "two", exc_info=False)
        self.assertEqual(len(logs.records), 2)


class FileTests(unittest.TestCase):
    def test_rotate_keeps_a_bounded_history(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x.log"
            for index in range(6):
                path.write_text(str(index))
                diagnostics.rotate_file(path, keep=3)
            names = sorted(p.name for p in Path(directory).iterdir())
            self.assertEqual(names, ["x.log.1", "x.log.2", "x.log.3"])
            self.assertEqual((Path(directory) / "x.log.1").read_text(), "5")


class NativeCrashTests(unittest.TestCase):
    CRASH = """
        import faulthandler, sys, threading
        from pathlib import Path
        from ffsbridge import diagnostics
        diagnostics.enable_faulthandler(Path(sys.argv[1]))
        threading.Thread(target=lambda: threading.Event().wait(30), name="FFS-input", daemon=True).start()
        faulthandler._sigsegv()   # stands in for a native crash / Tcl_Panic abort
    """

    def test_native_crash_leaves_all_thread_traces_and_rotates(self):
        with tempfile.TemporaryDirectory() as directory:
            for _ in range(2):
                result = run_python(self.CRASH, directory)
                self.assertNotEqual(result.returncode, 0)
            text = (Path(directory) / "faulthandler.log").read_text()
            self.assertRegex(text, r"(Fatal Python error|fatal exception)")
            self.assertIn("Current thread", text)      # the crashing thread ...
            self.assertRegex(text, r"\bThread 0x")       # ... and the other threads (all_threads=True)
            self.assertTrue((Path(directory) / "faulthandler.log.1").is_file())

    def test_clean_exit_removes_the_empty_file(self):
        with tempfile.TemporaryDirectory() as directory:
            result = run_python("""
                import sys
                from pathlib import Path
                from ffsbridge import diagnostics
                path = diagnostics.enable_faulthandler(Path(sys.argv[1]))
                assert path.exists()
                diagnostics.disable_faulthandler()
            """, directory)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse((Path(directory) / "faulthandler.log").exists())

    def test_stalled_ui_thread_is_dumped_while_running(self):
        with tempfile.TemporaryDirectory() as directory:
            result = run_python("""
                import sys, time
                from pathlib import Path
                from ffsbridge import diagnostics
                diagnostics.enable_faulthandler(Path(sys.argv[1]))
                watch = diagnostics.StallWatch(timeout=0.3)
                watch.beat()
                def blocked_in_driver_call():
                    time.sleep(1.2)          # the Tk thread stops beating
                blocked_in_driver_call()
            """, directory)
            self.assertEqual(result.returncode, 0, result.stderr)
            text = (Path(directory) / "faulthandler.log").read_text()
            self.assertIn("Timeout", text)
            self.assertIn("blocked_in_driver_call", text)

    def test_stall_watch_is_silent_when_beating(self):
        with tempfile.TemporaryDirectory() as directory:
            result = run_python("""
                import sys, time
                from pathlib import Path
                from ffsbridge import diagnostics
                diagnostics.enable_faulthandler(Path(sys.argv[1]))
                watch = diagnostics.StallWatch(timeout=0.5)
                for _ in range(40):
                    watch.armed_at = None     # re-arm every beat, as the 1 s throttle would
                    watch.beat()
                    time.sleep(0.05)
                watch.stop()
                diagnostics.disable_faulthandler()
            """, directory)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse((Path(directory) / "faulthandler.log").exists())


class MeasurementTests(unittest.TestCase):
    def test_process_resources_off_windows_is_empty(self):
        if sys.platform == "win32":
            self.skipTest("Windows-only API is covered below")
        self.assertEqual(diagnostics.process_resources(), {})

    @unittest.skipUnless(sys.platform == "win32", "needs Windows USER/GDI counters")
    def test_process_resources_on_windows(self):
        data = diagnostics.process_resources()
        self.assertGreater(data["handles"], 0)
        self.assertGreaterEqual(data["user_peak"], data["user"])
        self.assertGreaterEqual(data["gdi_peak"], data["gdi"])

    @unittest.skipIf(tk is None, "Tk libraries unavailable")
    def test_tk_snapshot_tracks_widgets_and_pending_callbacks(self):
        try:
            root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(str(exc))
        self.addCleanup(root.destroy)
        before = diagnostics.tk_snapshot(root)
        label = tk.Label(root)
        job = root.after(60_000, lambda: None)
        after = diagnostics.tk_snapshot(root)
        self.assertEqual(after["widgets"], before["widgets"] + 1)
        self.assertEqual(after["after"], before["after"] + 1)
        root.after_cancel(job)
        label.destroy()
        self.assertEqual(diagnostics.tk_snapshot(root)["widgets"], before["widgets"])
        diagnostics.warm_up_tk_menu(root)  # must be harmless and repeatable
        diagnostics.warm_up_tk_menu(root)
        self.assertEqual(diagnostics.tk_snapshot(root)["widgets"], before["widgets"])

    def test_threshold_warnings(self):
        calm = {"widgets": 80, "after": 2, "user": 300, "gdi": 200}
        self.assertEqual(diagnostics.threshold_warnings(calm, 76), [])
        runaway = {"widgets": 900, "after": 500, "user": 9000, "gdi": 100}
        text = " ".join(diagnostics.threshold_warnings(runaway, 76))
        self.assertIn("USER", text)
        self.assertIn("widgets grew", text)
        self.assertIn("pending after()", text)


class LauncherHookTests(unittest.TestCase):
    def test_tk_callback_exception_is_logged_with_traceback_and_stops_safely(self):
        root, service, errors = Mock(), Mock(), []
        report = launcher.tk_callback_reporter(root, service, errors)
        try:
            raise ValueError("boom in callback")
        except ValueError:
            info = sys.exc_info()
        with patch.object(launcher.diagnostics, "log_snapshot") as snapshot:
            with self.assertLogs("ffsbridge.launcher", "ERROR") as logs:
                report(*info)
        self.assertIn("boom in callback", "\n".join(logs.output))  # traceback text is in the record
        self.assertIn("Traceback", "\n".join(logs.output))
        snapshot.assert_called_once()
        service.shutdown.assert_called_once()
        root.quit.assert_called_once()
        self.assertEqual(len(errors), 1)

    def test_loop_is_still_quit_when_shutdown_itself_fails(self):
        root, service = Mock(), Mock()
        service.shutdown.side_effect = RuntimeError("worker gone")
        report = launcher.tk_callback_reporter(root, service, [])
        with patch.object(launcher.diagnostics, "log_snapshot"):
            with self.assertLogs("ffsbridge.launcher", "ERROR"):
                with self.assertRaises(RuntimeError):
                    report(ValueError, ValueError("x"), None)
        root.quit.assert_called_once()

    def test_unraisable_exceptions_reach_the_log_and_the_hook_is_restored(self):
        before = sys.unraisablehook
        with tempfile.TemporaryDirectory() as directory:
            with launcher.session_logging(Path(directory)):
                sys.unraisablehook(SimpleNamespace(exc_type=RuntimeError, exc_value=RuntimeError("del failed"),
                                                   exc_traceback=None, err_msg="Exception ignored in", object="Variable"))
            text = (Path(directory) / "bridge.log").read_text()
        self.assertIn("Unraisable exception", text)
        self.assertIn("del failed", text)
        self.assertIs(sys.unraisablehook, before)


if __name__ == "__main__":
    unittest.main()
