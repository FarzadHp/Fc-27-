"""Runner helpers need Tk installed, but do not need a display or hardware."""
import importlib.util
from pathlib import Path
import queue
import unittest
from unittest.mock import patch

try:
    spec = importlib.util.spec_from_file_location(
        "gui_stress", Path(__file__).resolve().parents[1] / "tools" / "gui_stress.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
except ImportError:
    runner = None


@unittest.skipIf(runner is None, "Tk/runner dependencies unavailable")
class StressHelpersTests(unittest.TestCase):
    def test_observation_preserves_events(self):
        events = runner.ObservedQueue()
        first, second = {"type": "running"}, {"type": "applied"}
        events.put(first)
        events.put(second)
        self.assertEqual(events.observed, [])
        self.assertIs(events.get_nowait(), first)
        self.assertIs(events.get_nowait(), second)
        self.assertEqual(events.observed, [first, second])
        with self.assertRaises(queue.Empty):
            events.get_nowait()

    def test_wait_checks_errors_even_if_predicate_is_true(self):
        class Root:
            def update(self):
                pass
        def fail():
            raise RuntimeError("callback error")
        with self.assertRaisesRegex(RuntimeError, "callback error"):
            runner.wait_until(Root(), lambda: True, 1, "timeout", fail)

    def test_wait_timeout(self):
        class Root:
            def update(self):
                pass
        with patch.object(runner.time, "monotonic", side_effect=[0, 2]):
            with self.assertRaisesRegex(TimeoutError, "not running"):
                runner.wait_until(Root(), lambda: False, 1, "not running")
