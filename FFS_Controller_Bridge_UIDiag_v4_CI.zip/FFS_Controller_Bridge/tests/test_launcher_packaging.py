import logging
from pathlib import Path
import struct
import tempfile
import threading
import unittest
from unittest.mock import patch

from ffsbridge import launcher
from tools.windows_bundle import check_pe_x64, data_files, require_build_host


class LauncherTests(unittest.TestCase):
    def test_config_check_without_gui_or_devices(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(launcher, 'run_gui') as gui, patch.object(launcher, 'list_devices') as devices:
                self.assertEqual(launcher.main(['--config-dir', directory, '--check-config']), 0)
                gui.assert_not_called()
                devices.assert_not_called()
            self.assertTrue((Path(directory) / 'logs/bridge.log').is_file())

    def test_no_scan_forwarded(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(launcher, 'run_gui') as gui:
            self.assertEqual(launcher.main(['--config-dir', directory, '--no-scan']), 0)
            self.assertFalse(gui.call_args.kwargs['auto_scan'])

    def test_device_diagnostic_dispatch(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(launcher, 'list_devices') as devices, patch.object(launcher, 'run_gui') as gui:
            self.assertEqual(launcher.main(['--config-dir', directory, '--list-devices']), 0)
            devices.assert_called_once()
            gui.assert_not_called()

    def test_gui_failure_reported(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(launcher, 'run_gui', side_effect=RuntimeError('simulated')), patch.object(launcher, 'notify_error') as notify:
            self.assertEqual(launcher.main(['--config-dir', directory]), 1)
            self.assertIn('simulated', notify.call_args.args[0])
            self.assertTrue(notify.call_args.args[1])

    def test_logging_restores_state_on_error(self):
        logger = logging.getLogger('ffsbridge')
        before = (logger.level, logger.propagate, list(logger.handlers), threading.excepthook)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(RuntimeError):
                with launcher.session_logging(Path(directory)):
                    logger.warning('test marker')
                    raise RuntimeError('test')
            self.assertIn('test marker', (Path(directory) / 'bridge.log').read_text())
        self.assertEqual(before, (logger.level, logger.propagate, list(logger.handlers), threading.excepthook))

    def test_diagnostics_mutually_exclusive(self):
        with self.assertRaises(SystemExit) as caught:
            launcher.parser().parse_args(['--check-config', '--list-devices'])
        self.assertEqual(caught.exception.code, 2)


class PackagingTests(unittest.TestCase):
    def test_build_rejects_linux(self):
        with patch('tools.windows_bundle.sys.platform', 'linux'):
            with self.assertRaises(RuntimeError):
                require_build_host()

    def test_data_manifest_exists(self):
        files = data_files(Path(__file__).resolve().parents[1])
        self.assertEqual(len(files), 4)
        self.assertTrue(all(destination == 'data' for _, destination in files))

    def test_missing_data_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                data_files(Path(directory))

    def test_pe_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'sample.dll'
            blob = bytearray(128)
            blob[:2] = b'MZ'
            struct.pack_into('<I', blob, 60, 64)
            blob[64:70] = b'PE\0\0\x64\x86'
            path.write_bytes(blob)
            check_pe_x64(path)
            blob[68:70] = b'\x4c\x01'
            path.write_bytes(blob)
            with self.assertRaises(ValueError):
                check_pe_x64(path)

    def test_non_pe_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'sample.dll'
            path.write_bytes(b'not a DLL')
            with self.assertRaises(ValueError):
                check_pe_x64(path)
