"""The Windows stress tool must itself work; this runs a short fake-controller pass of it."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

try:
    import tkinter as tk
except ImportError:
    tk = None

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipIf(tk is None, "Tk libraries unavailable")
class StressToolTests(unittest.TestCase):
    def setUp(self):
        try:
            tk.Tk().destroy()
        except tk.TclError as exc:
            self.skipTest(str(exc))

    def run_tool(self, *args):
        return subprocess.run([sys.executable, str(ROOT / "tools" / "stress_ui.py"), *args],
                              cwd=ROOT, capture_output=True, text=True, timeout=240)

    def test_short_fake_run_completes_and_writes_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            result = self.run_tool("--interactions", "120", "--warmup", "30", "--step-ms", "2",
                                   "--max-handle-growth", "500", "--out", directory)
            summary = json.loads((Path(directory) / "summary.json").read_text())
            self.assertIn(summary["verdict"], ("PASS", "FAIL"), result.stdout + result.stderr)
            self.assertEqual(summary["verdict"], "PASS", summary["problems"])
            self.assertEqual(result.returncode, 0)
            self.assertGreaterEqual(summary["actions"].get("start", 0), 1)
            rows = (Path(directory) / "samples.csv").read_text().splitlines()
            self.assertTrue(any(",reference," in row for row in rows))
            self.assertTrue(any(",final," in row for row in rows))
            self.assertTrue((Path(directory) / "logs" / "bridge.log").is_file())

    def test_real_output_and_unlabelled_hardware_runs_are_refused(self):
        self.assertEqual(self.run_tool("--mode", "real-output", "--device-label", "x").returncode, 2)
        self.assertEqual(self.run_tool("--mode", "preview-device").returncode, 2)


if __name__ == "__main__":
    unittest.main()
