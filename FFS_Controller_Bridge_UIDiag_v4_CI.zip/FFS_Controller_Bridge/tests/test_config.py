import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import jsonschema

from ffsbridge.config import ConfigStore, ConfigError, parse_json, read_json, atomic_json, MAX_JSON_BYTES
from tests.helpers import defaults


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ConfigStore(self.temp.name)
        self.settings, self.catalog = defaults()

    def test_schemas_and_bundled_data(self):
        for schema in self.store.schemas.values():
            jsonschema.Draft202012Validator.check_schema(schema)
        self.store.validate(self.settings, self.catalog)
        self.assertEqual(len(self.catalog["skills"]), 15)
        self.assertEqual({s["id"] for s in self.catalog["skills"]}, set(range(1, 16)))

    def test_defaults_automation_off(self):
        def flags(value):
            if isinstance(value, dict):
                for child in value.values():
                    yield from flags(child)
            elif isinstance(value, bool):
                yield value
        self.assertFalse(any(flags(self.settings)))
        self.assertFalse(any(self.settings["skills"]["mapping"].values()))
        self.assertEqual(self.settings["shots"]["normal_hold_ms"], 0)
        self.assertEqual(self.settings["input"]["deadzone"], 0)

    def test_load_save_backup_and_bundle(self):
        settings, catalog = self.store.load()
        settings["shots"]["normal"]["charge_ms"] = 250
        self.store.save_all(settings, catalog)
        self.assertEqual(self.store.load(), (settings, catalog))
        self.assertEqual(read_json(self.store.settings_path.with_suffix(".json.bak")), self.settings)
        bundle = Path(self.temp.name) / "bundle.json"
        self.store.export(bundle, settings, catalog)
        self.assertEqual(self.store.read_bundle(bundle), (settings, catalog))

    def test_invalid_disk_file_is_not_reset(self):
        self.store.load()
        self.store.settings_path.write_text('{"broken":', encoding="utf-8")
        with self.assertRaises(ConfigError):
            self.store.load()
        self.assertEqual(self.store.settings_path.read_text(), '{"broken":')

    def test_rejects_ambiguous_or_nonfinite_json(self):
        for text in ('{"a":1,"a":2}', '{"x":NaN}', 'Infinity', '1e9999', '[', None):
            with self.subTest(text=text), self.assertRaises(ConfigError):
                parse_json(text)
        with self.assertRaises(ConfigError):
            parse_json('"' + 'a' * MAX_JSON_BYTES + '"')

    def test_rejects_bad_settings(self):
        cases = [("input", "poll_ms", 0), ("input", "deadzone", float("nan")),
                 ("skills", "trigger_percent", 101), ("shots", "unknown", 1)]
        for section, key, value in cases:
            settings = copy.deepcopy(self.settings)
            settings[section][key] = value
            with self.subTest(section=section, key=key), self.assertRaises(ConfigError):
                self.store.validate(settings, self.catalog)

    def test_cross_field_validation(self):
        self.settings["movement"]["hair_trigger"]["release_percent"] = 10
        with self.assertRaisesRegex(ConfigError, "release"):
            self.store.validate(self.settings, self.catalog)
        self.settings, _ = defaults()
        self.settings["skills"]["mapping"]["U"] = 9999
        with self.assertRaisesRegex(ConfigError, "Unknown skill"):
            self.store.validate(self.settings, self.catalog)

    def test_rejects_duplicate_ids(self):
        self.catalog["skills"][1]["id"] = 1
        with self.assertRaisesRegex(ConfigError, "unique"):
            self.store.validate(self.settings, self.catalog)

    def test_rejects_conflicting_recipe_channels_in_both_layouts(self):
        for layout, button in (("classic", "b"), ("alternate", "x")):
            self.settings["layout"] = layout
            self.catalog["skills"][0]["steps"] = [{"duration_ms": 10, "set": {"shoot": 1, button: 0}}]
            with self.subTest(layout=layout), self.assertRaisesRegex(ConfigError, "conflicting"):
                self.store.validate(self.settings, self.catalog)
        self.catalog["skills"][0]["steps"] = [{"duration_ms": 10, "set": {"lx": 0}, "ls_local": [1, 0]}]
        with self.assertRaisesRegex(ConfigError, "conflicting"):
            self.store.validate(self.settings, self.catalog)

    def test_rejects_invalid_parameter_and_long_sequences(self):
        self.catalog["actions"]["pass"][0]["duration_ms"] = "$lob_ms"
        with self.assertRaisesRegex(ConfigError, "unsupported timing"):
            self.store.validate(self.settings, self.catalog)
        _, self.catalog = defaults()
        self.catalog["skills"][0]["steps"] = [{"duration_ms": 10000}] * 7
        with self.assertRaisesRegex(ConfigError, "60-second"):
            self.store.validate(self.settings, self.catalog)
        self.catalog["skills"][0]["steps"] = [{"duration_ms": 10, "set": {"charge": 1}}]
        with self.assertRaisesRegex(ConfigError, "only valid in action"):
            self.store.validate(self.settings, self.catalog)

    def test_atomic_replace_failure_keeps_original_and_removes_temp(self):
        path = Path(self.temp.name) / "atomic.json"
        atomic_json(path, {"a": 1})
        with patch("ffsbridge.config.os.replace", side_effect=OSError("injected")):
            with self.assertRaises(OSError):
                atomic_json(path, {"a": 2})
        self.assertEqual(read_json(path), {"a": 1})
        self.assertFalse(list(path.parent.glob("*.tmp")))

    def test_invalid_save_leaves_disk_unchanged(self):
        self.store.load()
        before = self.store.settings_path.read_bytes()
        self.settings["layout"] = "wrong"
        with self.assertRaises(ConfigError):
            self.store.save_settings(self.settings, self.catalog)
        self.assertEqual(before, self.store.settings_path.read_bytes())

    def test_bundle_format_is_strict(self):
        path = Path(self.temp.name) / "bad.json"
        for value in ({}, {"format": "unknown", "settings": {}, "catalog": {}}, []):
            path.write_text(json.dumps(value))
            with self.assertRaises(ConfigError):
                self.store.read_bundle(path)


if __name__ == "__main__":
    unittest.main()
