import queue
import unittest
from tools.stress_evidence import EvidenceQueue, evidence_problems


class EvidenceTests(unittest.TestCase):
    def test_preserves_ui_queue(self):
        events = EvidenceQueue()
        event = {'type': 'applied'}
        events.put(event)
        self.assertEqual(events.evidence(), [event])
        self.assertIs(events.get_nowait(), event)
        self.assertEqual(events.evidence(), [event])
        with self.assertRaises(queue.Empty):
            events.get_nowait()

    def test_rejection_fails_even_with_matching_ack(self):
        self.assertTrue(evidence_problems([{'type': 'applied'}, {'type': 'apply_rejected'}], 1))

    def test_service_error_fails(self):
        self.assertTrue(evidence_problems([{'type': 'error'}], 0, False))

    def test_missing_ack_fails(self):
        self.assertTrue(evidence_problems([], 1))

    def test_no_apply_is_not_pass(self):
        self.assertTrue(evidence_problems([], 0))

    def test_success(self):
        self.assertEqual(evidence_problems([{'type': 'applied'}], 1), [])
