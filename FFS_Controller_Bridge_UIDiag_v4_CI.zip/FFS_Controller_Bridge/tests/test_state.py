import math
import random
import unittest

from ffsbridge.input_sdl import stick_value, trigger_value
from ffsbridge.output import signed_axis, xbox_report, XUSB_BITS
from ffsbridge.state import PadState, BUTTONS, CHANNELS, radial_deadzone


class StateTests(unittest.TestCase):
    def test_clamps_and_quantizes(self):
        p = PadState.from_values(lx=-5, ly=5, rt=2, lt=-1, a=.49, b=.5)
        self.assertEqual([p[k] for k in ("lx", "ly", "rt", "lt", "a", "b")], [-1, 1, 1, 0, 0, 1])
        self.assertEqual(set(p.as_dict()), set(CHANNELS))

    def test_invalid_channels_and_numbers(self):
        for changes in ({"not_a_button": 1}, {"lx": math.nan}, {"rt": math.inf}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                PadState().patch(changes)

    def test_copies_do_not_alias(self):
        p = PadState.from_values(a=1)
        copy = p.copy()
        copy.patch({"a": 0})
        p.as_dict()["a"] = 0
        self.assertEqual(p["a"], 1)
        self.assertEqual(PadState()["a"], 0)

    def test_radial_deadzone(self):
        self.assertEqual(radial_deadzone(1, 1, 0), (1, 1))
        self.assertEqual(radial_deadzone(.1, .1, .2), (0, 0))
        self.assertAlmostEqual(radial_deadzone(.6, 0, .2)[0], .5)
        x, y = radial_deadzone(1, 1, .2)
        self.assertAlmostEqual(math.hypot(x, y), 1)
        for d in (-.1, 1, math.nan):
            with self.assertRaises(ValueError):
                radial_deadzone(0, 0, d)

    def test_sdl_normalization(self):
        for raw, value in ((-32768, -1), (0, 0), (32767, 1)):
            self.assertEqual(stick_value(raw), value)
        self.assertEqual(trigger_value(-32768), 0)
        self.assertEqual(trigger_value(0), 0)
        self.assertEqual(trigger_value(32767), 1)

    def test_xbox_axis_polarity_and_triggers(self):
        r = xbox_report(PadState.from_values(lx=-1, ly=-1, rx=1, ry=1, lt=.5, rt=1))
        self.assertEqual(r, dict(buttons=0, lx=-32768, ly=32767, rx=32767, ry=-32768, lt=128, rt=255))
        self.assertEqual(signed_axis(-2), -32768)
        self.assertEqual(signed_axis(2), 32767)

    def test_xbox_buttons_and_unsupported_extras(self):
        for key in BUTTONS:
            with self.subTest(key=key):
                self.assertEqual(xbox_report(PadState.from_values(**{key: 1}))["buttons"], XUSB_BITS.get(key, 0))
        self.assertEqual(xbox_report(PadState.from_values(**dict.fromkeys(BUTTONS, 1)))["buttons"], sum(XUSB_BITS.values()))

    def test_random_report_ranges(self):
        rng = random.Random(2026)
        for _ in range(500):
            p = PadState.from_values(**{key: rng.uniform(-2, 2) for key in CHANNELS})
            r = xbox_report(p)
            for key in ("lx", "ly", "rx", "ry"):
                self.assertTrue(-32768 <= r[key] <= 32767)
            self.assertTrue(0 <= r["lt"] <= 255 and 0 <= r["rt"] <= 255)


if __name__ == "__main__":
    unittest.main()
