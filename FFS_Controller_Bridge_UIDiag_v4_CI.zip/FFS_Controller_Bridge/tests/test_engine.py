"""Deterministic tests: engine time is synthetic milliseconds, never wall time."""
import copy
import math
import random
import unittest

from ffsbridge.engine import MacroEngine, Sequence, Step, snap_vector, local_vector
from ffsbridge.state import PadState, CHANNELS
from tests.helpers import defaults


class SequenceTests(unittest.TestCase):
    def test_step_boundaries_and_late_samples_skip_expired_steps(self):
        seq = Sequence("test", [Step(10, {"b": 1}), Step(20, {"b": 0})], 100)
        p = PadState()
        self.assertEqual(seq.sample(100, p), {"b": 1})
        self.assertEqual(seq.sample(109, p), {"b": 1})
        self.assertEqual(seq.sample(110, p), {"b": 0})
        self.assertIsNone(seq.sample(130, p))
        self.assertIsNone(seq.sample(10000, p))

    def test_confirm_release_is_latched(self):
        seq = Sequence("test", [Step(10, {"b": 1}), Step(10, {"b": 0}),
                                Step(10, {"b": 1, "rb": 1}, True)], 0, confirm_button="b")
        seq.sample(0, PadState.from_values(b=1))
        seq.sample(5, PadState())
        self.assertEqual(seq.sample(20, PadState.from_values(b=1)), {"b": 0, "rb": 0})
        self.assertEqual(seq.sample(25, PadState.from_values(b=1)), {"b": 0, "rb": 0})

    def test_confirm_held_at_decision_is_accepted(self):
        seq = Sequence("test", [Step(10, {"b": 1}, True)], 0, confirm_button="b")
        self.assertEqual(seq.sample(0, PadState.from_values(b=1)), {"b": 1})
        self.assertEqual(seq.sample(1, PadState()), {"b": 1})


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.settings, self.catalog = defaults()

    def engine(self, prime=True):
        e = MacroEngine(self.settings, self.catalog)
        if prime:
            e.tick(PadState(), 0)
        return e

    def shot(self, kind="normal", **changes):
        self.settings["shots"]["enabled"] = True
        self.settings["shots"][kind].update(enabled=True, **changes)

    def test_defaults_exact_passthrough_and_no_input_mutation(self):
        rng = random.Random(431)
        for layout in ("classic", "alternate"):
            self.settings["layout"] = layout
            e = self.engine()
            for now in range(1, 501):
                p = PadState.from_values(**{key: rng.uniform(-1, 1) for key in CHANNELS})
                before = p.copy()
                self.assertEqual(e.tick(p, now * 4), before)
                self.assertEqual(p, before)
                self.assertIsNone(e.sequence)

    def test_startup_and_resume_do_not_fabricate_press(self):
        self.shot()
        e = self.engine(prime=False)
        held = PadState.from_values(b=1)
        self.assertEqual(e.tick(held, 0), held)
        self.assertIsNone(e.sequence)
        e.tick(PadState(), 1)
        e.tick(held, 2)
        self.assertIsNotNone(e.sequence)
        e.set_paused(True)
        self.assertEqual(e.tick(held, 3), held)
        e.set_paused(False)
        self.assertEqual(e.tick(held, 4), held)
        self.assertIsNone(e.sequence)

    def test_charge_suppresses_held_trigger_until_release(self):
        self.shot(charge_ms=100)
        e = self.engine()
        held = PadState.from_values(b=1)
        for now, expected in ((1, 1), (100, 1), (101, 0), (181, 0), (1000, 0)):
            self.assertEqual(e.tick(held, now)["b"], expected)
        self.assertIsNone(e.sequence)
        e.tick(PadState(), 1001)
        self.assertEqual(e.tick(held, 1002)["b"], 1)
        self.assertIsNotNone(e.sequence)

    def test_shot_layout_aliases(self):
        self.shot(charge_ms=50)
        for layout, shoot, cross in (("classic", "b", "x"), ("alternate", "x", "b")):
            self.settings["layout"] = layout
            e = self.engine()
            e.tick(PadState.from_values(**{shoot: 1}), 1)
            self.assertEqual(e.tick(PadState(), 2)[shoot], 1)
            self.assertEqual(e.tick(PadState(), 3)[cross], 0)

    def test_double_shot_confirmation(self):
        self.shot(charge_ms=100, double_tap=True, gap_ms=30, confirm_hold=True)
        for release in (True, False):
            e = self.engine()
            e.tick(PadState.from_values(b=1), 1)
            p = PadState() if release else PadState.from_values(b=1)
            e.tick(p, 50)
            self.assertEqual(e.tick(p, 101)["b"], 0)
            self.assertEqual(e.tick(p, 131)["b"], int(not release))
            self.assertEqual(e.tick(p, 181)["b"], 0)

    def test_one_touch_works_without_shot_master(self):
        self.settings["shots"]["low_driven"]["enabled"] = True
        e = self.engine()
        out = e.tick(PadState.from_values(ls=1), 1)
        self.assertEqual((out["b"], out["ls"]), (1, 0))
        self.assertEqual(e.sequence.name, "one_touch")
        self.assertEqual(e.tick(PadState(), 191)["b"], 0)
        self.assertEqual(e.tick(PadState(), 221)["b"], 1)
        self.assertEqual(e.tick(PadState(), 1000), PadState())

    def test_shot_modifier_precedence(self):
        for i, kind in enumerate(("normal", "chip", "finesse", "flair", "power")):
            self.shot(kind, charge_ms=100 + i)
        for controls, kind in (({}, "normal"), ({"lb": 1}, "chip"), ({"rb": 1}, "finesse"),
                               ({"lt": .4, "rb": 1}, "flair"),
                               ({"lt": .4, "lb": 1, "rb": 1}, "power")):
            with self.subTest(kind=kind):
                e = self.engine()
                e.tick(PadState.from_values(b=1, **controls), 1)
                self.assertEqual(e.sequence.steps[0].duration, self.settings["shots"][kind]["charge_ms"])

    def test_one_touch_precedes_shoot_run_lob_and_r3_skill(self):
        self.settings["shots"]["low_trivela"].update(enabled=True, button="rs")
        self.settings["passes"]["run_lob"].update(enabled=True, button="rs")
        self.settings["skills"]["mapping"]["R3"] = 1
        self.shot()
        e = self.engine()
        out = e.tick(PadState.from_values(rs=1, b=1), 1)
        self.assertEqual(e.sequence.name, "one_touch")
        self.assertEqual((out["lt"], out["rs"]), (1, 0))

    def test_physical_shoot_precedes_pass_and_skill(self):
        self.shot()
        self.settings["passes"]["pass"]["enabled"] = True
        self.settings["skills"]["mapping"]["U"] = 1
        e = self.engine()
        e.tick(PadState.from_values(b=1, a=1, ry=-1), 1)
        self.assertEqual(e.sequence.name, "charge")

    def test_pass_cancels_skill_and_preserves_unrelated_physical_controls(self):
        self.settings["skills"]["mapping"]["U"] = 1
        e = self.engine()
        e.tick(PadState.from_values(ry=-1), 1)
        self.assertTrue(e.sequence.skill)
        p = PadState.from_values(a=1, rt=.6, ry=-1)
        self.assertEqual(e.tick(p, 2), p)
        self.assertIsNone(e.sequence)

    def test_modified_pass_remains_manual(self):
        self.settings["passes"]["pass"]["enabled"] = True
        for modifiers in ({"lb": 1}, {"rb": 1}, {"lt": .2}):
            e = self.engine()
            p = PadState.from_values(a=1, **modifiers)
            self.assertEqual(e.tick(p, 1), p)
            self.assertIsNone(e.sequence)

    def test_pause_menu_and_temporary_bypass_cancel(self):
        self.shot()
        for mode in ("pause", "menu", "bypass"):
            e = self.engine()
            e.tick(PadState.from_values(b=1), 1)
            p = PadState.from_values(lx=.5, rt=1, lt=1)
            if mode == "pause":
                e.set_paused(True)
            elif mode == "menu":
                e.set_menu(True)
            self.assertEqual(e.tick(p, 2), PadState() if mode == "menu" else p)
            self.assertIsNone(e.sequence)
            self.assertIsNone(e.aim)

    def test_shortcuts_edge_triggered_consumed_and_emit_setting(self):
        self.settings["shortcuts"]["enabled"] = True
        e = self.engine()
        p = PadState.from_values(lt=1, left=1)
        for now in (1, 2, 3):
            self.assertEqual(e.tick(p, now)["left"], 0)
        self.assertTrue(e.settings["shots"]["enabled"])
        self.assertEqual(e.events, [{"type": "setting", "path": ["shots", "enabled"], "value": True}])
        self.assertFalse(self.settings["shots"]["enabled"])
        e.tick(PadState(), 4)
        e.tick(p, 5)
        self.assertFalse(e.settings["shots"]["enabled"])

    def test_menu_chord_does_not_repeat_while_held(self):
        self.settings["shortcuts"]["enabled"] = True
        e = self.engine()
        p = PadState.from_values(lt=1, start=1)
        self.assertEqual(e.tick(p, 1), PadState())
        self.assertEqual(e.tick(p, 2), PadState())
        self.assertTrue(e.menu)
        e.tick(PadState(), 3)
        self.assertEqual(e.tick(p, 4)["start"], 0)
        self.assertFalse(e.menu)

    def test_shortcut_precedes_tactic(self):
        self.settings["shortcuts"]["enabled"] = True
        self.settings["tactics"]["offside_trap"] = True
        e = self.engine()
        e.tick(PadState.from_values(lt=1, up=1), 1)
        self.assertGreater(e.corner_until, 1)
        self.assertIsNone(e.sequence)

    def test_corner_is_one_shot_and_can_expire_or_cancel(self):
        e = self.engine()
        e.arm_corner(1)
        out = e.tick(PadState.from_values(x=1, lx=-.5), 2)
        self.assertEqual((out["x"], out["lx"], out["ly"]), (1, -.8, -.08))
        self.assertEqual(e.sequence.name, "cross")
        self.assertEqual(e.corner_until, 0)
        e = self.engine()
        e.arm_corner(1)
        e.arm_corner(2)
        self.assertEqual(e.corner_until, 0)
        e.arm_corner(3)
        e.tick(PadState.from_values(x=1), 30000)
        self.assertIsNone(e.sequence)

    def test_tactics_and_run_lob_release_generated_controls(self):
        for name, trigger in (("team_press", "left"), ("offside_trap", "up"), ("run_lob", "right")):
            settings_before = copy.deepcopy(self.settings)
            if name == "run_lob":
                self.settings["passes"][name]["enabled"] = True
            else:
                self.settings["tactics"][name] = True
            e = self.engine()
            e.tick(PadState.from_values(**{trigger: 1}), 1)
            self.assertEqual(e.sequence.name, name)
            self.assertEqual(e.tick(PadState(), 10000), PadState())
            self.assertIsNone(e.sequence)
            self.settings = settings_before

    def test_precision_through_and_lob(self):
        self.settings["passes"]["precision_pass"] = True
        e = self.engine()
        self.assertEqual(e.tick(PadState.from_values(y=1), 1)["rb"], 1)
        self.assertEqual(e.tick(PadState.from_values(y=1, lb=1), 2)["rb"], 0)
        self.settings["passes"]["precision_lob"] = True
        e = self.engine()
        self.assertEqual(e.tick(PadState.from_values(y=1, lb=1), 1)["rb"], 1)
        self.assertEqual(e.tick(PadState(), 2)["rb"], 0)

    def test_skill_requires_center_then_new_flick(self):
        self.settings["skills"]["mapping"]["U"] = 1
        e = self.engine(prime=False)
        flick = PadState.from_values(ry=-1)
        self.assertEqual(e.tick(flick, 0), flick)
        self.assertIsNone(e.sequence)
        e.tick(PadState(), 1)
        e.tick(flick, 2)
        self.assertTrue(e.sequence.skill)
        self.assertEqual(e.tick(flick, 1000)["ry"], 0)
        self.assertIsNone(e.sequence)
        e.tick(flick, 1001)
        self.assertIsNone(e.sequence)
        e.tick(PadState(), 1002)
        e.tick(flick, 1003)
        self.assertTrue(e.sequence.skill)

    def test_eight_directions_and_r3_mapping(self):
        controls = {"U": (0, -1), "UR": (1, -1), "R": (1, 0), "DR": (1, 1),
                    "D": (0, 1), "DL": (-1, 1), "L": (-1, 0), "UL": (-1, -1)}
        self.settings["skills"]["mapping"].update({k: i for i, k in enumerate(controls, 1)})
        self.settings["skills"]["mapping"]["R3"] = 9
        for direction, (x, y) in controls.items():
            e = self.engine()
            e.tick(PadState.from_values(rx=x, ry=y), 1)
            self.assertTrue(e.sequence.name.startswith(f"Skill {self.settings['skills']['mapping'][direction]}:"))
        e = self.engine()
        self.assertEqual(e.tick(PadState.from_values(rs=1), 1)["rs"], 0)
        self.assertTrue(e.sequence.name.startswith("Skill 9:"))

    def test_skill_scale_rotation_and_mirror(self):
        self.catalog["skills"][0].update(scale_percent=150, mirror_trigger=True, steps=[{"duration_ms": 100, "rs_local": [1, 0]}])
        self.settings["skills"]["mapping"].update(R=1, L=1)
        for x, expected in ((1, (0, 1)), (-1, (0, -1))):
            e = self.engine()
            out = e.tick(PadState.from_values(lx=1, rx=x), 1)
            self.assertEqual((out["rx"], out["ry"]), expected)
            self.assertEqual(e.sequence.steps[0].duration, 150)
            self.assertEqual(e.tick(PadState(), 151), PadState())

    def test_every_bundled_skill_compiles_and_completes_in_both_layouts(self):
        for layout in ("classic", "alternate"):
            self.settings["layout"] = layout
            for skill in self.catalog["skills"]:
                with self.subTest(layout=layout, skill=skill["id"]):
                    self.settings["skills"]["mapping"]["U"] = skill["id"]
                    e = self.engine()
                    e.tick(PadState.from_values(ry=-1), 1)
                    self.assertIsNotNone(e.sequence)
                    durations = [step.duration for step in e.sequence.steps]
                    now = 1
                    for duration in durations:
                        out = e.tick(PadState(), now)
                        self.assertTrue(all(math.isfinite(v) and -1 <= v <= 1 for v in out.as_dict().values()))
                        now += duration
                    self.assertEqual(e.tick(PadState(), now), PadState())
                    self.assertIsNone(e.sequence)

    def test_normal_aim_hold_releases_after_tail(self):
        self.settings["shots"]["normal_hold_ms"] = 100
        e = self.engine()
        e.tick(PadState.from_values(b=1, lx=.7), 1)
        self.assertEqual(e.tick(PadState.from_values(b=1, lx=-1), 50)["lx"], .7)
        self.assertEqual(e.tick(PadState.from_values(lx=-1), 60)["lx"], .7)
        self.assertEqual(e.tick(PadState.from_values(lx=-1), 150)["lx"], -1)
        self.assertIsNone(e.aim)

    def test_hair_trigger_hysteresis_and_perfect_sprint(self):
        self.settings["movement"]["hair_trigger"]["enabled"] = True
        self.settings["movement"]["perfect_sprint"].update(enabled=True, strength_percent=80)
        e = self.engine()
        for now, (rt, expected) in enumerate(((.09, 0), (.10, .8), (.08, .8), (.05, 0)), 1):
            self.assertEqual(e.tick(PadState.from_values(rt=rt), now)["rt"], expected)

    def test_controlled_sprint(self):
        self.settings["movement"]["controlled_sprint"].update(enabled=True, power_percent=50)
        e = self.engine()
        out = e.tick(PadState.from_values(rb=1, lx=1, ly=-.8), 1)
        self.assertEqual((out["lx"], out["ly"]), (.5, -.4))

    def test_repeat_sprint_guard_and_release(self):
        self.settings["movement"]["repeat_sprint"].update(enabled=True, run_ms=100, drop_ms=20, guard_ms=50)
        e = self.engine()
        p = PadState.from_values(lx=1, rt=1)
        for now, expected in ((1, 1), (100, 1), (101, 0), (120, 0), (121, 1)):
            self.assertEqual(e.tick(p, now)["rt"], expected)
        e.tick(PadState.from_values(lx=1, rt=1, a=1), 130)
        self.assertEqual(e.tick(p, 140)["rt"], 1)
        self.assertIsNone(e.pulse_start)
        self.assertEqual(e.tick(PadState(), 1000), PadState())

    def test_quick_step_and_quick_turn(self):
        self.settings["movement"]["quick_step"].update(enabled=True, idle_ms=120, drop_ms=50)
        e = self.engine()
        p = PadState.from_values(lx=1, rt=1)
        self.assertEqual(e.tick(p, 200)["rt"], 0)
        self.assertEqual(e.tick(p, 250)["rt"], 1)
        self.settings["movement"]["quick_step"]["enabled"] = False
        self.settings["movement"]["quick_turn"].update(enabled=True, mode="controlled", drop_ms=80)
        e = self.engine()
        e.tick(p, 1)
        turn = PadState.from_values(lx=-1, rt=1)
        out = e.tick(turn, 2)
        self.assertEqual((out["rt"], out["rb"]), (0, 1))
        self.assertEqual(e.tick(turn, 82), turn)

    def test_nonmonotonic_and_nonfinite_time_rejected(self):
        e = self.engine()
        for now in (-1, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                e.tick(PadState(), now)

    def test_settings_and_catalog_owned_by_engine(self):
        e = self.engine()
        self.catalog["skills"][0]["steps"][0]["duration_ms"] = 999
        self.settings["shots"]["enabled"] = True
        self.assertFalse(e.settings["shots"]["enabled"])
        self.assertNotEqual(e.skills[1]["steps"][0]["duration_ms"], 999)


class AimMathTests(unittest.TestCase):
    def test_local_rotation(self):
        self.assertEqual(local_vector((0, 1), (0, -1)), (0, -1))
        self.assertEqual(local_vector((0, 1), (1, 0)), (1, 0))
        self.assertEqual(local_vector((1, 0), (0, -1), True), (-1, 0))

    def test_snap_math_quadrants_and_degenerate_input(self):
        settings, _ = defaults()
        profile = settings["snap"]["flair"]
        self.assertIsNone(snap_vector(.25, 1, profile))
        for power in (True, False):
            for target in ("near", "far"):
                profile["target"] = target
                for x in (-1, -.3, .3, 1):
                    for y in (-1, 0, 1):
                        result = snap_vector(x, y, profile, power)
                        if result is not None:
                            self.assertTrue(all(math.isfinite(v) and -1 <= v <= 1 for v in result))
                            self.assertEqual(math.copysign(1, result[0]), math.copysign(1, x))


if __name__ == "__main__":
    unittest.main()
