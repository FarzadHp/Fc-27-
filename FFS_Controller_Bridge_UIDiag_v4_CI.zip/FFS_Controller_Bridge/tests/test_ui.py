"""GUI regressions; run on Windows or with Tk and a display (e.g. Xvfb)."""
import queue
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

try:
    import tkinter as tk
    from tkinter import ttk
    from ffsbridge.ui import BridgeApp
except ImportError:
    tk = None

from ffsbridge.config import ConfigStore
from ffsbridge.state import PadState


@unittest.skipIf(tk is None, "Tk libraries unavailable")
class SettingsFormTests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(str(exc))
        self.addCleanup(self.root.destroy)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        service = SimpleNamespace(
            events=queue.Queue(),
            snapshot=lambda: {
                "running": False,
                "input": PadState().as_dict(),
                "output": PadState().as_dict(),
                "activity": "Stopped",
            },
        )
        # Do not start a worker or periodic polling; event tests poll explicitly.
        with patch.object(BridgeApp, "_poll"):
            self.app = BridgeApp(self.root, ConfigStore(self.temp.name), service, auto_scan=False)
        self.app.tabs.select(0)
        self.root.update()

    def select(self, name):
        box = self.app.group_box
        box.selection_clear(0, "end")
        box.selection_set(self.app.groups.index(name))
        self.app._show_group()
        self.root.update()

    def test_repeated_switch_after_scroll_keeps_fields_and_edits(self):
        path = ("passes", "pass", "charge_ms")
        self.app.form_vars[path].set("321")
        for busy in (False, True, False):
            self.app._set_busy(busy)
            for _ in range(5):
                self.select("Skills")
                self.app.form_canvas.yview_moveto(1)
                self.select("Passes")
                fields = [w for w in self.app.form.winfo_children()
                          if isinstance(w, (ttk.Entry, ttk.Checkbutton))]
                expected = sum(p[0] == "passes" for p in self.app.field_schemas)
                self.assertEqual(len(fields), expected)
                self.assertTrue(all(w.winfo_ismapped() for w in fields))
                self.assertLessEqual(self.app.form_canvas.canvasy(0), 1)
                self.assertEqual(self.app.form_vars[path].get(), "321")

    def test_primary_actions_remain_visible_at_minimum_size(self):
        self.root.geometry("850x630")
        self.root.update()
        for widget in (self.app.start_button, self.app.apply_button, self.app.scan_button):
            self.assertTrue(widget.winfo_ismapped())
            self.assertGreater(widget.winfo_width(), 20)
            self.assertLessEqual(widget.winfo_rootx() + widget.winfo_width(),
                                 self.root.winfo_rootx() + self.root.winfo_width())
        self.assertGreater(self.app.form_canvas.winfo_height(), 100)
        self.assertFalse(self.app.log_box.winfo_ismapped())

    def test_failed_rebuild_keeps_previous_form(self):
        previous = self.app.form
        with patch.object(self.app, "_build_group", side_effect=ValueError("test")):
            with self.assertRaises(ValueError):
                self.app._show_group()
        self.assertIs(self.app.form, previous)
        self.assertTrue(previous.winfo_exists())
        self.assertTrue(previous.winfo_children())

    def test_refresh_preserves_explicit_selection_but_not_replaced_device(self):
        from ffsbridge.input_sdl import Device
        device = Device(7, "Physical", "guid", True)
        self.app.devices = [device]
        self.app.device_box.configure(values=[device.label])
        self.app.device_box.current(0)
        self.app.service.events.put({"type": "devices", "devices": [device]})
        self.app._poll_events()
        self.assertEqual(self.app.device_box.current(), 0)
        replacement = Device(8, "Physical", "guid", True)
        self.app.service.events.put({"type": "devices", "devices": [replacement]})
        self.app._poll_events()
        self.assertEqual(self.app.device_box.current(), -1)

    def test_stop_reenables_start_and_preserves_error(self):
        self.app._set_busy(True)
        self.app.service.events.put({"type": "error", "message": "Driver test failure"})
        self.app.service.events.put({"type": "stopped"})
        self.app._poll_events()
        self.assertFalse(self.app.busy)
        self.assertEqual(str(self.app.start_button["state"]), "normal")
        self.assertEqual(str(self.app.scan_button["state"]), "normal")
        self.assertIn("Driver test failure", self.app.status.get())

    def test_poll_reschedules_after_callback_failure(self):
        with patch.object(self.app, "_poll_events", side_effect=RuntimeError("test")):
            with self.assertLogs("ffsbridge.ui", level="ERROR"):
                self.app._poll()
        self.assertIsNotNone(self.app.poll_job)
        self.root.after_cancel(self.app.poll_job)

    def test_refresh_is_not_queued_twice(self):
        from unittest.mock import Mock
        self.app.service.request = Mock()
        self.app.scan()
        self.app.scan()
        self.app.service.request.assert_called_once()
        self.assertEqual(str(self.app.start_button["state"]), "disabled")
        self.app.service.events.put({"type": "devices", "devices": []})
        self.app._poll_events()
        self.assertFalse(self.app.scanning)
        self.assertEqual(str(self.app.start_button["state"]), "normal")

    def test_short_form_wheel_does_not_hide_fields(self):
        # Use an actually short fixture, not the production Snap group: its
        # height depends on fonts/DPI, and Windows may cap oversized windows
        # to the monitor work area.
        def build_short_form(form, group):
            ttk.Checkbutton(form, text="Short form option").grid(row=0, column=0)

        with patch.object(self.app, "_build_group", side_effect=build_short_form):
            self.select("Snap")
        self.root.update()
        self.assertLess(self.app.form.winfo_height(), self.app.form_canvas.winfo_height())
        event = SimpleNamespace(widget=self.app.form_canvas, delta=-120)
        for _ in range(50):
            self.app._wheel(event)
        self.root.update()
        self.assertLessEqual(self.app.form_canvas.canvasy(0), 1)
