"""Hardware-free integration tests using real input/output worker threads."""
import queue
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from ffsbridge.input_sdl import Device, InputDisconnected
from ffsbridge.output import OutputPump
from ffsbridge.service import BridgeService
from ffsbridge.state import PadState
from tests.helpers import RecordingOutput, defaults, eventually


DEVICE = Device(17, "Physical test controller", "0123456789abcdef", True)


class FakeInput:
    def __init__(self, trace):
        self.trace = trace
        self.created_on = threading.get_ident()
        self.device = None
        self.state = PadState.from_values(a=1, lx=.25, rt=.5)
        self.open_entered = threading.Event()
        self.read_entered = threading.Event()
        self.allow_open = threading.Event()
        self.allow_read = threading.Event()
        self.allow_open.set()
        self.allow_read.set()
        self.read_error = None
        self.open_error = None
        self.closed = False

    def record(self, name):
        self.trace.append((name, threading.get_ident()))

    def load_mappings(self, path):
        self.record("mappings")
        self.mapping_path = path

    def devices(self):
        self.record("devices")
        return [DEVICE]

    def open(self, device):
        self.record("open")
        self.open_entered.set()
        if not self.allow_open.wait(5):
            raise TimeoutError("test open gate")
        if self.open_error:
            raise self.open_error
        self.device = device
        return device

    def read(self, deadzone):
        self.record("read")
        self.read_entered.set()
        if not self.allow_read.wait(5):
            raise TimeoutError("test read gate")
        if self.read_error:
            raise self.read_error
        return self.state.copy()

    def close_device(self):
        self.record("close_device")
        self.device = None

    def close(self):
        self.record("close")
        self.closed = True


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.trace, self.sinks = [], []
        self.input = None
        self.input_setup = lambda backend: None
        self.sink_class = RecordingOutput
        self.factory_error = None
        self.factory_entered = threading.Event()
        self.allow_factory = threading.Event()
        self.allow_factory.set()
        self.settings, self.catalog = defaults()
        self.settings["input"]["watchdog_ms"] = 1000
        self.service = BridgeService(self.temp.name, self.input_factory, self.output_factory)
        self.addCleanup(self.finish)
        logger = patch("ffsbridge.service.log.exception")
        logger.start()
        self.addCleanup(logger.stop)

    def input_factory(self):
        self.input = FakeInput(self.trace)
        self.input_setup(self.input)
        return self.input

    def output_factory(self):
        self.trace.append(("output_create", threading.get_ident()))
        self.factory_entered.set()
        if not self.allow_factory.wait(5):
            raise TimeoutError("test factory gate")
        if self.factory_error:
            raise self.factory_error
        sink = self.sink_class()
        self.sinks.append(sink)
        return sink

    def finish(self):
        if self.input:
            self.input.allow_open.set()
            self.input.allow_read.set()
        self.allow_factory.set()
        self.service.shutdown()
        self.service.thread.join(4)
        eventually(lambda: not self.service.alive)
        self.assertFalse(self.service.thread.is_alive())

    def event(self, kind, text="", timeout=4):
        deadline = time.monotonic() + timeout
        seen = []
        while time.monotonic() < deadline:
            try:
                event = self.service.events.get(timeout=max(.001, deadline - time.monotonic()))
            except queue.Empty:
                break
            seen.append(event)
            if event["type"] == kind and text in event.get("message", ""):
                return event
        self.fail(f"Missing event {kind!r} {text!r}; received {seen}")

    def start(self):
        self.service.start(DEVICE, self.settings, self.catalog)
        self.event("running")
        eventually(lambda: self.service.snapshot()["running"])
        return self.sinks[-1]

    def scan_barrier(self):
        self.service.request("scan", mapping_file="")
        return self.event("devices")

    def test_repeated_start_stop_without_rescan(self):
        for _ in range(5):
            sink = self.start()
            self.service.stop()
            self.event("stopped")
            self.assertTrue(sink.closed.wait(2))
            self.assertFalse(self.service.snapshot()["running"])

    def test_apply_keeps_output_and_pause(self):
        sink = self.start()
        self.service.request("pause", value=True)
        eventually(lambda: self.service.snapshot().get("paused"))
        self.settings["input"]["deadzone"] = .15
        self.service.apply(self.settings, self.catalog)
        self.event("applied")
        self.assertEqual(self.service.engine.settings["input"]["deadzone"], .15)
        self.assertTrue(self.service.engine.paused)
        self.assertEqual(len(self.sinks), 1)
        self.assertFalse(sink.closed.is_set())

    def test_apply_restart_only_setting_rejected_without_stop(self):
        self.start()
        old = self.service.engine
        self.settings["input"]["watchdog_ms"] = 900
        self.service.apply(self.settings, self.catalog)
        self.event("apply_rejected")
        self.assertIs(self.service.engine, old)
        self.assertTrue(self.service.snapshot()["running"])

    def test_thread_ownership_start_order_passthrough_stop_and_restart(self):
        sink = self.start()
        eventually(lambda: sink.seen("a", 1))
        snapshot = self.service.snapshot()
        self.assertEqual(snapshot["input"], snapshot["output"])
        snapshot["output"]["a"] = 0
        self.assertEqual(self.service.snapshot()["output"]["a"], 1)
        names = [name for name, _ in self.trace]
        self.assertLess(names.index("open"), names.index("output_create"))
        self.service.stop()
        self.assertTrue(sink.closed.wait(3))
        self.scan_barrier()
        self.assertEqual(sink.last(), PadState())
        self.assertFalse(self.service.snapshot()["running"])
        second = self.start()
        self.assertIsNot(second, sink)
        self.service.shutdown()
        self.event("closed")
        self.assertTrue(self.input.closed)
        self.assertEqual({tid for name, tid in self.trace if name != "output_create"},
                         {self.service.thread.ident})
        for output in self.sinks:
            self.assertEqual(set(output.threads), {output.created_on})
            self.assertNotEqual(output.created_on, self.input.created_on)
            self.assertEqual(output.last(), PadState())

    def test_scan_and_relative_mapping_path(self):
        self.service.request("scan", mapping_file="mappings/gamecontrollerdb.txt")
        self.assertEqual(self.event("devices")["devices"], [DEVICE])
        self.assertEqual(Path(self.input.mapping_path),
                         Path(self.temp.name) / "mappings/gamecontrollerdb.txt")
        self.assertEqual(self.sinks, [])

    def test_invalid_config_rejected_before_opening_hardware(self):
        self.settings["input"]["poll_ms"] = 0
        self.service.start(DEVICE, self.settings, self.catalog)
        self.event("error", "poll_ms")
        self.scan_barrier()
        self.assertNotIn("open", [name for name, _ in self.trace])
        self.assertEqual(self.sinks, [])

    def test_open_failure_never_creates_output(self):
        self.input_setup = lambda backend: setattr(backend, "open_error", InputDisconnected("gone"))
        self.service.start(DEVICE, self.settings, self.catalog)
        self.event("error", "gone")
        self.scan_barrier()
        self.assertEqual(self.sinks, [])
        self.assertIsNone(self.input.device)

    def test_stop_cancels_blocked_open_before_output_creation(self):
        self.input_setup = lambda backend: backend.allow_open.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        eventually(lambda: self.input is not None and self.input.open_entered.is_set())
        self.service.stop()
        self.input.allow_open.set()
        self.scan_barrier()
        self.assertEqual(self.sinks, [])
        self.assertIsNone(self.input.device)

    def test_stop_cancels_superseded_and_queued_starts(self):
        self.input_setup = lambda backend: backend.allow_open.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        eventually(lambda: self.input is not None and self.input.open_entered.is_set())
        self.service.start(DEVICE, self.settings, self.catalog)
        self.service.stop()
        self.input.allow_open.set()
        self.scan_barrier()
        self.assertEqual(self.sinks, [])
        self.assertEqual([name for name, _ in self.trace].count("open"), 1)

    def test_start_and_stop_command_publication_is_serialized(self):
        entered, release, stopped = threading.Event(), threading.Event(), threading.Event()
        self.addCleanup(release.set)
        self.input_setup = lambda backend: backend.allow_open.clear()
        original = self.service.request

        def delayed(kind, **data):
            if kind == "start":
                entered.set()
                if not release.wait(3):
                    raise TimeoutError("test publication gate")
            original(kind, **data)

        with patch.object(self.service, "request", side_effect=delayed):
            starter = threading.Thread(target=lambda: self.service.start(DEVICE, self.settings, self.catalog))
            stopper = threading.Thread(target=lambda: (self.service.stop(), stopped.set()))
            starter.start()
            self.assertTrue(entered.wait(3))
            stopper.start()
            self.assertFalse(stopped.wait(.03))  # Cannot overtake start publication.
            release.set()
            starter.join(3)
            stopper.join(3)
        self.assertFalse(starter.is_alive())
        self.assertFalse(stopper.is_alive())
        if self.input:
            self.input.allow_open.set()
        self.scan_barrier()
        self.assertEqual(self.sinks, [])

    def test_start_payload_is_a_snapshot(self):
        self.input_setup = lambda backend: backend.allow_open.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        eventually(lambda: self.input is not None and self.input.open_entered.is_set())
        self.settings["layout"] = "invalid-after-queue"
        self.catalog["skills"].clear()
        self.input.allow_open.set()
        self.event("running")
        eventually(lambda: self.service.snapshot()["running"])
        self.assertEqual(self.service.engine.settings["layout"], "classic")
        self.assertEqual(len(self.service.engine.catalog["skills"]), 15)

    def test_output_initialization_failure_closes_input(self):
        self.factory_error = RuntimeError("driver injected")
        self.service.start(DEVICE, self.settings, self.catalog)
        self.event("error", "driver injected")
        self.scan_barrier()
        self.assertIsNone(self.input.device)
        self.assertIsNone(self.service.pump)

    def test_stop_during_output_initialization_never_sends_physical_controls(self):
        self.allow_factory.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        self.assertTrue(self.factory_entered.wait(3))
        self.service.stop()
        self.allow_factory.set()
        self.scan_barrier()
        self.assertEqual(len(self.sinks), 1)
        self.assertTrue(self.sinks[0].closed.is_set())
        self.assertTrue(all(p == PadState() for p in self.sinks[0].reports))

    def test_stop_neutralizes_without_waiting_for_blocked_input(self):
        sink = self.start()
        eventually(lambda: sink.seen("a", 1))
        self.input.read_entered.clear()
        self.input.allow_read.clear()
        self.assertTrue(self.input.read_entered.wait(3))
        self.service.stop()
        self.assertTrue(sink.closed.wait(3))
        self.assertEqual(sink.last(), PadState())
        self.input.allow_read.set()
        self.scan_barrier()
        self.assertFalse(self.service.snapshot()["running"])

    def test_watchdog_neutralizes_a_blocked_first_input_read(self):
        self.settings["input"]["watchdog_ms"] = 100
        self.input_setup = lambda backend: backend.allow_read.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        self.event("running")
        eventually(lambda: self.input.read_entered.is_set())
        self.assertTrue(self.sinks[0].closed.wait(3))
        self.assertEqual(self.sinks[0].last(), PadState())
        self.input.allow_read.set()
        self.event("error", "watchdog")
        self.scan_barrier()
        self.assertIsNone(self.input.device)

    def test_disconnect_stops_and_does_not_automatically_reconnect(self):
        sink = self.start()
        self.input.read_error = InputDisconnected("unplug injected")
        self.event("error", "unplug injected")
        self.assertTrue(sink.closed.wait(3))
        self.scan_barrier()
        self.assertEqual(sink.last(), PadState())
        self.assertEqual([name for name, _ in self.trace].count("open"), 1)

    def test_pause_menu_and_arm_commands(self):
        sink = self.start()
        self.service.request("pause", value=True)
        eventually(lambda: self.service.snapshot().get("paused"))
        self.assertEqual(self.service.snapshot()["input"], self.service.snapshot()["output"])
        self.service.request("pause", value=False)
        self.service.request("corner")
        eventually(lambda: self.service.snapshot().get("corner"))
        self.service.request("menu", value=True)
        eventually(lambda: self.service.snapshot().get("menu"))
        eventually(lambda: sink.last() == PadState())
        self.assertFalse(self.service.snapshot()["corner"])
        self.service.request("menu", value=False)
        eventually(lambda: sink.last().down("a"))

    def test_scan_while_active_fails_closed(self):
        sink = self.start()
        self.service.request("scan")
        self.event("error", "Stop virtual output")
        self.assertTrue(sink.closed.wait(3))
        self.assertEqual(sink.last(), PadState())

    def test_unresponsive_previous_output_blocks_restart(self):
        close_entered, allow_close = threading.Event(), threading.Event()
        self.addCleanup(allow_close.set)

        class SlowClose(RecordingOutput):
            def close(self):
                close_entered.set()
                allow_close.wait(4)
                super().close()

        self.sink_class = SlowClose
        sink = self.start()
        original_stop = OutputPump.stop
        with patch.object(OutputPump, "stop", lambda pump: original_stop(pump, .02)):
            self.service.stop()
            self.assertTrue(close_entered.wait(3))
            self.event("error", "unresponsive")
            self.service.start(DEVICE, self.settings, self.catalog)
            self.event("error", "Previous output")
            self.assertEqual(len(self.sinks), 1)
            allow_close.set()
            self.assertTrue(sink.closed.wait(3))
        self.service.stop()
        self.scan_barrier()

    def test_shutdown_cancels_blocked_start_and_rejects_new_starts(self):
        self.input_setup = lambda backend: backend.allow_open.clear()
        self.service.start(DEVICE, self.settings, self.catalog)
        eventually(lambda: self.input is not None and self.input.open_entered.is_set())
        self.service.shutdown()
        self.input.allow_open.set()
        self.event("closed")
        self.assertEqual(self.sinks, [])
        self.assertTrue(self.input.closed)
        with self.assertRaisesRegex(RuntimeError, "shutting down"):
            self.service.start(DEVICE, self.settings, self.catalog)


if __name__ == "__main__":
    unittest.main()
