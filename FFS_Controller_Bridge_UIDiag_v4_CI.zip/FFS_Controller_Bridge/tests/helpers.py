import threading
import time

from ffsbridge.config import ConfigStore, bundled_data, read_json
from ffsbridge.state import PadState


def defaults():
    return ConfigStore().defaults(), read_json(bundled_data() / "catalog.json")


def eventually(predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(.005)
    raise AssertionError("Timed out waiting for asynchronous test condition")


class RecordingOutput:
    def __init__(self):
        self.reports = []
        self.threads = []
        self.closed = threading.Event()
        self.lock = threading.Lock()
        self.created_on = threading.get_ident()

    def send(self, state):
        with self.lock:
            self.reports.append(state.copy())
            self.threads.append(threading.get_ident())

    def close(self):
        self.threads.append(threading.get_ident())
        self.closed.set()

    def seen(self, key, value):
        with self.lock:
            return any(p[key] == value for p in self.reports)

    def last(self):
        with self.lock:
            return self.reports[-1].copy() if self.reports else PadState()
