# نتیجهٔ آزمون‌ها

تاریخ: 2026-11-17؛ محیط: **Linux** (Ubuntu 24.04)، Python 3.12.3، Tk/Tcl 8.6.14 با **Xvfb**. نه Windows، نه Python 3.11.9، نه Tcl 8.6.12.

| اجرا | نتیجه |
|---|---|
| `xvfb-run python -m unittest discover -s tests` | **137 تست، OK؛ 1 skip** (`test_process_resources_on_windows`، فقط Windows) |
| همان دستور بدون DISPLAY | 137 تست، OK؛ 24 skip (همهٔ تست‌های Tk) |
| `tests.test_ui_regression tests.test_ui tests.test_stress_tool` سه بار پشت‌سرهم | هر سه OK (بدون ناپایداری) |
| `python -m compileall -q ffsbridge tools tests` | موفق |
| `python -m ffsbridge --check-config` | موفق |
| `python -m ffsbridge --no-scan --debug` زیر Xvfb، ۱٫۵ثانیه | شروع/خروج سالم؛ خطوط `resources[startup]` ثبت شد؛ `faulthandler.log` خالی حذف شد |
| `tools/stress_ui.py` حالت fake، ۴۰۰ تا ۷۰۰ تعامل (۳ اجرا، seedهای ۱ و ۳ و ۷) | PASS؛ ۱۸ Start، ۱۶ Stop، ۲۲ Apply، ۱۲ Refresh، ۴۶ resize، ۲۶ minimize؛ ویجت/after/commands/thread در حالت ثابت کاملاً برگشتند |

## تست‌های regression جدید
`tests/test_ui_regression.py` (12)، `tests/test_diagnostics.py` (14)، `tests/test_build_script.py` (3)، `tests/test_stress_tool.py` (2).
شش تست رابط جدید روی `ui.py` **قبلی** اجرا شد و پنج مورد شکست خورد (عدم همگامی فهرست/فرم، جدول Live I/O، ۲۴ idle معلق، ۱۰۰ لاگ، تغییر مقدار Combobox با چرخ). تست‌های «رشد ویجت» روی کد قبلی هم گذشتند: در Linux نشتی دیده نشد.

## اجرا نشده / تأییدنشده
- هیچ GUI واقعی روی Windows؛ هیچ اندازه‌گیری USER/GDI/HWND؛ کد `ctypes` آن‌ها (`diagnostics.process_resources`, `native_window_count`) روی Windows اجرا نشده.
- رفتار `faulthandler` روی `Tcl_Panic` ویندوز؛ فقط SIGSEGV در Linux تأیید شد.
- ساخت PyInstaller، تست EXE، SDL با کنترلر واقعی، ViGEmBus و خروجی واقعی Xbox.
- اصلاح مشکل تصویری روی Windows و علت کرش `menu window`: **هنوز تأیید نشده**.
