"""CLI/GUI entry point. Diagnostics never create a virtual gamepad."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import ctypes
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sys
import threading

from . import __version__, diagnostics
from .paths import default_config_dir

log = logging.getLogger(__name__)


@contextmanager
def session_logging(directory: Path, debug=False):
    """Own only our handlers; do not change a host application's root logger."""
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "bridge.log"
    file_handler = RotatingFileHandler(path, maxBytes=1_000_000, backupCount=3,
                                      encoding="utf-8", errors="backslashreplace")
    handlers = [file_handler]
    logger = logging.getLogger("ffsbridge")
    old_level, old_propagate = logger.level, logger.propagate
    old_thread_hook, old_unraisable_hook = threading.excepthook, sys.unraisablehook
    try:
        if sys.stderr is not None:
            handlers.append(logging.StreamHandler(sys.stderr))
        formatter = logging.Formatter("%(asctime)s %(levelname)s [%(threadName)s] %(name)s: %(message)s")
        logger.setLevel(logging.DEBUG if debug else logging.INFO)
        logger.propagate = False
        for handler in handlers:
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        def thread_failure(args):
            log.critical("Unhandled exception in thread %s", args.thread.name if args.thread else "unknown",
                         exc_info=(args.exc_type, args.exc_value, args.exc_traceback))

        def unraisable_failure(args):
            # Errors in __del__/destructors (e.g. a Tk Variable collected on a non-Tk thread)
            # are otherwise dropped silently: a windowed EXE has no stderr.
            log.error("Unraisable exception in %r: %s", args.object, args.err_msg or "",
                      exc_info=(args.exc_type, args.exc_value, args.exc_traceback))

        threading.excepthook = thread_failure
        sys.unraisablehook = unraisable_failure
        yield path
    finally:
        threading.excepthook = old_thread_hook
        sys.unraisablehook = old_unraisable_hook
        for handler in handlers:
            logger.removeHandler(handler)
            handler.close()
        logger.setLevel(old_level)
        logger.propagate = old_propagate


def notify_error(message: str, dialog: bool):
    """Native Windows dialog still works if Tk or a Python dependency is missing."""
    if sys.stderr is not None:
        try:
            sys.stderr.write(message + "\n")
        except (OSError, UnicodeError):
            pass
    if dialog and sys.platform == "win32":
        try:
            ctypes.windll.user32.MessageBoxW(None, message, "FFS Controller Bridge", 0x10)
        except Exception:
            pass  # Never replace the original failure with a reporting failure.


def list_devices(store, settings):
    from .input_sdl import SDLInput

    backend = SDLInput()
    try:
        mapping = settings["input"]["mapping_file"]
        if mapping:
            path = Path(mapping).expanduser()
            if not path.is_absolute():
                path = store.directory / path
            backend.load_mappings(str(path))
        devices = backend.devices()
        log.info("SDL controllers: %d (enumeration only; no virtual output)", len(devices))
        for device in devices:
            log.info("%s", device.label)
    finally:
        backend.close()


def tk_callback_reporter(root, service, errors):
    """Tk's report_callback_exception: full traceback + object counts, then a safe stop.

    Tk would otherwise print to stderr, which does not exist in the windowed EXE.
    """
    def report(kind, error, traceback):
        log.error("Unhandled Tk callback exception; stopping bridge",
                  exc_info=(kind, error, traceback))
        errors.append(error)
        try:
            diagnostics.log_snapshot(root, "callback-failure", logging.ERROR)
            service.shutdown()
        finally:
            root.quit()

    return report


def run_gui(store, auto_scan=True):
    # Lazy imports keep --help, --version and --check-config independent of Tk/SDL.
    import tkinter as tk
    from .service import BridgeService
    from .ui import BridgeApp

    root = tk.Tk()
    service = None
    callback_errors = []
    shutdown_failed = False
    try:
        log.info("Tk %s (Tcl %s) | patchlevel %s", tk.TkVersion, tk.TclVersion, root.tk.call("info", "patchlevel"))
        service = BridgeService(store.directory)
        root.report_callback_exception = tk_callback_reporter(root, service, callback_errors)
        diagnostics.warm_up_tk_menu(root)
        BridgeApp(root, store, service=service, auto_scan=auto_scan)
        diagnostics.log_snapshot(root, "startup")
        root.mainloop()
    finally:
        try:
            if service is not None:
                service.shutdown()
                service.thread.join(timeout=4.0)
                shutdown_failed = service.alive
                if shutdown_failed:
                    log.error("Worker unresponsive: neutral output/device removal could NOT be confirmed")
        finally:
            try:
                root.destroy()
            except tk.TclError:
                pass  # Normal UI close may already have destroyed the root.
    if callback_errors:
        raise RuntimeError("The interface failed; the bridge was asked to stop. See the log.") from callback_errors[0]
    if shutdown_failed:
        raise RuntimeError("A worker did not stop. Check Windows controllers before using the game.")


def parser():
    result = argparse.ArgumentParser(description="FFS Controller Bridge: SDL2 -> JSON macros -> Xbox 360")
    result.add_argument("--version", action="version", version=f"FFS Controller Bridge {__version__}")
    result.add_argument("--config-dir", type=Path, help="Writable settings/catalog/log directory")
    modes = result.add_mutually_exclusive_group()
    modes.add_argument("--check-config", action="store_true", help="Initialize/validate JSON, then exit; no hardware or GUI")
    modes.add_argument("--list-devices", action="store_true", help="List SDL controllers, then exit; no virtual output")
    result.add_argument("--no-scan", action="store_true", help="Open the editor without automatic SDL enumeration")
    result.add_argument("--debug", action="store_true", help="Enable detailed file/console logging")
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    dialog = not (args.check_config or args.list_devices)
    log_path = None
    try:
        directory = (args.config_dir if args.config_dir is not None else default_config_dir()).expanduser().resolve()
        with session_logging(directory / "logs", args.debug) as log_path:
            fault_path = None
            try:
                if not (args.check_config or args.list_devices):
                    fault_path = diagnostics.enable_faulthandler(directory / "logs")
                log.info("FFS Controller Bridge %s | Python %s | %s | frozen=%s",
                         __version__, sys.version.split()[0], sys.platform, bool(getattr(sys, "frozen", False)))
                log.info("Config: %s | Log: %s", directory, log_path)
                from .config import ConfigStore

                store = ConfigStore(directory)
                settings, catalog = store.load()
                log.info("Configuration OK: %d skills; existing settings preserved", len(catalog["skills"]))
                if args.check_config:
                    return 0
                if args.list_devices:
                    list_devices(store, settings)
                else:
                    run_gui(store, auto_scan=not args.no_scan)
                log.info("Closed")
                return 0
            except KeyboardInterrupt:
                log.warning("Interrupted; shutdown requested")
                return 130
            except Exception:
                log.exception("Application failed")
                raise
            finally:
                if fault_path is not None:
                    diagnostics.disable_faulthandler()
    except Exception as exc:
        detail = f"\nLog: {log_path}" if log_path is not None else "\nCould not initialize logging. Check --config-dir permissions."
        notify_error(f"FFS Controller Bridge could not continue:\n{exc}{detail}", dialog)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
