"""Paths shared by the launcher and config store; no third-party imports."""
from __future__ import annotations

import os
from pathlib import Path
import sys


def bundled_data() -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    return base / "data"


def default_config_dir() -> Path:
    if sys.platform == "win32":
        root = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return root / "FFSControllerBridge"
