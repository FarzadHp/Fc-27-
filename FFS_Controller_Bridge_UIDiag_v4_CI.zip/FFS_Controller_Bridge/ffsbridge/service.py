"""Thread boundary between Tk, SDL, the macro engine and virtual output."""
from __future__ import annotations

import copy
import logging
from pathlib import Path
import queue
import threading
import time

from .config import ConfigStore
from .engine import MacroEngine
from .input_sdl import SDLInput
from .output import OutputPump, PreviewOutput, XboxOutput
from .state import PadState

log = logging.getLogger(__name__)


class BridgeService:
    def __init__(self, config_dir, input_factory=SDLInput, output_factory=None):
        self.config_dir = Path(config_dir)
        self.input_factory = input_factory
        self.output_factory = output_factory
        self.commands = queue.Queue()
        self.events = queue.Queue()
        self.closing = threading.Event()
        self.cancel_start = threading.Event()
        self.session_token = None
        self.control_lock = threading.Lock()
        self.backend = None
        self.pump = None
        self.engine = None
        self.lock = threading.Lock()
        self.telemetry = {"running": False, "input": PadState().as_dict(),
                          "output": PadState().as_dict(), "activity": "Stopped"}
        self.thread = threading.Thread(target=self._run, name="FFS-input", daemon=True)
        self.thread.start()

    def request(self, kind, **values):
        self.commands.put((kind, values))

    def start(self, device, settings, catalog, preview=True):
        with self.control_lock:
            if self.closing.is_set():
                raise RuntimeError("Bridge is shutting down")
            if not self.thread.is_alive():
                raise RuntimeError("Bridge worker is closed. Close and reopen the application.")
            # A new request supersedes earlier queued/blocked starts. Stop must
            # cancel ALL pending starts, not just the most recently stored token.
            self.cancel_start.set()
            token = threading.Event()
            self.cancel_start = token
            self.request("start", device=device, settings=copy.deepcopy(settings),
                         catalog=copy.deepcopy(catalog), preview=preview, token=token)

    def apply(self, settings, catalog):
        settings, catalog = copy.deepcopy(settings), copy.deepcopy(catalog)
        ConfigStore(self.config_dir).validate(settings, catalog)
        self.request("apply", settings=settings, catalog=catalog)

    def _apply(self, data):
        old = self.engine
        if old is None or self.session_token.is_set():
            self._emit("apply_rejected", message="Bridge stopped; Start to use the edited settings.")
            return
        for key in ("mapping_file", "watchdog_ms"):
            if data["settings"]["input"][key] != old.settings["input"][key]:
                self._emit("apply_rejected", message=f"Changing input.{key} requires Stop then Start.")
                return
        replacement = MacroEngine(data["settings"], data["catalog"])
        replacement.paused, replacement.menu = old.paused, old.menu
        replacement.facing = old.facing
        old.cancel()
        self.engine = replacement
        self._emit("applied")

    def stop(self):
        with self.control_lock:
            self.cancel_start.set()
            if self.session_token is not None:
                self.session_token.set()
            pump = self.pump
            if pump is not None:
                pump.request_stop()  # Do not wait for the input thread to unblock.
            self.request("stop")

    def shutdown(self):
        self.closing.set()
        self.stop()

    @property
    def alive(self):
        return self.thread.is_alive() or (self.pump is not None and self.pump.alive)

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self.telemetry)

    def _emit(self, kind, **data):
        self.events.put({"type": kind, **data})

    def _backend(self, mapping_file):
        if self.backend is None:
            self.backend = self.input_factory()
        path = Path(mapping_file).expanduser() if mapping_file else None
        if path is not None and not path.is_absolute():
            path = self.config_dir / path
        self.backend.load_mappings(str(path) if path is not None else "")
        return self.backend

    def _cleanup(self):
        had_session = self.engine is not None or self.pump is not None
        if had_session:
            log.info("Session cleanup: neutral output, then release output and input")
        if self.engine is not None:
            self.engine.cancel()
        self.engine = None
        self.session_token = None
        pump = self.pump
        if pump is not None:
            if pump.stop():
                self.pump = None
                if pump.error:
                    self._emit("error", message=pump.error)
            else:
                self._emit("error", message="Output thread is unresponsive. Restart is blocked; close the app and check the driver.")
        if self.backend is not None:
            try:
                self.backend.close_device()
            except Exception as exc:
                log.exception("Input cleanup failed")
                self._emit("error", message=f"Input cleanup failed: {exc}")
        with self.lock:
            self.telemetry = {"running": False, "input": PadState().as_dict(),
                              "output": PadState().as_dict(), "activity": "Stopped"}
        if had_session:
            log.info("Session stopped; output thread %s", "still alive (restart blocked)" if self.pump is not None else "stopped")
        self._emit("stopped")

    def _start(self, data):
        if self.engine is not None:
            raise RuntimeError("Stop the bridge before starting another session")
        if self.pump is not None and self.pump.alive:
            raise RuntimeError("Previous output has not shut down; cannot safely restart")
        token = data["token"]
        if token.is_set() or self.closing.is_set():
            self._emit("stopped")
            return
        settings = data["settings"]
        ConfigStore(self.config_dir).validate(settings, data["catalog"])
        engine = MacroEngine(settings, data["catalog"])
        if token.is_set() or self.closing.is_set():
            self._emit("stopped")
            return
        backend = self._backend(settings["input"]["mapping_file"])
        device = backend.open(data["device"])  # Must happen BEFORE virtual output creation.
        if token.is_set() or self.closing.is_set():
            self._cleanup()
            return
        factory = self.output_factory or (PreviewOutput if data["preview"] else XboxOutput)
        self.pump = OutputPump(factory, settings["input"]["watchdog_ms"])
        self.pump.start()
        if token.is_set() or self.closing.is_set():
            self._cleanup()
            return
        self.engine = engine
        self.session_token = token
        self._emit("running", device=device.label, preview=data["preview"])
        log.info("Started %s: %s", "Preview" if data["preview"] else "Xbox output", device.label)

    def _command(self, kind, data):
        if kind == "start":
            self._start(data)
        elif kind == "apply":
            self._apply(data)
        elif kind == "stop":
            self._cleanup()
        elif kind == "scan":
            if self.engine is not None or (self.pump is not None and self.pump.alive):
                raise RuntimeError("Stop virtual output before scanning/selecting input")
            devices = self._backend(data.get("mapping_file", "")).devices()
            self._emit("devices", devices=devices)
        elif self.engine is not None:
            if kind == "pause":
                self.engine.set_paused(data["value"])
            elif kind == "menu":
                self.engine.set_menu(data["value"])
            elif kind == "corner":
                self.engine.arm_corner(time.monotonic() * 1000)

    def _tick(self):
        engine = self.engine
        if engine is None:
            return
        if self.session_token.is_set() or self.closing.is_set():
            self._cleanup()
            return
        p = self.backend.read(engine.settings["input"]["deadzone"])
        if self.session_token.is_set() or self.closing.is_set():
            self._cleanup()
            return
        now = time.monotonic()
        result = engine.tick(p, now * 1000)
        self.pump.submit(result, now)
        with self.lock:
            self.telemetry = {
                "running": True, "input": p.as_dict(), "output": result.as_dict(),
                "activity": "Menu: neutral" if engine.menu else "Paused: passthrough" if engine.paused else engine.activity,
                "paused": engine.paused, "menu": engine.menu,
                "corner": engine.corner_until > now * 1000,
            }
        for event in engine.events:
            self.events.put(event)
        engine.events.clear()

    def _run(self):
        deadline = time.monotonic()
        try:
            while not self.closing.is_set():
                timeout = max(0, deadline - time.monotonic()) if self.engine else .1
                try:
                    kind, data = self.commands.get(timeout=timeout)
                except queue.Empty:
                    kind, data = None, None
                try:
                    if kind is not None:
                        self._command(kind, data)
                    if self.engine is not None and time.monotonic() >= deadline:
                        self._tick()
                        if self.engine is not None:
                            interval = self.engine.settings["input"]["poll_ms"] / 1000
                            # No bursts to replay missed ticks after a scheduling stall.
                            deadline = max(deadline + interval, time.monotonic())
                except Exception as exc:
                    log.exception("Bridge failure")
                    self._emit("error", message=str(exc))
                    self._cleanup()
        finally:
            log.info("Bridge worker exiting")
            self._cleanup()
            if self.backend is not None:
                try:
                    self.backend.close()
                except Exception as exc:
                    log.exception("SDL shutdown failed")
                    self._emit("error", message=f"SDL shutdown failed: {exc}")
            self._emit("closed")
