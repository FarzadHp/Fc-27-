"""SDL2 input. All SDL calls belong to one long-lived worker thread.

A source is pinned by instance ID *before* creating our virtual controller.
There is deliberately no automatic reconnect/device-index fallback.
"""
from __future__ import annotations

import ctypes
from dataclasses import dataclass
from pathlib import Path

from .state import PadState, radial_deadzone


@dataclass(frozen=True)
class Device:
    instance_id: int
    name: str
    guid: str
    mapped: bool
    vendor: int = 0
    product: int = 0

    @property
    def label(self):
        support = "" if self.mapped else " [NO SDL MAPPING]"
        return f"{self.name} | ID {self.instance_id} | {self.guid[:8]}{support}"


class InputDisconnected(RuntimeError):
    pass


def stick_value(value):
    return max(-1., min(1., value / (32768. if value < 0 else 32767.)))


def trigger_value(value):
    # SDL GameController triggers are 0..32767, not joystick -32768..32767.
    return max(0., min(1., value / 32767.))


class SDLInput:
    def __init__(self):
        # Lazy import: offline engine/config tests need neither SDL nor its DLL.
        import sdl2
        self.sdl = sdl2
        self.handle = None
        self.device = None
        self.flags = sdl2.SDL_INIT_GAMECONTROLLER | sdl2.SDL_INIT_EVENTS
        sdl2.SDL_SetHint(b"SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", b"1")
        if sdl2.SDL_InitSubSystem(self.flags) != 0:
            raise RuntimeError(self._error("SDL initialization failed"))
        self.closed = False
        self.buttons = {
            "a": 0, "b": 1, "x": 2, "y": 3, "back": 4, "guide": 5,
            "start": 6, "ls": 7, "rs": 8, "lb": 9, "rb": 10,
            "up": 11, "down": 12, "left": 13, "right": 14,
            "misc1": 15, "touchpad": 20,
        }

    def _error(self, prefix):
        return prefix + ": " + (self.sdl.SDL_GetError() or b"Unknown SDL error").decode("utf-8", "replace")

    def load_mappings(self, filename=""):
        if filename:
            path = Path(filename)
            if not path.is_file():
                raise RuntimeError(f"SDL mapping file not found: {path}")
            count = self.sdl.SDL_GameControllerAddMappingsFromFile(str(path).encode("utf-8"))
            if count < 0:
                raise RuntimeError(self._error("Cannot load SDL mappings"))

    def pump(self):
        sdl = self.sdl
        event = sdl.SDL_Event()
        while sdl.SDL_PollEvent(ctypes.byref(event)):
            pass
        sdl.SDL_GameControllerUpdate()

    def devices(self):
        self.pump()
        sdl, result = self.sdl, []
        count = sdl.SDL_NumJoysticks()
        if count < 0:
            raise RuntimeError(self._error("Cannot enumerate controllers"))
        for index in range(count):
            guid = ctypes.create_string_buffer(33)
            sdl.SDL_JoystickGetGUIDString(sdl.SDL_JoystickGetDeviceGUID(index), guid, 33)
            name = (sdl.SDL_JoystickNameForIndex(index) or b"Unnamed controller").decode("utf-8", "replace")
            result.append(Device(int(sdl.SDL_JoystickGetDeviceInstanceID(index)), name,
                                 guid.value.decode("ascii"), bool(sdl.SDL_IsGameController(index)),
                                 int(sdl.SDL_JoystickGetDeviceVendor(index)),
                                 int(sdl.SDL_JoystickGetDeviceProduct(index))))
        return result

    def open(self, selected: Device):
        self.close_device()
        # Matching ID alone is insufficient if the caller supplies stale/wrong metadata.
        current = next((d for d in self.devices() if d.instance_id == selected.instance_id), None)
        if current is None or (current.guid, current.name) != (selected.guid, selected.name):
            raise InputDisconnected("Selected controller disappeared. Refresh and explicitly select it again.")
        if not current.mapped:
            raise RuntimeError("This joystick has no SDL GameController mapping. Add a mapping file and refresh.")
        sdl = self.sdl
        index = next((i for i in range(sdl.SDL_NumJoysticks())
                      if sdl.SDL_JoystickGetDeviceInstanceID(i) == selected.instance_id), None)
        if index is None:
            raise InputDisconnected("Selected controller disconnected during open")
        handle = sdl.SDL_GameControllerOpen(index)
        if not handle:
            raise RuntimeError(self._error("Cannot open controller"))
        joystick = sdl.SDL_GameControllerGetJoystick(handle)
        if sdl.SDL_JoystickInstanceID(joystick) != selected.instance_id:
            sdl.SDL_GameControllerClose(handle)
            raise InputDisconnected("Controller identity changed during open")
        self.handle, self.device = handle, current
        return current

    def read(self, deadzone=0.):
        self.pump()
        sdl, handle = self.sdl, self.handle
        if not handle or not sdl.SDL_GameControllerGetAttached(handle):
            raise InputDisconnected("Input controller disconnected; bridge stopped. No automatic reconnect.")
        values = {name: float(bool(sdl.SDL_GameControllerGetButton(handle, index)))
                  for name, index in self.buttons.items()}
        for index, name in enumerate(("lx", "ly", "rx", "ry", "lt", "rt")):
            raw = int(sdl.SDL_GameControllerGetAxis(handle, index))
            values[name] = stick_value(raw) if index < 4 else trigger_value(raw)
        for x, y in (("lx", "ly"), ("rx", "ry")):
            values[x], values[y] = radial_deadzone(values[x], values[y], deadzone)
        return PadState.from_values(**values)

    def close_device(self):
        if self.handle:
            self.sdl.SDL_GameControllerClose(self.handle)
        self.handle = self.device = None

    def close(self):
        if not self.closed:
            self.close_device()
            self.sdl.SDL_QuitSubSystem(self.flags)
            self.closed = True
