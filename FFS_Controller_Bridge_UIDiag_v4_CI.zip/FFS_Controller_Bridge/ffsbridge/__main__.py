"""Run with: python -m ffsbridge."""
from .launcher import main

if __name__ == "__main__":
    raise SystemExit(main())
