"""Internal convention: sticks -1..1, Y positive DOWN; triggers 0..1."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Mapping

STICKS = ("lx", "ly", "rx", "ry")
TRIGGERS = ("lt", "rt")
BUTTONS = ("a", "b", "x", "y", "lb", "rb", "back", "start", "guide", "ls", "rs",
           "up", "down", "left", "right", "touchpad", "misc1")
CHANNELS = STICKS + TRIGGERS + BUTTONS
NEUTRAL = dict.fromkeys(CHANNELS, 0.0)


@dataclass
class PadState:
    values: dict[str, float] = field(default_factory=lambda: NEUTRAL.copy())

    @classmethod
    def from_values(cls, **values: float) -> "PadState":
        state = cls()
        state.patch(values)
        return state

    def __getitem__(self, key: str) -> float:
        return self.values[key]

    def down(self, key: str, threshold: float = 0.5) -> bool:
        return self[key] >= threshold

    def patch(self, changes: Mapping[str, float]) -> None:
        for key, value in changes.items():
            if key not in NEUTRAL:
                raise ValueError(f"Unknown controller channel: {key}")
            number = float(value)
            if not math.isfinite(number):
                raise ValueError(f"Non-finite controller value: {key}")
            low = -1.0 if key in STICKS else 0.0
            self.values[key] = max(low, min(1.0, number)) if key not in BUTTONS else float(number >= 0.5)

    def copy(self) -> "PadState":
        return PadState(self.values.copy())

    def as_dict(self) -> dict[str, float]:
        return self.values.copy()


def radial_deadzone(x: float, y: float, deadzone: float) -> tuple[float, float]:
    if not 0 <= deadzone < 1:
        raise ValueError("Deadzone must be in [0, 1)")
    if deadzone == 0:
        return x, y  # Preserve the square SDL stick range in passthrough mode.
    length = math.hypot(x, y)
    if length <= deadzone:
        return 0.0, 0.0
    scaled = min(1.0, (length - deadzone) / (1.0 - deadzone))
    return x / length * scaled, y / length * scaled
