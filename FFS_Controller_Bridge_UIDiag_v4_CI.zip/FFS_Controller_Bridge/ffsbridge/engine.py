"""Deterministic, hardware-independent input transforms; all times are milliseconds.

Recipes are data, never Python/GPC code. One action owns the scheduler at a time.
Every output starts from fresh physical input: generated buttons cannot latch.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field

from .state import PadState

DIRECTIONS = ("U", "UR", "R", "DR", "D", "DL", "L", "UL")


def snap_vector(lx, ly, profile, power=False):
    """Port of stick-based aim math. No knowledge of screen, goal or player state."""
    if abs(lx) <= .25:
        return None
    x, y = abs(lx), abs(ly) if abs(ly) >= .08 else 0
    sign_y = -1 if ly <= 0 else 1
    offset = profile["margin_cm"] / (100 * profile["distance_m"])
    if power:
        offset = min(.35, offset) * (1 if profile["target"] == "far" else -1)
        vx, vy = x - y * offset, y + x * offset
        if vx <= 0:
            return None
        scale = max(vx, abs(vy))
        return math.copysign(vx / scale, lx), sign_y * vy / scale
    slope = y / x + offset * (1 if profile["target"] == "far" else -1)
    if slope < 0:
        sign_y *= -1
    slope = min(3, abs(slope))
    vx, vy = (1, slope) if slope <= 1 else (1 / slope, 1)
    return math.copysign(vx, lx), sign_y * vy


def local_vector(vector, facing, mirror=False):
    x, y = vector
    if mirror:
        x = -x
    fx, fy = facing
    return x * -fy + y * fx, x * fx + y * fy


@dataclass
class Step:
    duration: int
    values: dict
    confirm: bool = False


@dataclass
class Sequence:
    name: str
    steps: list[Step]
    started: float
    skill: bool = False
    confirm_button: str | None = None
    released: bool = False
    decisions: dict[int, bool] = field(default_factory=dict)

    def sample(self, now, physical):
        if self.confirm_button and not physical.down(self.confirm_button):
            self.released = True
        elapsed = now - self.started
        for index, step in enumerate(self.steps):
            if elapsed < step.duration:
                if step.confirm and self.confirm_button:
                    if index not in self.decisions:
                        self.decisions[index] = not self.released
                    if not self.decisions[index]:
                        # Rejected second tap emits neutral for its positive buttons.
                        return {key: 0 for key, val in step.values.items() if val > 0}
                return step.values
            elapsed -= step.duration
        return None  # Late samples skip expired steps; no catch-up button burst.


@dataclass
class AimLock:
    vector: tuple[float, float]
    until: float
    button: str | None = None
    tail: int = 0


class MacroEngine:
    """Use validated settings/catalog. Owned exclusively by the polling thread."""
    def __init__(self, settings, catalog):
        self.settings = copy.deepcopy(settings)
        self.catalog = copy.deepcopy(catalog)
        self.skills = {s["id"]: s for s in self.catalog["skills"]}
        self.aliases = {"shoot": "b", "pass": "a", "cross": "x", "through": "y", "charge": "b"}
        if settings["layout"] == "alternate":
            self.aliases.update(shoot="x", cross="b", charge="x")
        self.previous = None
        self.now = None
        self.paused = False
        self.menu = False
        self.events = []
        self.sequence = None
        self.aim = None
        self.corner_until = 0
        self.suppressed = set()
        self.skill_ready = False
        self.skill_consume = False
        self.facing = (0., -1.)
        self.hair = False
        self.was_moving = False
        self.idle_since = None
        self.pulse_start = None
        self.quick_until = 0
        self.guard_until = 0
        self.turn_previous = None
        self.turn_seen = 0
        self.turn_until = 0
        self.turn_cooldown = 0

    @property
    def activity(self):
        return self.sequence.name if self.sequence else ("Aim hold" if self.aim else "Passthrough")

    def cancel(self):
        self.sequence = self.aim = None
        self.skill_ready = self.skill_consume = False
        self.pulse_start = None
        self.quick_until = self.turn_until = self.turn_cooldown = 0
        self.turn_previous = None
        self.hair = False

    def set_paused(self, value):
        self.paused = bool(value)
        self.cancel()
        self.corner_until = 0
        self.suppressed.clear()
        # Resuming while a control is held must not create a new press edge.
        self.previous = None

    def set_menu(self, value):
        self.menu = bool(value)
        self.cancel()
        self.corner_until = 0
        self.suppressed.clear()
        self.previous = None

    def arm_corner(self, now):
        if not self.paused and not self.menu:
            self.cancel()
            self.corner_until = 0 if self.corner_until > now else now + self.settings["corner"]["arm_timeout_ms"]

    def _edge(self, p, key):
        return p.down(key) and not self.previous.down(key)

    def _compile(self, rows, params=None, modifiers=None, facing=None, mirror=False, scale=100):
        result = []
        for row in rows:
            duration = row["duration_ms"]
            if isinstance(duration, str):
                duration = params[duration[1:]]
            values = {self.aliases.get(key, key): val for key, val in row.get("set", {}).items()}
            for local, axes in (("ls_local", ("lx", "ly")), ("rs_local", ("rx", "ry"))):
                if local in row:
                    values.update(zip(axes, local_vector(row[local], facing or self.facing, mirror)))
            if row.get("modifiers"):
                values.update(modifiers or {})
            result.append(Step(max(1, round(duration * scale / 100)), values, row.get("confirm", False)))
        return result

    def _action(self, name, now, params=None, modifiers=None, trigger=None, confirm=False):
        self.cancel()
        self.sequence = Sequence(name, self._compile(self.catalog["actions"][name], params, modifiers),
                                 now, confirm_button=trigger if confirm else None)
        if trigger:
            self.suppressed.add(trigger)

    def _toggle(self, path):
        node = self.settings
        for key in path[:-1]:
            node = node[key]
        node[path[-1]] = not node[path[-1]]
        self.events.append({"type": "setting", "path": path, "value": node[path[-1]]})

    def _shortcuts(self, p, now):
        if not self.settings["shortcuts"]["enabled"] or p["lt"] <= .5:
            return False
        used = False
        for key in ("start", "back", "up", "left", "down"):
            if not p.down(key):
                continue
            edge = self._edge(p, key)
            if edge:
                if key == "start":
                    self.set_menu(not self.menu)
                    self.events.append({"type": "menu", "value": self.menu})
                elif key == "back":
                    self.set_paused(not self.paused)
                elif not self.paused and not self.menu:
                    if key == "up":
                        self.arm_corner(now)
                    elif key == "left":
                        self.cancel()
                        self._toggle(["shots", "enabled"])
                    elif key == "down":
                        self.cancel()
                        self._toggle(["snap", "flair", "enabled"])
            self.suppressed.add(key)
            used = True
            # set_menu/set_paused reset previous; keep subsequent chords safe.
            self.previous = p.copy() if self.previous is None else self.previous
        return used

    def _shot(self, p, now):
        s = self.settings
        shoot = self.aliases["shoot"]
        for name, modifier in (("low_driven", {}), ("low_trivela", {"lt": 1})):
            profile = s["shots"][name]
            if profile["enabled"] and self._edge(p, profile["button"]):
                self._action("one_touch", now, profile, modifier, profile["button"])
                snap = s["snap"][name]
                vector = snap_vector(p["lx"], p["ly"], snap) if snap["enabled"] else None
                if vector:
                    duration = sum(step.duration for step in self.sequence.steps)
                    self.aim = AimLock(vector, now + duration + snap["hold_ms"])
                return True
        if not self._edge(p, shoot):
            return False
        if p.down("lb") and p.down("rb"):
            kind, modifiers = "power", {"lb": 1, "rb": 1}
        elif p["lt"] > .1:
            kind, modifiers = "flair", {"lt": 1}
        elif p.down("rb"):
            kind, modifiers = "finesse", {"rb": 1}
        elif p.down("lb"):
            kind, modifiers = "chip", {"lb": 1}
        else:
            kind, modifiers = "normal", {}
        self.cancel()
        profile = s["shots"][kind]
        automated = s["shots"]["enabled"] and profile["enabled"]
        if automated:
            double = profile["double_tap"] and kind != "chip"
            self._action("double_shot" if double else "charge", now, profile, modifiers, shoot,
                         profile["confirm_hold"] and double)
        snap = s["snap"].get(kind)
        vector = None
        tail = s["shots"]["normal_hold_ms"] if kind == "normal" else 0
        if snap and snap["enabled"]:
            vector = snap_vector(p["lx"], p["ly"], snap, power=kind == "power")
            tail = 150 + snap["hold_ms"]
        elif kind == "normal" and tail:
            vector = (p["lx"], p["ly"])
        if vector:
            if automated:
                duration = sum(step.duration for step in self.sequence.steps)
                self.aim = AimLock(vector, now + max(duration, profile["charge_ms"] + tail))
            else:
                self.aim = AimLock(vector, now + tail, shoot, tail)
        return True

    def _other_actions(self, p, now):
        s = self.settings
        cross, pass_button = self.aliases["cross"], self.aliases["pass"]
        if self.corner_until > now and self._edge(p, cross):
            c = s["corner"]
            bars, y = {"near": (25, -8), "spot": (30, -26), "far": (45, -6)}[c["target"]]
            duration = int(max(5, bars + c["power_trim_tenths"]) * c["bar_ms"] / 10)
            self._action("cross", now, {"charge_ms": duration}, trigger=cross)
            x = min(100, max(0, 80 + c["x_trim"])) / 100
            y = min(100, max(-100, y + c["y_trim"])) / 100
            self.aim = AimLock(((-x if p["lx"] < 0 else x), y), now + duration + 150)
            self.corner_until = 0
            return
        for name, key in (("pass", pass_button), ("cross", cross)):
            if self._edge(p, key):
                self.cancel()
                profile = s["passes"][name]
                if profile["enabled"] and not (p.down("lb") or p.down("rb") or p["lt"] > .1):
                    self._action(name, now, profile, trigger=key)
                return
        if self._edge(p, "y"):
            self.cancel()
            return
        run = s["passes"]["run_lob"]
        if run["enabled"] and self._edge(p, run["button"]):
            self._action("run_lob", now, run, trigger=run["button"])
            return
        if p["lt"] <= .1:
            for name, key in (("team_press", "left"), ("offside_trap", "up")):
                if s["tactics"][name] and self._edge(p, key):
                    self._action(name, now, trigger=key)
                    return

    def _skills(self, p, now):
        cfg = self.settings["skills"]
        length = math.hypot(p["lx"], p["ly"])
        if length > .25:
            self.facing = (p["lx"] / length, p["ly"] / length)
        blocked = (self._physical_action(p) or self.aim is not None or self.corner_until > now
                   or (self.sequence is not None and not self.sequence.skill))
        if blocked:
            if self.sequence and self.sequence.skill:
                self.sequence = None
            self.skill_ready = self.skill_consume = False
            return
        magnitude = max(abs(p["rx"]), abs(p["ry"]))
        centered = magnitude <= cfg["center_percent"] / 100
        reserved = any(self.settings["shots"][k]["enabled"] and self.settings["shots"][k]["button"] == "rs"
                       for k in ("low_driven", "low_trivela"))
        run = self.settings["passes"]["run_lob"]
        reserved = reserved or (run["enabled"] and run["button"] == "rs")
        direction = None
        if not self.sequence:
            if centered:
                self.skill_ready = True
                self.skill_consume = False
            if centered and not reserved and cfg["mapping"]["R3"] and self._edge(p, "rs"):
                direction = "R3"
                self.suppressed.add("rs")
            elif self.skill_ready and magnitude >= cfg["trigger_percent"] / 100:
                index = int((math.atan2(p["rx"], -p["ry"]) + math.pi / 8) // (math.pi / 4)) % 8
                direction = DIRECTIONS[index]
        if direction:
            self.skill_ready = False
            skill_id = cfg["mapping"][direction]
            if skill_id:
                skill = self.skills[skill_id]
                mirror = skill["mirror_trigger"] and direction in ("DL", "L", "UL")
                steps = self._compile(skill["steps"], facing=self.facing, mirror=mirror,
                                      scale=skill["scale_percent"])
                self.sequence = Sequence(f"Skill {skill_id}: {skill['name']}", steps, now, skill=True)
                self.skill_consume = True

    def _physical_action(self, p):
        return (any(p.down(key) for key in ("a", "b", "x", "y", "lb", "rb")) or p["lt"] > .05
                or any(self.settings["shots"][k]["enabled"] and p.down(self.settings["shots"][k]["button"])
                       for k in ("low_driven", "low_trivela"))
                or (self.settings["passes"]["run_lob"]["enabled"]
                    and p.down(self.settings["passes"]["run_lob"]["button"])))

    def _movement(self, p, out, now):
        m = self.settings["movement"]
        h = m["hair_trigger"]
        if h["enabled"]:
            if p["rt"] >= h["press_percent"] / 100:
                self.hair = True
            elif p["rt"] <= h["release_percent"] / 100:
                self.hair = False
            out.patch({"rt": int(self.hair)})
        if m["perfect_sprint"]["enabled"] and out["rt"] > .1:
            out.patch({"rt": m["perfect_sprint"]["strength_percent"] / 100})
        if m["controlled_sprint"]["enabled"] and p.down("rb"):
            factor = m["controlled_sprint"]["power_percent"] / 100
            out.patch({"lx": p["lx"] * factor, "ly": p["ly"] * factor})
        moving = math.hypot(p["lx"], p["ly"]) > .25
        blocked = self._physical_action(p) or self.sequence or self.aim or self.skill_consume or self.corner_until > now
        repeat, quick = m["repeat_sprint"], m["quick_step"]
        if blocked:
            self.guard_until = now + repeat["guard_ms"]
        if self.idle_since is None:
            self.idle_since = now
        if not moving and self.was_moving:
            self.idle_since = now
        eligible = not blocked and now >= self.guard_until and moving and p["rt"] > .1
        if not eligible:
            self.pulse_start = None
            self.quick_until = 0
        else:
            if quick["enabled"] and not self.was_moving and now - self.idle_since >= quick["idle_ms"]:
                self.quick_until = now + quick["drop_ms"]
                self.pulse_start = self.quick_until
            if repeat["enabled"] and self.pulse_start is None:
                self.pulse_start = now
            drop = now < self.quick_until
            if repeat["enabled"] and self.pulse_start is not None and now >= self.pulse_start:
                drop |= (now - self.pulse_start) % (repeat["run_ms"] + repeat["drop_ms"]) >= repeat["run_ms"]
            if drop:
                out.patch({"rt": 0})
        self.was_moving = moving
        turn = m["quick_turn"]
        if (not turn["enabled"] or blocked or p["rt"] <= .05
                or max(abs(p["rx"]), abs(p["ry"])) > .2):
            self.turn_previous = None
            self.turn_until = self.turn_cooldown = 0
        else:
            if moving:
                if (self.turn_previous and now >= self.turn_cooldown and now >= self.turn_until
                        and p["lx"] * self.turn_previous[0] + p["ly"] * self.turn_previous[1] < 0):
                    self.turn_until = now + turn["drop_ms"]
                    self.turn_cooldown = self.turn_until + turn["cooldown_ms"]
                self.turn_previous = (p["lx"], p["ly"])
                self.turn_seen = now
            elif now - self.turn_seen > 120:
                self.turn_previous = None
            if now < self.turn_until:
                out.patch({"rt": 0})
                if turn["mode"] == "controlled":
                    out.patch({"rb": 1})

    def tick(self, physical: PadState, now: float) -> PadState:
        if not math.isfinite(now) or (self.now is not None and now < self.now):
            raise ValueError("Engine time must be finite and monotonic")
        self.now = now
        p = physical
        if self.previous is None:
            self.previous = p.copy()  # Startup/Resume cannot fabricate press edges.
        self.suppressed = {key for key in self.suppressed if p.down(key)}
        shortcut = self._shortcuts(p, now)
        if self.menu:
            self.previous = p.copy()
            return PadState()
        if self.paused:
            out = p.copy()
            for key in self.suppressed:
                out.patch({key: 0})
            self.previous = p.copy()
            return out
        # A physical LT+RT squeeze is a temporary automation bypass/cancel.
        if p["lt"] > .9 and p["rt"] > .9:
            self.cancel()
            self.corner_until = 0
            self.suppressed.clear()
            self.previous = p.copy()
            return p.copy()
        if self.aim:
            if self.aim.button and p.down(self.aim.button):
                self.aim.until = now + self.aim.tail
            elif now >= self.aim.until:
                self.aim = None
        if self.sequence and self.sequence.sample(now, p) is None:
            self.sequence = None
        if not shortcut:
            if not self._shot(p, now):
                self._other_actions(p, now)
            self._skills(p, now)
        out = p.copy()
        for key in self.suppressed:
            out.patch({key: 0})
        self._movement(p, out, now)
        if p.down("y"):
            if ((p.down("lb") and self.settings["passes"]["precision_lob"])
                    or (not p.down("lb") and self.settings["passes"]["precision_pass"])):
                out.patch({"rb": 1})
        if self.skill_consume:
            out.patch({"rx": 0, "ry": 0})
        if self.sequence:
            values = self.sequence.sample(now, p)
            if values is not None:
                out.patch(values)
        if self.aim:
            out.patch(dict(zip(("lx", "ly"), self.aim.vector)))
        self.previous = p.copy()
        return out
