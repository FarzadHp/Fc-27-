"""SDL2 -> JSON automation -> virtual Xbox 360. No GPC runtime dependency."""
__version__ = "0.1.0"
