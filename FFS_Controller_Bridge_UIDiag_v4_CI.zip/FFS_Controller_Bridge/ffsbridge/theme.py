"""Native, light UI appearance used before the custom blue theme.

Keep the style API so the current layout and runtime fixes remain intact.
"""
from tkinter import ttk

UI_FONT = ("Segoe UI", 10)
MONO_FONT = ("Consolas", 10)


def apply_theme(root):
    style = ttk.Style(root)
    available = style.theme_names()
    for name in ("vista", "xpnative", "winnative", "default"):
        if name in available:
            style.theme_use(name)
            break
    background = style.lookup("TFrame", "background") or "#f0f0f0"
    root.configure(background=background)
    # Named styles inherit native colours; no custom dark widget/selection maps.
    style.configure("Heading.TLabel", font=("Segoe UI", 11, "bold"))
    style.configure("Status.TLabel", padding=(8, 6))
    return style


def style_text(widget, mono=False):
    widget.configure(font=MONO_FONT if mono else UI_FONT)


def style_listbox(widget):
    widget.configure(font=UI_FONT)


def style_canvas(widget):
    style = ttk.Style(widget)
    widget.configure(background=style.lookup("TFrame", "background") or "#f0f0f0",
                     highlightthickness=0, borderwidth=0)
