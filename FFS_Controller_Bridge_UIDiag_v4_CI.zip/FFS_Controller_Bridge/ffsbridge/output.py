"""Virtual Xbox output plus an independent, latching freshness watchdog.

Only the output thread ever touches the vgamepad object. Windows/ViGEm is
optional for Preview; it is imported only when real output is requested.
"""
from __future__ import annotations

import logging
import math
import sys
import threading
import time

from .state import PadState

log = logging.getLogger(__name__)

XUSB_BITS = {
    "up": 0x0001, "down": 0x0002, "left": 0x0004, "right": 0x0008,
    "start": 0x0010, "back": 0x0020, "ls": 0x0040, "rs": 0x0080,
    "lb": 0x0100, "rb": 0x0200, "guide": 0x0400,
    "a": 0x1000, "b": 0x2000, "x": 0x4000, "y": 0x8000,
}


def signed_axis(value):
    value = min(1., max(-1., value))
    return round(value * (32768 if value < 0 else 32767))


def xbox_report(state):
    """Pure conversion; internal Y is down, XInput Y is up.

    touchpad/misc1 have no Xbox 360 equivalents: usable as macro triggers only.
    """
    return {
        "buttons": sum(bit for key, bit in XUSB_BITS.items() if state.down(key)),
        "lt": round(state["lt"] * 255), "rt": round(state["rt"] * 255),
        "lx": signed_axis(state["lx"]), "ly": signed_axis(-state["ly"]),
        "rx": signed_axis(state["rx"]), "ry": signed_axis(-state["ry"]),
    }


class PreviewOutput:
    def send(self, state):
        pass

    def close(self):
        pass


class XboxOutput:
    def __init__(self):
        if sys.platform != "win32":
            raise RuntimeError("Virtual Xbox output requires Windows. Use Preview on this system.")
        try:
            import vgamepad
            self.pad = vgamepad.VX360Gamepad()
        except Exception as exc:
            raise RuntimeError("Cannot create virtual Xbox controller. Check vgamepad and the ViGEmBus driver. "
                               + str(exc)) from exc
        self.send(PadState())

    def send(self, state):
        r = xbox_report(state)
        self.pad.reset()  # Complete reports, never incremental latched state.
        self.pad.press_button(button=r["buttons"])
        self.pad.left_trigger(value=r["lt"])
        self.pad.right_trigger(value=r["rt"])
        self.pad.left_joystick(x_value=r["lx"], y_value=r["ly"])
        self.pad.right_joystick(x_value=r["rx"], y_value=r["ry"])
        self.pad.update()

    def close(self):
        if self.pad is not None:
            try:
                self.send(PadState())
            finally:
                # vgamepad 0.2.0 releases the target in its destructor, on this thread.
                pad, self.pad = self.pad, None
                del pad


class FreshReport:
    """Latest report mailbox; a stale report permanently trips this session.

    Staleness is checked on both read AND submission, so a delayed producer
    cannot conceal its missed deadline with a new report.
    """
    def __init__(self, timeout_seconds):
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise ValueError("Watchdog timeout must be finite and positive")
        self.timeout = timeout_seconds
        self.lock = threading.Lock()
        self.state = PadState()
        self.stamp = None
        self.tripped = False

    def _check(self, now):
        if not math.isfinite(now) or (self.stamp is not None and
                                     (now < self.stamp or now - self.stamp > self.timeout)):
            self.tripped = True
        return self.tripped

    def submit(self, state, now):
        with self.lock:
            if self._check(now):
                raise TimeoutError("Input watchdog expired; explicitly restart the bridge.")
            self.state, self.stamp = state.copy(), now

    def sample(self, now=None):
        with self.lock:
            # Read the clock *after* taking the lock. Otherwise a producer can
            # publish a newer stamp between our clock read and lock acquisition,
            # falsely looking like time went backwards and tripping the watchdog.
            now = time.monotonic() if now is None else now
            return (PadState() if self._check(now) else self.state.copy()), self.tripped


class OutputPump:
    def __init__(self, factory, watchdog_ms):
        self.factory = factory
        self.mailbox = FreshReport(watchdog_ms / 1000)
        self.ready = threading.Event()
        self.stopping = threading.Event()
        self.wake = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self._run, name="FFS-output", daemon=True)

    @property
    def alive(self):
        return self.thread.is_alive()

    def start(self):
        self.thread.start()
        if not self.ready.wait(10):
            self.request_stop()
            raise TimeoutError("Virtual output did not initialize within 10 seconds")
        if self.error:
            raise RuntimeError(self.error)

    def submit(self, state, now=None):
        if self.error or self.stopping.is_set() or not self.alive:
            raise RuntimeError(self.error or "Output stopped")
        self.mailbox.submit(state, time.monotonic() if now is None else now)
        self.wake.set()

    def request_stop(self):
        self.stopping.set()
        self.wake.set()

    def stop(self, timeout=2):
        self.request_stop()
        if self.thread.ident is not None:
            self.thread.join(timeout)
        return not self.alive

    def _run(self):
        sink = None
        try:
            sink = self.factory()
            sink.send(PadState())
            # Arm before the first physical read: a blocked first read also fails closed.
            self.mailbox.submit(PadState(), time.monotonic())
            self.ready.set()
            last = None
            last_sent = 0
            while not self.stopping.is_set():
                self.wake.clear()
                state, expired = self.mailbox.sample()
                now = time.monotonic()
                if expired or state != last or now - last_sent >= .05:
                    sink.send(state)
                    last, last_sent = state, now
                if expired:
                    raise TimeoutError("Input watchdog expired; output neutralized and stopped.")
                self.wake.wait(.005)
        except Exception as exc:
            self.error = str(exc)
            log.exception("Output worker failed")
        finally:
            if sink is not None:
                try:
                    sink.send(PadState())
                except Exception as exc:
                    self.error = self.error or f"Neutral report failed: {exc}"
                    log.exception("Neutral output report failed")
                try:
                    sink.close()
                except Exception as exc:
                    self.error = self.error or f"Output cleanup failed: {exc}"
                    log.exception("Output cleanup failed")
            self.stopping.set()
            self.ready.set()
