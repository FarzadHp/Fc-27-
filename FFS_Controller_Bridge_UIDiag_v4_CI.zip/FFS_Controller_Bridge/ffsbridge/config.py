"""Validated, atomic per-user settings. Invalid files are never silently reset."""
from __future__ import annotations

import copy
import json
import math
import os
from pathlib import Path
import shutil
import tempfile

import jsonschema

from .paths import bundled_data, default_config_dir

MAX_JSON_BYTES = 2_000_000


class ConfigError(ValueError):
    pass


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ConfigError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(text: str):
    def reject_constant(value):
        raise ConfigError(f"Non-finite JSON number: {value}")
    if not isinstance(text, str) or len(text.encode("utf-8")) > MAX_JSON_BYTES:
        raise ConfigError("JSON text is missing or exceeds the 2 MB limit")
    try:
        value = json.loads(text, object_pairs_hook=_unique_object, parse_constant=reject_constant)
    except (ValueError, TypeError, RecursionError) as exc:
        raise ConfigError(str(exc)) from exc
    def finite(item):
        if isinstance(item, float) and not math.isfinite(item):
            raise ConfigError("JSON numbers must be finite")
        if isinstance(item, dict):
            for child in item.values():
                finite(child)
        elif isinstance(item, list):
            for child in item:
                finite(child)
    try:
        finite(value)
    except RecursionError as exc:
        raise ConfigError("JSON nesting is too deep") from exc
    return value


def read_json(path: Path):
    try:
        if path.stat().st_size > MAX_JSON_BYTES:
            raise ConfigError(f"JSON exceeds {MAX_JSON_BYTES} bytes: {path}")
        return parse_json(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError) as exc:
        raise ConfigError(f"Cannot read {path}: {exc}") from exc


def atomic_json(path: Path, value, backup: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if len(text.encode("utf-8")) > MAX_JSON_BYTES:
        raise ConfigError("JSON file too large")
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        if backup and path.exists():
            shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class ConfigStore:
    def __init__(self, directory: Path | str | None = None):
        self.directory = Path(directory) if directory is not None else default_config_dir()
        self.settings_path = self.directory / "settings.json"
        self.catalog_path = self.directory / "catalog.json"
        self.schemas = {name: read_json(bundled_data() / f"{name}.schema.json")
                        for name in ("settings", "catalog")}
        self.validators = {name: jsonschema.Draft202012Validator(schema)
                           for name, schema in self.schemas.items()}

    def initialize(self) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        for target, source in ((self.settings_path, "default_settings.json"),
                               (self.catalog_path, "catalog.json")):
            if not target.exists():
                atomic_json(target, read_json(bundled_data() / source), backup=False)

    def defaults(self):
        return read_json(bundled_data() / "default_settings.json")

    def validate(self, settings, catalog) -> None:
        # Also rejects NaN/infinite values passed from Python/UI, not just JSON files.
        try:
            json.dumps([settings, catalog], allow_nan=False)
        except (ValueError, TypeError, RecursionError) as exc:
            raise ConfigError(str(exc)) from exc
        for name, value in (("settings", settings), ("catalog", catalog)):
            errors = sorted(self.validators[name].iter_errors(value), key=lambda e: str(list(e.path)))
            if errors:
                first = errors[0]
                location = ".".join(map(str, first.absolute_path)) or "<root>"
                raise ConfigError(f"{name}.{location}: {first.message}")
        hair = settings["movement"]["hair_trigger"]
        if hair["release_percent"] >= hair["press_percent"]:
            raise ConfigError("Hair-trigger release must be below press threshold")
        ids = [skill["id"] for skill in catalog["skills"]]
        if len(ids) != len(set(ids)):
            raise ConfigError("Skill IDs must be unique")
        for direction, skill_id in settings["skills"]["mapping"].items():
            if skill_id and skill_id not in ids:
                raise ConfigError(f"Unknown skill ID {skill_id} for {direction}")
        aliases = {"shoot": "b", "pass": "a", "cross": "x", "through": "y", "charge": "b"}
        if settings["layout"] == "alternate":
            aliases.update(shoot="x", cross="b", charge="x")

        def check_steps(label, steps, scale=100, parameters=None):
            total = 0
            for step in steps:
                duration = step["duration_ms"]
                if isinstance(duration, str):
                    if parameters is None or duration not in parameters:
                        raise ConfigError(f"{label}: unsupported timing parameter {duration}")
                    duration = parameters[duration]
                total += max(1, round(duration * scale / 100))
                channels = [aliases.get(key, key) for key in step.get("set", {})]
                if parameters is None and "charge" in step.get("set", {}):
                    raise ConfigError(f"{label}: 'charge' is only valid in action recipes")
                for local, axes in (("rs_local", ("rx", "ry")), ("ls_local", ("lx", "ly"))):
                    if local in step:
                        channels.extend(axes)
                if len(channels) != len(set(channels)):
                    raise ConfigError(f"{label}: conflicting channels in a step")
            if total > 60_000:
                raise ConfigError(f"{label}: exceeds the 60-second safety limit")

        for skill in catalog["skills"]:
            check_steps(f"Skill {skill['id']}", skill["steps"], skill["scale_percent"])
        # Upper bounds, not current values: every valid profile must be safe.
        parameter_limits = {
            "charge": {"$charge_ms": 2200}, "pass": {"$charge_ms": 2000},
            "cross": {"$charge_ms": 2200},
            "double_shot": {"$charge_ms": 2000, "$gap_ms": 500},
            "one_touch": {"$charge_ms": 2000, "$gap_ms": 500},
            "run_lob": {"$request_ms": 1000, "$delay_ms": 3000, "$lob_ms": 2000},
            "team_press": {}, "offside_trap": {}}
        for name, steps in catalog["actions"].items():
            check_steps(f"Action {name}", steps, parameters=parameter_limits[name])

    def load(self):
        self.initialize()
        settings, catalog = read_json(self.settings_path), read_json(self.catalog_path)
        self.validate(settings, catalog)
        return settings, catalog

    def save_settings(self, settings, catalog) -> None:
        self.validate(settings, catalog)
        atomic_json(self.settings_path, settings)

    def save_catalog(self, catalog, settings) -> None:
        self.validate(settings, catalog)
        atomic_json(self.catalog_path, catalog)

    def save_all(self, settings, catalog) -> None:
        self.validate(settings, catalog)
        # Each file is atomic, not the pair. Export a bundle before major edits.
        atomic_json(self.catalog_path, catalog)
        atomic_json(self.settings_path, settings)

    def export(self, path: Path, settings, catalog) -> None:
        self.validate(settings, catalog)
        atomic_json(path, {"format": "ffs-bridge-bundle-v1", "settings": settings, "catalog": catalog})

    def read_bundle(self, path: Path):
        bundle = read_json(path)
        if not isinstance(bundle, dict) or set(bundle) != {"format", "settings", "catalog"}:
            raise ConfigError("Not an FFS settings/catalog bundle")
        if bundle["format"] != "ffs-bridge-bundle-v1":
            raise ConfigError("Unsupported bundle format")
        self.validate(bundle["settings"], bundle["catalog"])
        return copy.deepcopy(bundle["settings"]), copy.deepcopy(bundle["catalog"])
