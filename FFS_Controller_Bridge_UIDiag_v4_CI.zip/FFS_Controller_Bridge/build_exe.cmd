@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
echo Building FFS Controller Bridge for Windows x64...
echo Requires Python 3.11 x64 with Tcl/Tk and Python Launcher.
echo Internet is required to install dependencies. No driver is installed.
echo.
call build_windows.cmd --no-pause
if errorlevel 1 goto failed
echo.
echo SUCCESS: %CD%\dist\FFSControllerBridge\FFSControllerBridge.exe
echo Keep the ENTIRE FFSControllerBridge folder, including _internal.
start "" explorer.exe "%CD%\dist\FFSControllerBridge"
popd
pause
exit /b 0
:failed
echo.
echo Build failed. Read the errors above. Do not use an old or partial EXE.
popd
pause
exit /b 1
