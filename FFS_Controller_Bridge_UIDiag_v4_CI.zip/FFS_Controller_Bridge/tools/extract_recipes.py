"""One-time, offline conversion of the supplied GPC tables. NOT used by the app."""
from pathlib import Path
import argparse
import hashlib
import json
import re


def extract(source: str) -> dict:
    def array(name):
        match = re.search(r'\b' + name + r'\[\]\s*=\s*\{([^}]+)\}', source)
        if not match:
            raise ValueError(f'Missing table: {name}')
        return [int(v) for v in re.findall(r'-?\d+', match[1])]

    starts = array('recipe_start_index')
    counts = array('recipe_step_count')
    data = array('recipe_data')
    if len(starts) != 85 or len(counts) != 85 or len(data) != (starts[-1] + counts[-1]) * 7:
        raise ValueError('Unexpected source table dimensions')
    names = {int(n): re.sub(r'^\d+ ', '', text) for n, text in re.findall(
        r'if\(sk_map\[row\] == (\d+)\).*?"([^"]+)"', source)}

    def step(x, y, ms, mod=0):
        out = {'duration_ms': ms, 'rs_local': [x / 100, y / 100]}
        if mod:
            out['set'] = {'lt': 1}
            if mod == 2:
                out['set']['rb'] = 1
        return out

    builtins = {
        1: [(100, 0, 220), (0, 0, 30), (0, 100, 80)],
        2: [(0, 0, 40, 1), (0, 100, 80, 1), (100, 0, 100, 1)],
        3: [(0, 100, 80), (0, 0, 40), (0, -100, 80)],
        4: [(0, 100, 80), (0, 0, 40), (100, 0, 80)],
        5: [(100, 0, 40), (71, -71, 40), (0, -100, 40), (-71, -71, 40), (-100, 0, 60)],
        6: [(-100, 0, 40), (-71, -71, 40), (0, -100, 40), (71, -71, 40), (100, 0, 60)],
        7: [(0, 0, 40, 2), (0, -100, 40, 2), (71, -71, 40, 2),
            (100, 0, 40, 2), (71, 71, 40, 2), (0, 100, 40, 2),
            (-71, 71, 40, 2), (-100, 0, 40, 2), (-71, -71, 40, 2), (0, -100, 40, 2)]
    }
    masks = {1: 'lt', 2: 'rb', 4: 'lb', 8: 'shoot', 16: 'pass',
             32: 'cross', 64: 'rt', 128: 'rs', 256: 'ls', 512: 'through'}
    skills = []
    for skill_id in range(1, 93):
        steps = [step(0, 0, 40)]
        if skill_id <= 7:
            steps += [step(*s) for s in builtins[skill_id]]
            steps += [step(0, 0, 80)]
        else:
            # Preserve source order: the 80ms neutral is BEFORE recipe_build().
            steps += [step(0, 0, 80)]
            idx = skill_id - 8
            for row in range(starts[idx], starts[idx] + counts[idx]):
                x, y, ms, mask, on, lx, ly = data[row * 7:row * 7 + 7]
                s = step(x, y, ms)
                values = {key: int(bool(on & bit)) for bit, key in masks.items() if mask & bit}
                if values:
                    s['set'] = values
                if mask & 3072:
                    s['ls_local'] = [lx / 100, ly / 100]
                steps.append(s)
        skills.append({'id': skill_id, 'name': names.get(skill_id, f'Skill {skill_id}'),
                       'mirror_trigger': skill_id in (1, 2, 4, 7), 'scale_percent': 100,
                       'steps': steps})

    def action(ms, values, **kw):
        return {'duration_ms': ms, 'set': values, **kw}

    actions = {
        'charge': [action('$charge_ms', {'charge': 1}, modifiers=True),
                   action(80, {'charge': 0})],
        'pass': [action('$charge_ms', {'pass': 1}), action(60, {'pass': 0})],
        'cross': [action('$charge_ms', {'cross': 1}), action(60, {'cross': 0})],
        'double_shot': [action('$charge_ms', {'shoot': 1}, modifiers=True),
                        action('$gap_ms', {'shoot': 0}, modifiers=True),
                        action(50, {'shoot': 1}, modifiers=True, confirm=True),
                        action(60, {'shoot': 0})],
        'one_touch': [action('$charge_ms', {'shoot': 1}, modifiers=True),
                      action('$gap_ms', {'shoot': 0}, modifiers=True),
                      action(50, {'shoot': 1}, modifiers=True),
                      action(60, {'shoot': 0}, modifiers=True)],
        'run_lob': [action('$request_ms', {'lb': 1, 'rb': 1, 'through': 0}),
                    action('$delay_ms', {'lb': 0, 'rb': 0, 'through': 0}),
                    action('$lob_ms', {'lb': 1, 'rb': 0, 'through': 1}),
                    action(80, {'lb': 0, 'rb': 0, 'through': 0})],
        'team_press': [action(70, {'up': 1}), action(70, {'up': 0}),
                       action(70, {'left': 1}), action(40, {'left': 0})],
        'offside_trap': [action(70, {'up': 1}), action(70, {'up': 0}),
                         action(70, {'up': 1}), action(40, {'up': 0})]
    }
    return {'version': 1, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
            'notes': 'Experimental fixed timings. Names preserve the source OLED labels, including truncation. '
                     'Local x=right, local y=forward. Table recipes retain fixed handedness.',
            'skills': skills, 'actions': actions}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'data' / 'catalog.json')
    args = parser.parse_args()
    catalog = extract(args.source.read_text(encoding='utf-8-sig'))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(f'Exported {len(catalog["skills"])} skills to {args.output}')
