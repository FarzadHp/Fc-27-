"""Hardware-independent evidence checks shared by stress tests."""
import queue


class EvidenceQueue(queue.Queue):
    def __init__(self):
        super().__init__()
        self.history = []

    def _put(self, event):
        super()._put(event)
        self.history.append(event.copy())

    def evidence(self):
        with self.mutex:
            return list(self.history)


def evidence_problems(events, requested, require_apply=True):
    problems = []
    for event in events:
        if event.get('type') in ('error', 'apply_rejected'):
            problems.append(f"Service event: {event}")
    acknowledged = sum(e.get('type') == 'applied' for e in events)
    if requested != acknowledged:
        problems.append(f"Apply requested={requested}, acknowledged={acknowledged}")
    if require_apply and not acknowledged:
        problems.append('No successful Apply was exercised')
    return problems
