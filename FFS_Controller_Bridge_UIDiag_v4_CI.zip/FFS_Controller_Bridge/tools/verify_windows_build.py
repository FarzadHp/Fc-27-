"""Post-build smoke checks on Windows; never creates a virtual controller."""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import tempfile

if __package__:
    from .windows_bundle import DATA_FILES, NATIVE_FILES, check_pe_x64, require_build_host
else:
    from windows_bundle import DATA_FILES, NATIVE_FILES, check_pe_x64, require_build_host


def verify_layout(directory: Path):
    internal = directory / "_internal"
    for name in ("FFSControllerBridge.exe", "FFSControllerBridge-console.exe"):
        check_pe_x64(directory / name)
    for _, name in NATIVE_FILES:
        check_pe_x64(internal / name)
    for relative in ([f"data/{name}" for name in DATA_FILES]
                     + ["_tcl_data/init.tcl", "_tk_data/tk.tcl"]):
        if not (internal / relative).is_file():
            raise FileNotFoundError(internal / relative)
    if not (internal / "licenses").is_dir():
        raise FileNotFoundError("Missing bundled third-party license directory")
    forbidden = [path for path in directory.rglob("*") if path.suffix.lower() in (".msi", ".sys")]
    if forbidden:
        raise RuntimeError(f"Driver/installer files must not be redistributed in this bundle: {forbidden}")


def smoke_test(directory: Path):
    # Non-ASCII path and unrelated CWD exercise frozen data/config resolution.
    with tempfile.TemporaryDirectory(prefix="ffs-build-") as temporary:
        base = Path(temporary)
        config = base / "profile تست"
        for executable, action in (("FFSControllerBridge.exe", "--check-config"),
                                   ("FFSControllerBridge-console.exe", "--check-config"),
                                   ("FFSControllerBridge-console.exe", "--list-devices")):
            subprocess.run([str(directory / executable), "--config-dir", str(config), action],
                           cwd=base, check=True, timeout=60)
        log = config / "logs" / "bridge.log"
        if not log.is_file() or "SDL controllers:" not in log.read_text(encoding="utf-8"):
            raise RuntimeError("Frozen SDL smoke check did not leave the expected log entry")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    require_build_host()
    directory = args.directory.resolve()
    verify_layout(directory)
    smoke_test(directory)
    print("Frozen JSON/logging/SDL enumeration checks passed. GUI/hardware tests are still manual.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
