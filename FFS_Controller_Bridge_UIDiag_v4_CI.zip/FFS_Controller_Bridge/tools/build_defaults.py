"""Rebuild bundled defaults and strict JSON schemas; no GPC is needed."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1] / 'data'
BUTTONS = 'a b x y lb rb back start guide ls rs up down left right touchpad misc1'.split()
AXES = 'lx ly rx ry lt rt'.split()
LOGICAL = ['shoot', 'pass', 'cross', 'through', 'charge']
DIRECTIONS = 'U UR R DR D DL L UL R3'.split()


def obj(properties, **kw):
    return {'type': 'object', 'properties': properties, 'required': list(properties),
            'additionalProperties': False, **kw}


def flag(description=''):
    return {'type': 'boolean', 'default': False, 'description': description}


def number(default, lo, hi, description='', integer=True):
    return {'type': 'integer' if integer else 'number', 'minimum': lo, 'maximum': hi,
            'default': default, 'description': description}


def choice(default, values, description=''):
    return {'type': 'string', 'enum': values, 'default': default, 'description': description}


def timed(default=180):
    return obj({'enabled': flag(), 'charge_ms': number(default, 10, 2000),
                'double_tap': flag('Second shot tap after the charge.'),
                'gap_ms': number(30, 1, 500),
                'confirm_hold': flag('Cancel tap two if shoot was released before tap two.')})


def snap():
    return obj({'enabled': flag(), 'target': choice('far', ['far', 'near']),
                'distance_m': number(18, 8, 40), 'margin_cm': number(320, 200, 366),
                'hold_ms': number(0, 0, 3000, 'Post-shot aim hold. No screen or game-state detection.')})


config_schema = obj({
    'version': {'const': 1, 'default': 1},
    'input': obj({'deadzone': number(0, 0, 0.3, 'Radial stick deadzone; 0 preserves physical input.', False),
                  'poll_ms': number(4, 1, 20), 'watchdog_ms': number(150, 50, 1000),
                  'mapping_file': {'type': 'string', 'default': '', 'maxLength': 4096,
                                   'description': 'Optional SDL2 gamecontrollerdb.txt. Relative to config folder.'}}),
    'layout': choice('classic', ['classic', 'alternate'], 'Classic shoot=B / cross=X; alternate swaps B and X.'),
    'shortcuts': obj({'enabled': flag('LT chords alter output. OFF initially for plain passthrough.')}),
    'movement': obj({
        'perfect_sprint': obj({'enabled': flag(), 'strength_percent': number(100, 1, 100)}),
        'hair_trigger': obj({'enabled': flag(), 'press_percent': number(10, 1, 100),
                             'release_percent': number(5, 0, 99)}),
        'controlled_sprint': obj({'enabled': flag(), 'power_percent': number(100, 50, 100)}),
        'quick_step': obj({'enabled': flag(), 'drop_ms': number(50, 10, 500), 'idle_ms': number(120, 0, 1000)}),
        'repeat_sprint': obj({'enabled': flag(), 'run_ms': number(800, 50, 5000),
                              'drop_ms': number(80, 10, 1000), 'guard_ms': number(300, 0, 2000)}),
        'quick_turn': obj({'enabled': flag(), 'drop_ms': number(80, 30, 200),
                           'mode': choice('release', ['release', 'controlled']),
                           'cooldown_ms': number(200, 0, 2000)})}),
    'shots': obj({'enabled': flag('Master switch; also enable the desired shot profile below.'),
                  'normal': timed(), 'finesse': timed(), 'flair': timed(), 'power': timed(), 'chip': timed(),
                  'normal_hold_ms': number(0, 0, 3000),
                  'low_driven': obj({'enabled': flag(), 'button': choice('ls', BUTTONS),
                                     'charge_ms': number(190, 10, 2000), 'gap_ms': number(30, 1, 500)}),
                  'low_trivela': obj({'enabled': flag(), 'button': choice('rs', BUTTONS),
                                      'charge_ms': number(190, 10, 2000), 'gap_ms': number(30, 1, 500)})}),
    'snap': obj({name: snap() for name in ('flair', 'low_driven', 'power', 'finesse', 'low_trivela')}),
    'passes': obj({
        'pass': obj({'enabled': flag(), 'charge_ms': number(100, 10, 2000)}),
        'cross': obj({'enabled': flag(), 'charge_ms': number(120, 10, 2000)}),
        'precision_pass': flag('Physical Y becomes RB+Y; assumes this in-game binding.'),
        'precision_lob': flag('Physical LB+Y becomes LB+RB+Y.'),
        'run_lob': obj({'enabled': flag(), 'button': choice('right', BUTTONS),
                        'request_ms': number(80, 10, 1000), 'delay_ms': number(350, 10, 3000),
                        'lob_ms': number(180, 10, 2000)})}),
    'corner': obj({'target': choice('near', ['near', 'spot', 'far']), 'bar_ms': number(200, 100, 400),
                   'power_trim_tenths': number(0, -10, 10), 'x_trim': number(0, -30, 30),
                   'y_trim': number(0, -30, 30), 'arm_timeout_ms': number(20000, 1000, 60000)}),
    'tactics': obj({'team_press': flag('D-pad Left'), 'offside_trap': flag('D-pad Up')}),
    'skills': obj({'mapping': obj({d: number(0, 0, 9999, '0 = disabled; otherwise catalog skill ID.') for d in DIRECTIONS}),
                   'trigger_percent': number(65, 40, 100), 'center_percent': number(20, 0, 39)})
})
config_schema.update({'$schema': 'https://json-schema.org/draft/2020-12/schema', 'title': 'FFS Bridge settings v1'})


def defaults(schema):
    if schema.get('type') == 'object':
        return {k: defaults(v) for k, v in schema['properties'].items()}
    return schema['default']


vector = {'type': 'array', 'items': {'type': 'number', 'minimum': -1, 'maximum': 1},
          'minItems': 2, 'maxItems': 2}
values = obj({key: ({'type': 'number', 'minimum': -1, 'maximum': 1} if key in AXES[:4]
                    else {'type': 'number', 'minimum': 0, 'maximum': 1} if key in ('lt', 'rt')
                    else {'type': 'integer', 'enum': [0, 1]}) for key in BUTTONS + AXES + LOGICAL})
values['required'] = []
step_props = {'duration_ms': number(40, 1, 10000), 'set': values,
              'rs_local': vector, 'ls_local': vector}
skill_step = obj(step_props)
skill_step['required'] = ['duration_ms']
action_step = obj({**step_props,
                   'duration_ms': {'oneOf': [number(40, 1, 10000),
                                    {'enum': ['$charge_ms', '$gap_ms', '$request_ms', '$delay_ms', '$lob_ms']}]},
                   'modifiers': {'type': 'boolean'}, 'confirm': {'type': 'boolean'}})
action_step['required'] = ['duration_ms']
steps = lambda item: {'type': 'array', 'minItems': 1, 'maxItems': 128, 'items': item}
catalog_schema = obj({
    'version': {'const': 1}, 'source_sha256': {'type': 'string'}, 'notes': {'type': 'string'},
    'skills': {'type': 'array', 'minItems': 1, 'maxItems': 1000, 'items': obj({
        'id': number(1, 1, 9999), 'name': {'type': 'string', 'minLength': 1, 'maxLength': 120},
        'mirror_trigger': {'type': 'boolean'}, 'scale_percent': number(100, 25, 300),
        'steps': steps(skill_step)})},
    'actions': obj({key: steps(action_step) for key in
                    ('charge', 'pass', 'cross', 'double_shot', 'one_touch', 'run_lob', 'team_press', 'offside_trap')})
})
catalog_schema.update({'$schema': 'https://json-schema.org/draft/2020-12/schema', 'title': 'FFS Bridge recipe catalog v1'})

if __name__ == '__main__':
    ROOT.mkdir(exist_ok=True)
    for name, value in [('default_settings.json', defaults(config_schema)),
                        ('settings.schema.json', config_schema), ('catalog.schema.json', catalog_schema)]:
        (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print(ROOT / name)
