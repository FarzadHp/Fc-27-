"""Preview-only GUI stress runner; no physical or virtual controller required.
Run: python tools/gui_stress.py --cycles 300 --applies 50
CSV samples and a sibling .log report are saved even when a check fails.
"""
from __future__ import annotations

import argparse
import csv
import queue
import sys
import tempfile
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import tkinter as tk
from ffsbridge.config import ConfigStore
from ffsbridge.diagnostics import count_widgets, process_resources
from ffsbridge.input_sdl import Device
from ffsbridge.service import BridgeService
from ffsbridge.state import PadState
from ffsbridge.ui import BridgeApp


def gui_resources():
    data = process_resources()
    return (data['user'], data['gdi']) if 'user' in data and 'gdi' in data else None


def pending_after_count(root):
    return len(root.tk.splitlist(root.tk.call('after', 'info')))


DEVICE = Device(1, "Stress fake controller", "0" * 32, True)


class FakeInput:
    def load_mappings(self, path):
        pass

    def devices(self):
        return [DEVICE]

    def open(self, device):
        return device

    def read(self, deadzone):
        time.sleep(0.004)
        return PadState()

    def close_device(self):
        pass

    def close(self):
        pass


class ObservedQueue(queue.Queue):
    """Observe events consumed by the real UI, without stealing or changing them."""
    def __init__(self):
        super().__init__()
        self.observed = []

    def get(self, block=True, timeout=None):
        event = super().get(block, timeout)
        self.observed.append(event)
        return event


def pump(root, seconds=0.05):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        root.update()
        time.sleep(0.005)


def wait_until(root, predicate, timeout, label, check=lambda: None):
    deadline = time.monotonic() + timeout
    while True:
        root.update()
        check()
        if predicate():
            return
        if time.monotonic() >= deadline:
            raise TimeoutError(label)
        time.sleep(0.005)


def select(app, name):
    app.group_box.selection_clear(0, "end")
    app.group_box.selection_set(app.groups.index(name))
    app._show_group()


def sample(root, app, step):
    for _ in range(3):
        root.update()
    form = app.form
    selection = app.group_box.curselection()
    return {
        "step": step,
        "group": app.groups[selection[0]] if selection else "General",
        "gui": gui_resources(),
        "widgets": count_widgets(root),
        "after": pending_after_count(root),
        "form_visible": bool(form.winfo_exists() and form.winfo_ismapped()
                             and form.winfo_height() > 1 and form.winfo_children()),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cycles", type=int, default=300)
    parser.add_argument("--applies", type=int, default=50)
    parser.add_argument("--timeout", type=float, default=10)
    parser.add_argument("--csv", default="stress_result.csv")
    args = parser.parse_args()
    if args.cycles < 0 or args.applies < 0 or args.timeout <= 0:
        parser.error("cycles/applies must be nonnegative and timeout positive")

    root = service = app = tmp = None
    failures, rows = [], []
    events = ObservedQueue()
    requested = acknowledged = 0
    baseline = final = None

    def callback_failure(kind, error, tb):
        failures.append("Tk callback:\n" + "".join(traceback.format_exception(kind, error, tb)))

    def check(running=False):
        if app is not None and app.poll_failure_count:
            raise RuntimeError('UI event polling failed')
        if failures:
            raise RuntimeError("GUI/callback failure recorded")
        bad = [e for e in events.observed if e["type"] in ("error", "apply_rejected")]
        if bad:
            raise RuntimeError(f"Service failure: {bad[-1]}")
        if service is not None and not service.thread.is_alive():
            raise RuntimeError("Service worker exited unexpectedly")
        if running and not service.snapshot()["running"]:
            raise RuntimeError("Preview stopped unexpectedly")

    def capture(step):
        row = sample(root, app, step)
        rows.append(row)
        if not row["form_visible"]:
            raise RuntimeError(f"Form not visible at {step}")
        return row

    try:
        root = tk.Tk()
        root.report_callback_exception = callback_failure
        tmp = tempfile.TemporaryDirectory()
        service = BridgeService(tmp.name, FakeInput)
        service.events = events
        app = BridgeApp(root, ConfigStore(tmp.name), service, auto_scan=False)
        # Report errors without modal dialogs blocking an unattended test.
        app._error = lambda message: failures.append(f"UI error: {message}")
        app.devices = [DEVICE]
        app.device_box.configure(values=[DEVICE.label])
        app.device_box.current(0)
        app.preview.set(True)
        app.tabs.select(0)
        pump(root, 0.3)
        app.start()
        wait_until(root, lambda: service.snapshot()["running"], args.timeout,
                   "Preview did not start", check)
        for name in app.groups:
            select(app, name)
            pump(root, 0.02)
        select(app, "Skills")
        pump(root, 0.3)
        check(True)
        baseline = capture("baseline")
        for i in range(1, max(args.cycles, args.applies) + 1):
            check(True)
            if i <= args.cycles:
                select(app, app.groups[i % len(app.groups)])
            if i <= args.applies:
                wait_until(root, lambda: str(app.apply_button.cget("state")) == "normal",
                           args.timeout, "Apply did not become available", lambda: check(True))
                before = sum(e["type"] == "applied" for e in events.observed)
                app.apply_button.invoke()
                requested += 1
                wait_until(root, lambda: sum(e["type"] == "applied" for e in events.observed) > before,
                           args.timeout, "Apply acknowledgement timed out", lambda: check(True))
                acknowledged += 1
            pump(root, 0.02)
            check(True)
            if i % 25 == 0:
                print(capture(i), flush=True)
        # Compare the SAME form with the SAME running service after idle work.
        select(app, baseline["group"])
        pump(root, 0.3)
        check(True)
        final = capture("final")
        for key in ("widgets", "after"):
            if final[key] != baseline[key]:
                failures.append(f"{key}: {baseline[key]} -> {final[key]}")
        if requested != args.applies or acknowledged != requested:
            failures.append(f"Apply counts: expected={args.applies}, requested={requested}, acknowledged={acknowledged}")
    except Exception:
        failures.append(traceback.format_exc())
    finally:
        if service is not None:
            try:
                if app is not None:
                    app.stop()
                else:
                    service.stop()
                service.shutdown()
                deadline = time.monotonic() + args.timeout
                while service.alive and time.monotonic() < deadline:
                    if root is not None:
                        root.update()
                    time.sleep(0.01)
                if service.alive:
                    failures.append("Shutdown timed out: worker/output still alive")
                if service.snapshot()["running"]:
                    failures.append("Running telemetry persisted after shutdown")
            except Exception:
                failures.append("Cleanup:\n" + traceback.format_exc())
        if app is not None:
            app.closing = True
            if app.sampler is not None:
                app.sampler.stop()
            if app.stall_watch is not None:
                app.stall_watch.stop()
            if app.form_reset_job is not None:
                try:
                    root.after_cancel(app.form_reset_job)
                except tk.TclError as exc:
                    failures.append(f"Cancel form reset: {exc}")
            if app.poll_job is not None:
                try:
                    root.after_cancel(app.poll_job)
                except tk.TclError as exc:
                    failures.append(f"Cancel poll: {exc}")
        if root is not None:
            try:
                root.destroy()
            except tk.TclError as exc:
                failures.append(f"Destroy: {exc}")
        if tmp is not None:
            try:
                tmp.cleanup()
            except OSError as exc:
                failures.append(f"Temporary directory cleanup: {exc}")
        bad = [e for e in events.observed if e["type"] in ("error", "apply_rejected")]
        if bad:
            failures.append(f"Observed service errors: {bad}")
        report = [f"Apply requested={requested}, acknowledged={acknowledged}"]
        if baseline and final and baseline["gui"] is not None and final["gui"] is not None:
            report.append(f"USER/GDI delta: {tuple(b-a for a,b in zip(baseline['gui'], final['gui']))}")
        else:
            report.append("Comparable USER/GDI measurements unavailable")
        report.extend(failures or ["No check failed; this does NOT prove the Windows GUI bug is fixed."])
        report.append("Resource growth requires investigation; stable counts do not exclude layout/callback problems.")
        output = Path(args.csv)
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open("w", newline="", encoding="utf-8") as fh:
                writer = csv.DictWriter(fh, fieldnames=["step", "group", "gui", "widgets", "after", "form_visible"])
                writer.writeheader()
                writer.writerows(rows)
            output.with_suffix(".log").write_text("\n".join(report), encoding="utf-8")
        except OSError as exc:
            failures.append(f"Saving results failed: {exc}")
            report.append(failures[-1])
        print("\n".join(report))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
