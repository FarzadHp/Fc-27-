"""Windows build inputs, deliberately without importing vgamepad or PyInstaller.

Only the two explicitly named native DLLs are selected. In particular, never
collect_all('vgamepad'): its source distribution also contains driver installers.
"""
from __future__ import annotations

import argparse
from importlib.metadata import distribution
from pathlib import Path, PurePosixPath
import platform
import struct
import sys

DATA_FILES = ("default_settings.json", "catalog.json", "settings.schema.json", "catalog.schema.json")
NATIVE_FILES = (
    ("pysdl2-dll", "sdl2dll/dll/SDL2.dll"),
    ("vgamepad", "vgamepad/win/vigem/client/x64/ViGEmClient.dll"),
)
LICENSE_PACKAGES = (
    "jsonschema", "jsonschema-specifications", "attrs", "referencing", "rpds-py",
    "typing-extensions", "PySDL2", "pysdl2-dll", "vgamepad",
)


def require_build_host():
    if sys.platform != "win32":
        raise RuntimeError("Build on Windows; PyInstaller does not cross-compile this app from Linux/macOS.")
    if struct.calcsize("P") != 8 or platform.machine().lower() not in ("amd64", "x86_64"):
        raise RuntimeError("This build requires Windows x64 and 64-bit Python (not x86 or ARM64).")
    if sys.version_info[:2] != (3, 11):
        raise RuntimeError("Use Python 3.11 x64 for the pinned build recipe.")


def check_pe_x64(path: Path):
    """Check PE signature/machine, not trust/signature or all DLL dependencies."""
    with path.open("rb") as stream:
        header = stream.read(64)
        if len(header) != 64 or header[:2] != b"MZ":
            raise ValueError(f"Not a Windows PE binary: {path}")
        offset = struct.unpack_from("<I", header, 0x3C)[0]
        if offset < 64 or offset > path.stat().st_size - 24:
            raise ValueError(f"Invalid PE header offset: {path}")
        stream.seek(offset)
        signature = stream.read(6)
        if signature[:4] != b"PE\0\0" or signature[4:] != b"\x64\x86":
            raise ValueError(f"Expected x64 PE binary, not a Linux/x86/ARM64 binary: {path}")


def native_binaries(locate=distribution):
    binaries = []
    for package, relative in NATIVE_FILES:
        source = Path(locate(package).locate_file(relative))
        check_pe_x64(source)
        binaries.append((str(source), str(PurePosixPath(relative).parent)))
    return binaries


def data_files(root: Path):
    result = []
    for filename in DATA_FILES:
        path = root / "data" / filename
        if not path.is_file():
            raise FileNotFoundError(path)
        result.append((str(path), "data"))
    return result


def license_files(locate=distribution, python_root=None):
    """Copy available installed-package notices; not a legal completeness audit."""
    result = []
    for package in LICENSE_PACKAGES:
        dist = locate(package)
        for entry in dist.files or ():
            path = PurePosixPath(str(entry).replace("\\", "/"))
            if path.is_absolute() or ".." in path.parts:
                continue
            if (path.name.lower().startswith(("license", "copying", "notice"))
                    or "licenses" in (part.lower() for part in path.parts)):
                source = Path(dist.locate_file(entry))
                if source.is_file():
                    destination = PurePosixPath("licenses", package) / path.parent
                    result.append((str(source), str(destination)))
    base = Path(python_root or sys.base_prefix)
    for relative in ("LICENSE.txt", "tcl/tcl8.6/license.terms", "tcl/tk8.6/license.terms"):
        source = base / relative
        if source.is_file():
            destination = PurePosixPath("licenses", "Python") / PurePosixPath(relative).parent
            result.append((str(source), str(destination)))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Validate Windows x64 build inputs without creating a virtual controller")
    parser.add_argument("--host-only", action="store_true")
    args = parser.parse_args(argv)
    require_build_host()
    if not args.host_only:
        native_binaries()
        import tkinter
        import jsonschema  # noqa: F401
        import sdl2
        print("Tcl:", tkinter.Tcl().eval("info patchlevel"))
        print("SDL loaded:", sdl2.__version__)
    print("Windows/Python x64 preflight OK; no driver installed, no virtual controller created.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
