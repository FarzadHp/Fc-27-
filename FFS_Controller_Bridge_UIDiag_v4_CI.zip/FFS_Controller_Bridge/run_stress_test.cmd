@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
if not exist ".venv\Scripts\python.exe" (
    echo Run setup_windows.cmd first.
    popd
    exit /b 1
)
set "PYTHONUTF8=1"
rem Default mode is fake controller + Preview: no hardware, no driver. See docs\UI_DIAGNOSTICS_FA.md.
".venv\Scripts\python.exe" tools\stress_ui.py %*
set "RC=%ERRORLEVEL%"
popd
exit /b %RC%
