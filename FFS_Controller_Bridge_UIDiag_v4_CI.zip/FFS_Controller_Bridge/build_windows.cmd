@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
set "RC=1"
set "VGAMEPAD_SKIP_VIGEMBUS_INSTALL=true"
set "PYTHONUTF8=1"
rem A failed build must never leave an old or partial EXE folder that looks usable.
if exist dist\FFSControllerBridge rmdir /s /q dist\FFSControllerBridge
if exist dist\FFSControllerBridge (
    echo Cannot remove the old dist\FFSControllerBridge. Close the running app and try again.
    goto finish
)
call setup_windows.cmd --no-pause
if errorlevel 1 goto finish
".venv\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto finish
if not exist build mkdir build
".venv\Scripts\python.exe" -m unittest discover -s tests -v >build\test-results.txt 2>&1
if errorlevel 1 (
    type build\test-results.txt
    goto finish
)
type build\test-results.txt
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --workpath build\pyinstaller FFSControllerBridge.spec
if errorlevel 1 goto finish
".venv\Scripts\python.exe" tools\verify_windows_build.py dist\FFSControllerBridge
if errorlevel 1 goto finish
copy /Y README.md dist\FFSControllerBridge\README.md >nul
if errorlevel 1 goto finish
copy /Y THIRD_PARTY.md dist\FFSControllerBridge\THIRD_PARTY.md >nul
if errorlevel 1 goto finish
if not exist dist\FFSControllerBridge\docs mkdir dist\FFSControllerBridge\docs
copy /Y docs\WINDOWS_FA.md dist\FFSControllerBridge\docs\WINDOWS_FA.md >nul
if errorlevel 1 goto finish
".venv\Scripts\python.exe" -m pip freeze >dist\FFSControllerBridge\build-requirements.txt
if errorlevel 1 goto finish
echo.
echo Build checks passed. Distribute the ENTIRE dist\FFSControllerBridge folder.
echo Live GUI, driver and physical-controller acceptance checks are still required.
set "RC=0"
:finish
if not "%RC%"=="0" echo BUILD FAILED. No EXE was produced; do not use any old copy.
if not "%RC%"=="0" if exist dist\FFSControllerBridge rmdir /s /q dist\FFSControllerBridge
popd
if /I not "%~1"=="--no-pause" pause
exit /b %RC%
