"""Source and PyInstaller entry point."""
from ffsbridge.launcher import main

if __name__ == "__main__":
    raise SystemExit(main())
