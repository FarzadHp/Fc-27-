# -*- mode: python ; coding: utf-8 -*-
# Build on Windows x64 with build_windows.cmd. Not a Linux cross-build spec.
from pathlib import Path
import sys

ROOT = Path(SPECPATH)
sys.path.insert(0, str(ROOT))
from tools.windows_bundle import require_build_host, native_binaries, data_files, license_files

require_build_host()
a = Analysis(
    [str(ROOT / "run_bridge.py")],
    pathex=[str(ROOT)],
    binaries=native_binaries(),
    datas=data_files(ROOT) + license_files(),
    hiddenimports=["sdl2dll", "vgamepad.win.virtual_gamepad", "jsonschema_specifications"],
    hookspath=[],
    runtime_hooks=[str(ROOT / "windows" / "rthook_sdl2.py")],
    excludes=["vgamepad.lin", "libevdev"],
    noarchive=False,
)
pyz = PYZ(a.pure)
# Two entry points share one folder: GUI for everyday use, console for diagnostics.
gui = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name="FFSControllerBridge",
    debug=False, strip=False, upx=False, console=False,
)
console = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name="FFSControllerBridge-console",
    debug=False, strip=False, upx=False, console=True,
)
coll = COLLECT(
    gui, console, a.binaries, a.datas,
    strip=False, upx=False, name="FFSControllerBridge",
)
