"""Do the SDL calls leak USER/GDI objects? Real SDL2 (pysdl2-dll), no Tk, no controller needed.

Phase 1: create/enumerate/close SDLInput N times (the Refresh path creates the backend once, but this
         is the worst case). Phase 2: one backend, enumerate N times. Prints the process resources.
Windows only for the numbers; elsewhere it just checks the loop runs.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ffsbridge import diagnostics  # noqa: E402
from ffsbridge.input_sdl import SDLInput  # noqa: E402


def show(label):
    data = diagnostics.process_resources()
    print(f"{label:28s} {diagnostics.format_snapshot(data) if data else '(no Windows counters)'}", flush=True)
    return data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=300)
    parser.add_argument("--max-growth", type=int, default=50)
    args = parser.parse_args()
    start = show("start")
    for i in range(args.iterations):
        backend = SDLInput()
        backend.devices()
        backend.close()
        if (i + 1) % 50 == 0:
            show(f"new backend x{i + 1}")
    middle = show("after phase 1")
    backend = SDLInput()
    for i in range(args.iterations * 3):
        backend.devices()
        if (i + 1) % 150 == 0:
            show(f"devices() x{i + 1}")
    backend.close()
    end = show("after phase 2")
    if start and end:
        grown = {k: end[k] - start[k] for k in ("user", "gdi") if end[k] - start[k] > args.max_growth}
        print("RESULT:", "GROWTH " + str(grown) if grown else "no USER/GDI growth beyond threshold")
        return 1 if grown else 0
    print("RESULT: loop ran (no counters on this OS)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
