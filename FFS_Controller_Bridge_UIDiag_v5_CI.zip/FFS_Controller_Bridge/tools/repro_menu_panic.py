"""Windows experiment: does USER-handle exhaustion produce 'Failed to create the menu window'?

cold: exhaust this process's USER objects, THEN let Tk initialise its lazy menu windows
      (what the first WM_SYSCOMMAND would do). Expected if the hypothesis holds: Tcl_Panic,
      process dies, faulthandler.log written.
warm: same, but ffsbridge.diagnostics.warm_up_tk_menu() ran at startup. Measured on a real
      runner: no panic. Then a mapped widget is created and its HWND is checked (see output).
Results are evidence about the hypothesis only; they do not show what exhausted the handles in the real app.
"""
import argparse
import subprocess
import sys
import textwrap
from pathlib import Path

CHILD = r'''
import ctypes, sys, tkinter as tk
from ctypes import wintypes
from pathlib import Path
sys.path.insert(0, sys.argv[3])
from ffsbridge import diagnostics
diagnostics.enable_faulthandler(Path(sys.argv[2]))
root = tk.Tk()
if sys.argv[1] == "warm":
    diagnostics.warm_up_tk_menu(root)
user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.CreateWindowExW.restype = wintypes.HWND
user32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HWND, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
count = 0
while user32.CreateWindowExW(0, "STATIC", "x", 0, 0, 0, 1, 1, None, None, None, None):
    count += 1
print("windows created before failure:", count, "| USER objects:", diagnostics.process_resources().get("user"), flush=True)
try:
    if sys.argv[1] == "cold":
        tk.Menu(root)      # first menu use in this thread -> TkpMenuThreadInit
        print("RESULT: no failure", flush=True)
    else:
        # A Tk widget only gets its native window when it is mapped: pack + update forces that.
        user32.IsWindow.argtypes = [wintypes.HWND]
        label = tk.Label(root, text="after exhaustion")
        label.pack()
        root.update()
        hwnd = label.winfo_id()
        print("label HWND:", hex(hwnd), "| IsWindow:", bool(user32.IsWindow(hwnd)),
              "| mapped:", bool(label.winfo_ismapped()), flush=True)
        print("RESULT: no panic" + ("" if user32.IsWindow(hwnd) else " but the widget has NO native window (silent)"), flush=True)
except tk.TclError as exc:
    print("RESULT: TclError (catchable):", exc, flush=True)
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("cold", "warm"))
    parser.add_argument("--out", type=Path, default=Path("repro-out"))
    args = parser.parse_args()
    if sys.platform != "win32":
        print("Windows only.")
        return 2
    args.out.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[1]
    run = subprocess.run([sys.executable, "-c", textwrap.dedent(CHILD), args.mode, str(args.out), str(root)],
                         capture_output=True, text=True, timeout=300)
    print(f"mode={args.mode} exit={run.returncode}\n{run.stdout}{run.stderr}")
    fault = args.out / "faulthandler.log"
    print("faulthandler.log:", fault.read_text(errors="replace")[:1500] if fault.exists() else "(none)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
