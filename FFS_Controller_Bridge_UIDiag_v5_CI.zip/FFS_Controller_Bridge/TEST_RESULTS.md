# نتیجهٔ آزمون‌ها

## Windows واقعی (GitHub Actions windows-latest، Python 3.11.9 x64، Tk 8.6.12)
کنترلر واقعی، ViGEmBus و درایور گرافیک شما در کار نبود؛ ورودی جعلی + Preview.

| آزمون | نتیجه |
|---|---|
| تست‌های واحد | 147 تست؛ 146 OK، **1 شکست** (`test_wheel_over_skill_combobox_scrolls_form_not_value`)، 1 skip. شکست از **خود تست** بود: کنترل آن با رویداد X11 (`Button-5`) نوشته شده بود که در Windows وجود ندارد. در این نسخه با `<MouseWheel>` اصلاح شد |
| `stress_ui.py` 800 تعامل | PASS. USER 107→108، GDI 35 ثابت، HWND برابر شمار ویجت، 30 Apply تأییدشده |
| `gui_stress.py` 300 چرخه و 50 Apply | 50/50 تأیید؛ USER/GDI delta = (0, 0) |
| `repro_menu_panic.py cold` | **بازتولید شد**: `Failed to create the menu window`، کد خروج 0x80000003، `faulthandler.log` پر شد |
| `repro_menu_panic.py warm` | بدون پانیک؛ ساخت `Label` بدون map هیچ HWND نمی‌خواهد، پس آزمون ضعیف بود. نسخهٔ جدید map می‌کند و HWND را چاپ می‌کند (هنوز اجرا نشده) |

## Linux (Xvfb، Tk 8.6.14) روی همین بسته
151 تست: OK، 1 skip (تست Windows-only). این تست‌ها روی Windows واقعی دوباره اجرا نشده‌اند.

## اجرا نشده
`sdl_handle_probe.py` و `handle_pressure` روی Windows، رفتار با کنترلر فیزیکی و خروجی واقعی Xbox، ساخت EXE. علت فرم خالی و خطای `menu window` در برنامهٔ شما: **هنوز تأیید نشده**.
