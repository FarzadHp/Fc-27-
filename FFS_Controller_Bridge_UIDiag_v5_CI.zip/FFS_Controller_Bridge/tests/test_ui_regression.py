"""Windows-relevant GUI regressions. Hardware-free: fake input device, Preview output.

Run on Windows, or on Linux with Tk and a display (xvfb-run). They check Python/Tk
object lifecycles (widgets, Tcl commands, pending after() jobs, threads), not Windows
USER/GDI handles; use tools/stress_ui.py on Windows for those.
"""
import queue
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch

try:
    import tkinter as tk
    from tkinter import ttk
    from ffsbridge.ui import BridgeApp
except ImportError:
    tk = None

from ffsbridge import diagnostics
from ffsbridge.config import ConfigStore
from ffsbridge.service import BridgeService
from ffsbridge.state import PadState
from tests.test_service import DEVICE, FakeInput

GROUPS = ["General", "Movement", "Shots", "Snap", "Passes", "Corner", "Tactics", "Skills"]
CHARGE = ("passes", "pass", "charge_ms")


def idle_snapshot():
    return {"running": False, "input": PadState().as_dict(), "output": PadState().as_dict(), "activity": "Stopped"}


class GuiCase(unittest.TestCase):
    service = None

    def make_app(self, service=None, poll=False):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(str(exc))
        self.addCleanup(self.root.destroy)
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.service = service or SimpleNamespace(events=queue.Queue(), snapshot=idle_snapshot)
        if poll:
            self.app = BridgeApp(self.root, ConfigStore(temp.name), self.service, auto_scan=False)
            self.addCleanup(self.stop_polling)
        else:
            with patch.object(BridgeApp, "_poll"):
                self.app = BridgeApp(self.root, ConfigStore(temp.name), self.service, auto_scan=False)
        self.app.tabs.select(0)
        self.root.update()
        return self.app

    def stop_polling(self):
        if self.app.poll_job is not None:
            self.root.after_cancel(self.app.poll_job)
            self.app.closing = True

    def pump(self, predicate, timeout=8.0):
        """Run the real Tk event loop (timers included) until predicate() holds."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.root.update()
            if predicate():
                return
            time.sleep(0.01)
        raise AssertionError("Timed out waiting for the UI/event loop")

    def select(self, group):
        box = self.app.group_box
        box.selection_clear(0, "end")
        box.selection_set(GROUPS.index(group))
        self.app._show_group()
        self.root.update()

    def fields(self):
        return [w for w in self.app.form.winfo_children()
                if isinstance(w, (ttk.Entry, ttk.Checkbutton, ttk.Combobox))]

    def assert_form_visible(self, group):
        expected = sum(p[0] in ({"input", "layout", "shortcuts"} if group == "General" else {group.lower()})
                       for p in self.app.field_schemas)
        fields = self.fields()
        self.assertEqual(len(fields), expected)
        self.assertTrue(all(w.winfo_ismapped() for w in fields))
        self.assertLessEqual(self.app.form_canvas.canvasy(0), 1)


@unittest.skipIf(tk is None, "Tk libraries unavailable")
class GroupSwitchRegressions(GuiCase):
    def setUp(self):
        self.make_app()

    def cycle(self):
        for group in GROUPS:
            self.select(group)
            self.app.form_canvas.yview_moveto(1)  # scroll to the bottom before every swap
        self.select("Passes")

    def test_canvas_attach_failure_preserves_previous_form(self):
        previous = self.app.form
        shown = self.app.shown_group
        widgets = diagnostics.count_widgets(self.root)
        self.app.group_box.selection_clear(0, 'end')
        self.app.group_box.selection_set(GROUPS.index('Skills'))
        with patch.object(self.app.form_canvas, 'itemconfigure', side_effect=tk.TclError('injected attach failure')):
            with self.assertRaisesRegex(tk.TclError, 'injected attach failure'):
                self.app._show_group()
        self.assertIs(self.app.form, previous)
        self.assertTrue(previous.winfo_exists())
        self.assertEqual(self.app.shown_group, shown)
        self.assertEqual(self.app.groups[self.app.group_box.curselection()[0]], shown)
        self.assertEqual(diagnostics.count_widgets(self.root), widgets)

    def test_repeated_group_switching_does_not_grow_tk_objects(self):
        for _ in range(3):
            self.cycle()
        baseline = diagnostics.tk_snapshot(self.root)
        for _ in range(40):
            self.cycle()
        after = diagnostics.tk_snapshot(self.root)
        self.assertEqual(after["widgets"], baseline["widgets"])
        self.assertEqual(after["globals"], baseline["globals"])
        self.assertLessEqual(after["commands"], baseline["commands"] + 5)
        self.assertLessEqual(after["after"], baseline["after"])
        self.assert_form_visible("Passes")

    def test_skills_and_passes_after_scroll_stay_visible_with_edits(self):
        self.app.form_vars[CHARGE].set("321")
        for _ in range(10):
            self.select("Skills")
            self.app.form_canvas.yview_moveto(1)
            self.select("Passes")
            self.assert_form_visible("Passes")
            self.assertEqual(self.app.form_vars[CHARGE].get(), "321")

    def test_only_one_form_reset_is_ever_pending(self):
        for group in GROUPS * 3:
            box = self.app.group_box
            box.selection_clear(0, "end")
            box.selection_set(GROUPS.index(group))
            self.app._show_group()  # deliberately no event-loop turn in between
        self.assertEqual(sum(1 for job in self.root.tk.splitlist(self.root.tk.call("after", "info"))
                             if "_reset_form_view" in str(self.root.tk.call("after", "info", job))), 1)
        self.root.update()
        self.assertIsNone(self.app.form_reset_job)

    def test_failed_rebuild_keeps_form_and_list_selection(self):
        self.select("Passes")
        previous = self.app.form
        real_build = self.app._build_group

        def fail_for_skills(form, group):
            if group == "Skills":
                raise ValueError("test")
            return real_build(form, group)

        with patch.object(self.app, "_build_group", side_effect=fail_for_skills):
            self.app.group_box.selection_clear(0, "end")
            self.app.group_box.selection_set(GROUPS.index("Skills"))
            with self.assertRaises(ValueError):  # the failure is surfaced, not swallowed
                self.app._show_group()
        self.root.update()
        self.assertIs(self.app.form, previous)
        self.assertEqual(self.app.group_box.curselection(), (GROUPS.index("Passes"),))
        self.assert_form_visible("Passes")
        self.assertEqual(len(self.root.winfo_children()), len({str(w) for w in self.root.winfo_children()}))

    def wheel(self, widget):
        """One wheel-down event the way this windowing system delivers it."""
        if self.root.tk.call("tk", "windowingsystem") == "x11":
            widget.event_generate("<Button-5>")
        else:  # Windows (and macOS): ttk binds <MouseWheel>, not Button-4/5
            widget.event_generate("<MouseWheel>", delta=-120)
        self.root.update()

    def test_wheel_over_skill_combobox_scrolls_form_not_value(self):
        self.root.geometry("1100x500")
        self.select("Skills")
        combo = next(w for w in self.fields() if isinstance(w, ttk.Combobox))
        before = combo.get()
        for _ in range(5):
            self.wheel(combo)  # ttk's class binding would select the next value
        self.assertEqual(combo.get(), before)
        # Control: the same event over a plain ttk.Combobox DOES change its value, so the
        # assertion above cannot pass merely because the event never arrived.
        plain = ttk.Combobox(self.root, values=["a", "b", "c"], state="readonly")
        plain.set("a")
        plain.pack()
        self.root.update()
        self.wheel(plain)
        self.assertEqual(plain.get(), "b")

    def test_resize_minimize_restore_and_tab_changes_keep_form(self):
        self.select("Skills")
        self.app.form_vars[CHARGE].set("333")
        for size in ("850x630", "1300x900", "900x700"):
            self.root.geometry(size)
            self.root.update()
            self.assertEqual(int(self.app.form_canvas.itemcget(self.app.form_window, "width")),
                             self.app.form_canvas.winfo_width())
        self.root.iconify()
        self.root.update()
        self.root.deiconify()
        self.root.update()
        self.assertEqual(self.root.state(), "normal")
        for index in (1, 2, 3, 4, 0, 3, 0):
            self.app.tabs.select(index)
            self.root.update()
        self.assertTrue(self.app.form.winfo_ismapped())
        self.assertTrue(all(w.winfo_ismapped() for w in self.fields()))
        self.select("Passes")
        self.assertEqual(self.app.form_vars[CHARGE].get(), "333")

    def test_live_table_is_only_redrawn_while_its_tab_is_visible(self):
        state = idle_snapshot()
        state.update(running=True, paused=False, menu=False, corner=False, activity="Passthrough")
        state["input"] = dict(state["input"], lx=0.5)
        self.service.snapshot = lambda: state
        self.app._poll_events()
        self.assertEqual(str(self.app.io.item("lx", "values")[0]), "0.000")  # Settings tab visible: table untouched
        self.app.tabs.select(self.app.monitor_tab)
        self.app._poll_events()
        self.assertEqual(str(self.app.io.item("lx", "values")[0]), "+0.500")
        self.assertTrue(self.app.status.get().endswith("Passthrough"))

    def test_error_and_menu_events_select_tabs_by_identity_not_position(self):
        self.app.tabs.select(self.app.monitor_tab)
        self.service.events.put({"type": "error", "message": "driver failed"})
        self.app._poll_events()
        self.assertEqual(self.app.tabs.select(), str(self.app.logs_tab))
        self.service.events.put({"type": "menu", "value": True})
        self.app._poll_events()
        self.assertEqual(self.app.tabs.select(), str(self.app.settings_tab))

    def test_handle_pressure_is_reported_once_in_the_log_tab(self):
        with patch.object(diagnostics, "handle_pressure", return_value="USER=9000/10000 nearly out"):
            with self.assertLogs("ffsbridge.ui", level="ERROR") as logs:
                for group in GROUPS * 2:
                    self.select(group)
        self.assertEqual(len(logs.records), 1)  # throttled, not once per group switch
        self.assertIn("USER=9000", self.app.log_box.get("1.0", "end"))

    def test_poll_failure_is_logged_once_not_at_20hz(self):
        with patch.object(self.app, "_poll_events", side_effect=RuntimeError("persistent")):
            with self.assertLogs("ffsbridge.ui", level="ERROR") as logs:
                for _ in range(100):
                    self.app._poll()
                    self.root.after_cancel(self.app.poll_job)  # a test artefact: do not stack timers
        self.assertEqual(len(logs.records), 1)
        self.assertIsNotNone(logs.records[0].exc_info)  # the first one carries the traceback


@unittest.skipIf(tk is None, "Tk libraries unavailable")
class SessionRegressions(GuiCase):
    """Real BridgeService/worker threads with a fake input device and Preview output."""

    def setUp(self):
        service = BridgeService(tempfile.mkdtemp(), input_factory=lambda: FakeInput([]))
        self.addCleanup(self.close_service, service)
        self.make_app(service, poll=True)
        self.app.form_vars[("input", "watchdog_ms")].set("1000")  # keep slow CI from tripping the watchdog

    @staticmethod
    def close_service(service):
        service.shutdown()
        service.thread.join(5)

    def refresh(self):
        self.app.scan()
        self.pump(lambda: not self.app.scanning)

    def start(self):
        self.refresh()
        self.app.device_box.current(0)
        self.app.start()
        self.pump(lambda: self.app.busy and self.app.status.get().startswith("PREVIEW |"))

    def stop(self):
        self.app.stop()
        self.pump(lambda: not self.app.busy and not self.service.snapshot()["running"])

    def test_refresh_start_stop_cycles_keep_ui_and_objects_stable(self):
        samples = []
        for cycle in range(8):
            self.start()
            self.assertEqual(self.app.device_box.get(), DEVICE.label)
            self.stop()
            self.assertEqual(str(self.app.start_button["state"]), "normal")
            self.assertEqual(str(self.app.scan_button["state"]), "normal")
            self.refresh()
            self.assertEqual(self.app.device_box.current(), 0)  # exact device survives Refresh
            samples.append(diagnostics.tk_snapshot(self.root))
        first, last = samples[1], samples[-1]
        self.assertEqual(last["widgets"], first["widgets"])
        self.assertLessEqual(last["commands"], first["commands"] + 5)
        self.assertLessEqual(last["after"], first["after"] + 1)
        self.assertLessEqual(last["threads"], first["threads"])  # output thread is joined every Stop
        self.select("Skills")
        self.assert_form_visible("Skills")

    def test_repeated_apply_keeps_values_form_and_running_session(self):
        self.start()
        for step in range(12):
            value = 200 + step
            self.app.form_vars[CHARGE].set(str(value))
            self.app.apply_changes()
            self.pump(lambda: str(self.app.apply_button["state"]) == "normal")
            self.pump(lambda: self.service.engine is not None
                      and self.service.engine.settings["passes"]["pass"]["charge_ms"] == value)
            self.select("Skills")
            self.app.form_canvas.yview_moveto(1)
            self.select("Passes")
            self.assert_form_visible("Passes")
            self.assertEqual(self.app.form_vars[CHARGE].get(), str(value))
            self.assertTrue(self.app.status.get().startswith("PREVIEW |"))
        self.stop()

    def test_pending_callbacks_are_bounded_during_a_running_session(self):
        self.start()
        deadline = time.monotonic() + 1.5
        peak = 0
        while time.monotonic() < deadline:
            self.root.update()
            peak = max(peak, diagnostics.tk_snapshot(self.root)["after"])
            time.sleep(0.01)
        self.assertLessEqual(peak, 4)  # poll timer + at most a couple of idle jobs
        self.stop()


if __name__ == "__main__":
    unittest.main()
